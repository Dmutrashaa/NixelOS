#include "efi.h"

static void put_at(EFI_SIMPLE_TEXT_OUTPUT *o, UINTN cols, UINTN row, const CHAR16 *s, UINTN len, UINTN attr)
{
    o->SetAttribute(o, attr);
    o->SetCursorPosition(o, cols > len ? (cols - len) / 2 : 0, row);
    o->OutputString(o, s);
}

EFI_STATUS EFIAPI efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *st)
{
    EFI_SIMPLE_TEXT_OUTPUT *o = st->ConOut;
    UINTN cols = 80, rows = 25, idx;
    EFI_INPUT_KEY key;
    (void)image;

    if (!o) return EFI_UNSUPPORTED;
    o->SetMode(o, 0);
    o->QueryMode(o, (UINTN)o->Mode->Mode, &cols, &rows);
    o->SetAttribute(o, 0x07);
    o->ClearScreen(o);
    o->EnableCursor(o, 0);

    put_at(o, cols, 7, (const CHAR16 *)u"Error!", 6, 0x04);
    put_at(o, cols, 9, (const CHAR16 *)u"Cannot boot NixelOS. Error code: UNSUPPORTED_ARCH", 49, 0x0F);
    put_at(o, cols, 11, (const CHAR16 *)u"NXBoot for ARM is not available yet.", 36, 0x07);
    put_at(o, cols, 12, (const CHAR16 *)u"Check https://t.me/NixelOS for more information.", 48, 0x07);
    put_at(o, cols, 14, (const CHAR16 *)u"Press any key to return to the firmware...", 42, 0x07);

    if (st->ConIn && st->BootServices) {
        st->ConIn->Reset(st->ConIn, 0);
        st->BootServices->WaitForEvent(1, &st->ConIn->WaitForKey, &idx);
        st->ConIn->ReadKeyStroke(st->ConIn, &key);
    }
    o->SetAttribute(o, 0x07);
    o->ClearScreen(o);
    return EFI_UNSUPPORTED;
}
