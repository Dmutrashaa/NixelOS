#include "decoders.h"

/* ======== zlib inflate ======== */

typedef struct {
    const uint8_t *src;
    size_t len;
    size_t pos;
    uint32_t bitbuf;
    int bitcnt;
    uint8_t *out;
    size_t outlen;
    size_t outpos;
    int err;
} inf_t;

typedef struct {
    uint16_t count[16];
    uint16_t symbol[288];
} huff_t;

static int inf_bits(inf_t *s, int need)
{
    uint32_t v = s->bitbuf;
    while (s->bitcnt < need) {
        if (s->pos >= s->len) {
            s->err = 1;
            return 0;
        }
        v |= (uint32_t)s->src[s->pos++] << s->bitcnt;
        s->bitcnt += 8;
    }
    s->bitbuf = v >> need;
    s->bitcnt -= need;
    return (int)(v & ((1u << need) - 1));
}

static int huff_build(huff_t *h, const uint8_t *len, int n)
{
    uint16_t offs[16];
    int i, left = 1;
    for (i = 0; i < 16; i++) h->count[i] = 0;
    for (i = 0; i < n; i++) h->count[len[i]]++;
    if (h->count[0] == n) return 0;
    for (i = 1; i < 16; i++) {
        left <<= 1;
        left -= h->count[i];
        if (left < 0) return -1;
    }
    offs[1] = 0;
    for (i = 1; i < 15; i++) offs[i + 1] = offs[i] + h->count[i];
    for (i = 0; i < n; i++)
        if (len[i]) h->symbol[offs[len[i]]++] = (uint16_t)i;
    return left;
}

static int huff_decode(inf_t *s, const huff_t *h)
{
    int code = 0, first = 0, index = 0, len;
    for (len = 1; len <= 15; len++) {
        code |= inf_bits(s, 1);
        if (s->err) return -1;
        int count = h->count[len];
        if (code - count < first) return h->symbol[index + (code - first)];
        index += count;
        first += count;
        first <<= 1;
        code <<= 1;
    }
    return -1;
}

static const uint16_t len_base[29] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31,
                                      35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
static const uint8_t len_ext[29] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2,
                                    3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
static const uint16_t dist_base[30] = {1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129,
                                       193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097,
                                       6145, 8193, 12289, 16385, 24577};
static const uint8_t dist_ext[30] = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6,
                                     6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};

static int inf_codes(inf_t *s, const huff_t *lc, const huff_t *dc)
{
    for (;;) {
        int sym = huff_decode(s, lc);
        if (sym < 0) return -1;
        if (sym < 256) {
            if (s->outpos >= s->outlen) return -1;
            s->out[s->outpos++] = (uint8_t)sym;
        } else if (sym == 256) {
            return 0;
        } else {
            sym -= 257;
            if (sym >= 29) return -1;
            size_t len = len_base[sym] + (size_t)inf_bits(s, len_ext[sym]);
            int ds = huff_decode(s, dc);
            if (ds < 0 || ds >= 30) return -1;
            size_t dist = dist_base[ds] + (size_t)inf_bits(s, dist_ext[ds]);
            if (s->err || dist > s->outpos || len > s->outlen - s->outpos) return -1;
            while (len--) {
                s->out[s->outpos] = s->out[s->outpos - dist];
                s->outpos++;
            }
        }
    }
}

static int inf_fixed(inf_t *s)
{
    huff_t lc, dc;
    uint8_t l[288];
    int i;
    for (i = 0; i < 144; i++) l[i] = 8;
    for (; i < 256; i++) l[i] = 9;
    for (; i < 280; i++) l[i] = 7;
    for (; i < 288; i++) l[i] = 8;
    huff_build(&lc, l, 288);
    for (i = 0; i < 30; i++) l[i] = 5;
    huff_build(&dc, l, 30);
    return inf_codes(s, &lc, &dc);
}

static int inf_dynamic(inf_t *s)
{
    static const uint8_t order[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15};
    uint8_t lengths[320];
    huff_t lc, dc;
    int nlen = inf_bits(s, 5) + 257;
    int ndist = inf_bits(s, 5) + 1;
    int ncode = inf_bits(s, 4) + 4;
    int i;
    if (s->err || nlen > 286 || ndist > 30) return -1;
    for (i = 0; i < 19; i++) lengths[i] = 0;
    for (i = 0; i < ncode; i++) lengths[order[i]] = (uint8_t)inf_bits(s, 3);
    if (s->err) return -1;
    if (huff_build(&lc, lengths, 19) < 0) return -1;
    i = 0;
    while (i < nlen + ndist) {
        int sym = huff_decode(s, &lc);
        if (sym < 0) return -1;
        if (sym < 16) {
            lengths[i++] = (uint8_t)sym;
        } else {
            int val = 0, rep;
            if (sym == 16) {
                if (i == 0) return -1;
                val = lengths[i - 1];
                rep = 3 + inf_bits(s, 2);
            } else if (sym == 17) {
                rep = 3 + inf_bits(s, 3);
            } else {
                rep = 11 + inf_bits(s, 7);
            }
            if (s->err || i + rep > nlen + ndist) return -1;
            while (rep--) lengths[i++] = (uint8_t)val;
        }
    }
    if (lengths[256] == 0) return -1;
    if (huff_build(&lc, lengths, nlen) < 0) return -1;
    if (huff_build(&dc, lengths + nlen, ndist) < 0) return -1;
    return inf_codes(s, &lc, &dc);
}

int zlib_inflate(const uint8_t *src, size_t len, uint8_t *out, size_t outlen)
{
    inf_t s;
    int last;
    im_zero(&s, sizeof s);
    if (len < 2) return -1;
    if ((src[0] & 15) != 8 || ((src[0] << 8) | src[1]) % 31 || (src[1] & 32)) return -1;
    s.src = src;
    s.len = len;
    s.pos = 2;
    s.out = out;
    s.outlen = outlen;
    do {
        int type;
        last = inf_bits(&s, 1);
        type = inf_bits(&s, 2);
        if (s.err) return -1;
        if (type == 0) {
            size_t n, nn;
            s.bitbuf = 0;
            s.bitcnt = 0;
            if (s.len - s.pos < 4) return -1;
            n = s.src[s.pos] | ((size_t)s.src[s.pos + 1] << 8);
            nn = s.src[s.pos + 2] | ((size_t)s.src[s.pos + 3] << 8);
            if (n != (~nn & 0xFFFF)) return -1;
            s.pos += 4;
            if (n > s.len - s.pos || n > s.outlen - s.outpos) return -1;
            im_copy(s.out + s.outpos, s.src + s.pos, n);
            s.pos += n;
            s.outpos += n;
        } else if (type == 1) {
            if (inf_fixed(&s)) return -1;
        } else if (type == 2) {
            if (inf_dynamic(&s)) return -1;
        } else {
            return -1;
        }
    } while (!last);
    return s.outpos == outlen ? 0 : -1;
}

/* ======== PNG ======== */

typedef struct {
    uint32_t w, h;
    uint8_t depth, ct, interlace;
    int have_ihdr, have_plte, has_trns;
    uint32_t pal_n;
    uint8_t pal[256][4];
    uint32_t tr_gray;
    uint32_t tr_rgb[3];
} png_t;

static const uint8_t adam_xs[7] = {0, 4, 0, 2, 0, 1, 0};
static const uint8_t adam_ys[7] = {0, 0, 4, 0, 2, 0, 1};
static const uint8_t adam_dx[7] = {8, 8, 4, 4, 2, 2, 1};
static const uint8_t adam_dy[7] = {8, 8, 8, 4, 4, 2, 2};

static void png_pass(const png_t *c, int p, uint32_t *xs, uint32_t *ys, uint32_t *dx, uint32_t *dy,
                     uint32_t *pw, uint32_t *ph)
{
    if (c->interlace) {
        *xs = adam_xs[p];
        *ys = adam_ys[p];
        *dx = adam_dx[p];
        *dy = adam_dy[p];
        *pw = c->w > *xs ? (c->w - *xs + *dx - 1) / *dx : 0;
        *ph = c->h > *ys ? (c->h - *ys + *dy - 1) / *dy : 0;
    } else {
        *xs = 0;
        *ys = 0;
        *dx = 1;
        *dy = 1;
        *pw = c->w;
        *ph = c->h;
    }
}

static int png_scan(const uint8_t *d, size_t n, png_t *c, uint8_t *idat, size_t *idat_len)
{
    size_t pos = 8, total = 0;
    while (pos + 8 <= n) {
        uint32_t len = be32(d + pos);
        const uint8_t *t = d + pos + 4;
        const uint8_t *b = d + pos + 8;
        uint32_t i;
        if (len > n - pos - 8) return IMG_ERR_DATA;
        if (tag_is(t, "IHDR")) {
            if (len < 13) return IMG_ERR_DATA;
            c->w = be32(b);
            c->h = be32(b + 4);
            c->depth = b[8];
            c->ct = b[9];
            if (b[10] != 0 || b[11] != 0 || b[12] > 1) return IMG_ERR_UNSUPPORTED;
            c->interlace = b[12];
            c->have_ihdr = 1;
        } else if (!c->have_ihdr) {
            return IMG_ERR_DATA;
        } else if (tag_is(t, "PLTE")) {
            if (len % 3 || len > 768) return IMG_ERR_DATA;
            c->pal_n = len / 3;
            for (i = 0; i < c->pal_n; i++) {
                c->pal[i][0] = b[i * 3];
                c->pal[i][1] = b[i * 3 + 1];
                c->pal[i][2] = b[i * 3 + 2];
            }
            c->have_plte = 1;
        } else if (tag_is(t, "tRNS")) {
            if (c->ct == 0 && len >= 2) {
                c->tr_gray = be16(b);
                c->has_trns = 1;
            } else if (c->ct == 2 && len >= 6) {
                c->tr_rgb[0] = be16(b);
                c->tr_rgb[1] = be16(b + 2);
                c->tr_rgb[2] = be16(b + 4);
                c->has_trns = 1;
            } else if (c->ct == 3) {
                for (i = 0; i < len && i < 256; i++) c->pal[i][3] = b[i];
            }
        } else if (tag_is(t, "IDAT")) {
            if (idat) im_copy(idat + total, b, len);
            total += len;
        } else if (tag_is(t, "IEND")) {
            break;
        }
        pos += 12 + (size_t)len;
    }
    *idat_len = total;
    return IMG_OK;
}

static int paeth(int a, int b, int c)
{
    int p = a + b - c;
    int pa = p > a ? p - a : a - p;
    int pb = p > b ? p - b : b - p;
    int pc = p > c ? p - c : c - p;
    if (pa <= pb && pa <= pc) return a;
    if (pb <= pc) return b;
    return c;
}

static int png_unfilter(uint8_t *buf, uint32_t rows, size_t stride, int bpp)
{
    uint32_t r;
    size_t i;
    for (r = 0; r < rows; r++) {
        uint8_t *row = buf + (size_t)r * (stride + 1);
        uint8_t *cur = row + 1;
        const uint8_t *prev = r ? cur - (stride + 1) : NULL;
        int f = row[0];
        if (f > 4) return -1;
        for (i = 0; i < stride; i++) {
            int a = i >= (size_t)bpp ? cur[i - bpp] : 0;
            int b = prev ? prev[i] : 0;
            int c = (prev && i >= (size_t)bpp) ? prev[i - bpp] : 0;
            int add;
            switch (f) {
            case 1: add = a; break;
            case 2: add = b; break;
            case 3: add = (a + b) >> 1; break;
            case 4: add = paeth(a, b, c); break;
            default: add = 0; break;
            }
            cur[i] = (uint8_t)(cur[i] + add);
        }
    }
    return 0;
}

static uint32_t png_sample(const uint8_t *row, size_t idx, int depth)
{
    if (depth == 8) return row[idx];
    if (depth == 16) return ((uint32_t)row[idx * 2] << 8) | row[idx * 2 + 1];
    {
        size_t per = 8 / depth;
        uint32_t byte = row[idx / per];
        int shift = 8 - depth - (int)(idx % per) * depth;
        return (byte >> shift) & ((1u << depth) - 1);
    }
}

static uint8_t png_to8(uint32_t v, int depth)
{
    if (depth == 16) return (uint8_t)(v >> 8);
    if (depth == 8) return (uint8_t)v;
    return (uint8_t)(v * 255 / ((1u << depth) - 1));
}

static void png_pixel(const png_t *c, const uint8_t *row, uint32_t x, uint8_t *o)
{
    int dp = c->depth;
    uint32_t v, r, g, b, a;
    switch (c->ct) {
    case 0:
        v = png_sample(row, x, dp);
        o[0] = o[1] = o[2] = png_to8(v, dp);
        o[3] = (c->has_trns && v == c->tr_gray) ? 0 : 255;
        break;
    case 2:
        r = png_sample(row, (size_t)x * 3, dp);
        g = png_sample(row, (size_t)x * 3 + 1, dp);
        b = png_sample(row, (size_t)x * 3 + 2, dp);
        o[0] = png_to8(r, dp);
        o[1] = png_to8(g, dp);
        o[2] = png_to8(b, dp);
        o[3] = (c->has_trns && r == c->tr_rgb[0] && g == c->tr_rgb[1] && b == c->tr_rgb[2]) ? 0 : 255;
        break;
    case 3:
        v = png_sample(row, x, dp);
        if (v < c->pal_n) {
            o[0] = c->pal[v][0];
            o[1] = c->pal[v][1];
            o[2] = c->pal[v][2];
            o[3] = c->pal[v][3];
        } else {
            o[0] = o[1] = o[2] = 0;
            o[3] = 255;
        }
        break;
    case 4:
        g = png_sample(row, (size_t)x * 2, dp);
        a = png_sample(row, (size_t)x * 2 + 1, dp);
        o[0] = o[1] = o[2] = png_to8(g, dp);
        o[3] = png_to8(a, dp);
        break;
    default:
        r = png_sample(row, (size_t)x * 4, dp);
        g = png_sample(row, (size_t)x * 4 + 1, dp);
        b = png_sample(row, (size_t)x * 4 + 2, dp);
        a = png_sample(row, (size_t)x * 4 + 3, dp);
        o[0] = png_to8(r, dp);
        o[1] = png_to8(g, dp);
        o[2] = png_to8(b, dp);
        o[3] = png_to8(a, dp);
        break;
    }
}

int png_decode(const uint8_t *d, size_t n, image_t *out)
{
    static const uint8_t sig[8] = {137, 80, 78, 71, 13, 10, 26, 10};
    png_t c;
    size_t idat_len = 0, raw_size = 0, out_size, off, stride;
    uint8_t *idat = NULL, *raw = NULL, *pix = NULL;
    int i, r, channels, bits, bpp, np;

    if (n < 8) return IMG_ERR_FORMAT;
    for (i = 0; i < 8; i++)
        if (d[i] != sig[i]) return IMG_ERR_FORMAT;

    im_zero(&c, sizeof c);
    for (i = 0; i < 256; i++) c.pal[i][3] = 255;
    r = png_scan(d, n, &c, NULL, &idat_len);
    if (r) return r;
    if (!c.have_ihdr || idat_len == 0) return IMG_ERR_DATA;
    if (c.w == 0 || c.h == 0 || c.w > IMG_MAX_DIM || c.h > IMG_MAX_DIM) return IMG_ERR_UNSUPPORTED;

    switch (c.ct) {
    case 0:
        if (c.depth != 1 && c.depth != 2 && c.depth != 4 && c.depth != 8 && c.depth != 16) return IMG_ERR_DATA;
        channels = 1;
        break;
    case 2:
        if (c.depth != 8 && c.depth != 16) return IMG_ERR_DATA;
        channels = 3;
        break;
    case 3:
        if (c.depth != 1 && c.depth != 2 && c.depth != 4 && c.depth != 8) return IMG_ERR_DATA;
        if (!c.have_plte) return IMG_ERR_DATA;
        channels = 1;
        break;
    case 4:
        if (c.depth != 8 && c.depth != 16) return IMG_ERR_DATA;
        channels = 2;
        break;
    case 6:
        if (c.depth != 8 && c.depth != 16) return IMG_ERR_DATA;
        channels = 4;
        break;
    default:
        return IMG_ERR_DATA;
    }
    bits = channels * c.depth;
    bpp = (bits + 7) / 8;
    np = c.interlace ? 7 : 1;

    for (i = 0; i < np; i++) {
        uint32_t xs, ys, dx, dy, pw, ph;
        png_pass(&c, i, &xs, &ys, &dx, &dy, &pw, &ph);
        if (pw && ph) raw_size += (((size_t)pw * bits + 7) / 8 + 1) * ph;
    }
    if (!mul_ok((size_t)c.w * c.h, 4, &out_size)) return IMG_ERR_MEMORY;

    idat = img_malloc(idat_len);
    raw = img_malloc(raw_size);
    pix = img_malloc(out_size);
    if (!idat || !raw || !pix) {
        r = IMG_ERR_MEMORY;
        goto fail;
    }
    r = png_scan(d, n, &c, idat, &idat_len);
    if (r) goto fail;
    if (zlib_inflate(idat, idat_len, raw, raw_size)) {
        r = IMG_ERR_DATA;
        goto fail;
    }

    off = 0;
    for (i = 0; i < np; i++) {
        uint32_t xs, ys, dx, dy, pw, ph, x, y;
        png_pass(&c, i, &xs, &ys, &dx, &dy, &pw, &ph);
        if (!pw || !ph) continue;
        stride = ((size_t)pw * bits + 7) / 8;
        if (png_unfilter(raw + off, ph, stride, bpp)) {
            r = IMG_ERR_DATA;
            goto fail;
        }
        for (y = 0; y < ph; y++) {
            const uint8_t *row = raw + off + (size_t)y * (stride + 1) + 1;
            for (x = 0; x < pw; x++) {
                size_t o = ((size_t)(ys + y * dy) * c.w + (xs + x * dx)) * 4;
                png_pixel(&c, row, x, pix + o);
            }
        }
        off += (stride + 1) * ph;
    }

    img_free(idat);
    img_free(raw);
    out->width = c.w;
    out->height = c.h;
    out->pixels = pix;
    return IMG_OK;

fail:
    if (idat) img_free(idat);
    if (raw) img_free(raw);
    if (pix) img_free(pix);
    return r;
}

/* ======== JPEG ======== */

typedef struct {
    uint16_t count[17];
    uint8_t sym[256];
    int ok;
} jhuff_t;

typedef struct {
    int id, h, v, tq, td, ta, pred, qlatched;
    uint32_t bw, bh;
    int16_t *coef;
    uint8_t *plane;
    uint16_t q[64];
} jcomp_t;

typedef struct {
    uint32_t w, h, mcux, mcuy;
    int nf, progressive, hmax, vmax, ri, adobe, adobe_tf, frame, scans, eobrun;
    jcomp_t comp[3];
    jhuff_t dc[4], ac[4];
    uint16_t qt[4][64];
    int qt_ok[4];
} jpeg_t;

typedef struct {
    const uint8_t *p, *end;
    uint32_t buf;
    int cnt;
} jbits_t;

static const uint8_t zz[64] = {0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5,
                               12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28,
                               35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51,
                               58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63};

static int jb_bit(jbits_t *j)
{
    if (j->cnt == 0) {
        uint32_t b = 0;
        if (j->p < j->end) {
            b = *j->p;
            if (b == 0xFF) {
                if (j->p + 1 < j->end && j->p[1] == 0) j->p += 2;
                else b = 0;
            } else {
                j->p++;
            }
        }
        j->buf = b;
        j->cnt = 8;
    }
    j->cnt--;
    return (int)((j->buf >> j->cnt) & 1);
}

static int jb_recv(jbits_t *j, int n)
{
    int v = 0;
    while (n--) v = (v << 1) | jb_bit(j);
    return v;
}

static int jextend(int v, int n)
{
    return v < (1 << (n - 1)) ? v - (1 << n) + 1 : v;
}

static void jb_restart(jbits_t *j)
{
    j->cnt = 0;
    while (j->p + 1 < j->end) {
        if (j->p[0] == 0xFF && j->p[1] >= 0xD0 && j->p[1] <= 0xD7) {
            j->p += 2;
            break;
        }
        if (j->p[0] == 0xFF && j->p[1] != 0 && j->p[1] != 0xFF) break;
        j->p++;
    }
}

static int jh_build(jhuff_t *h, const uint8_t *counts, const uint8_t *vals, int total)
{
    int i, left = 1;
    h->count[0] = 0;
    for (i = 1; i <= 16; i++) {
        h->count[i] = counts[i - 1];
        left <<= 1;
        left -= counts[i - 1];
        if (left < 0) return -1;
    }
    for (i = 0; i < total; i++) h->sym[i] = vals[i];
    h->ok = 1;
    return 0;
}

static int jh_decode(jbits_t *b, const jhuff_t *h)
{
    int code = 0, first = 0, index = 0, len;
    if (!h->ok) return -1;
    for (len = 1; len <= 16; len++) {
        int count;
        code |= jb_bit(b);
        count = h->count[len];
        if (code - count < first) return h->sym[index + (code - first)];
        index += count;
        first += count;
        first <<= 1;
        code <<= 1;
    }
    return -1;
}

static int jblock(jpeg_t *j, jbits_t *b, jcomp_t *c, int16_t *blk, int ss, int se, int ah, int al)
{
    int k;
    if (!j->progressive) {
        int t = jh_decode(b, &j->dc[c->td]);
        if (t < 0 || t > 11) return -1;
        c->pred += t ? jextend(jb_recv(b, t), t) : 0;
        blk[0] = (int16_t)c->pred;
        for (k = 1; k < 64;) {
            int rs = jh_decode(b, &j->ac[c->ta]), rr, s;
            if (rs < 0) return -1;
            rr = rs >> 4;
            s = rs & 15;
            if (s == 0) {
                if (rr == 15) {
                    k += 16;
                    continue;
                }
                break;
            }
            k += rr;
            if (k > 63) return -1;
            blk[zz[k]] = (int16_t)jextend(jb_recv(b, s), s);
            k++;
        }
        return 0;
    }
    if (ss == 0) {
        if (ah == 0) {
            int t = jh_decode(b, &j->dc[c->td]);
            if (t < 0 || t > 11) return -1;
            c->pred += t ? jextend(jb_recv(b, t), t) : 0;
            blk[0] = (int16_t)(c->pred * (1 << al));
        } else if (jb_bit(b)) {
            blk[0] |= (int16_t)(1 << al);
        }
        return 0;
    }
    if (ah == 0) {
        if (j->eobrun > 0) {
            j->eobrun--;
            return 0;
        }
        for (k = ss; k <= se;) {
            int rs = jh_decode(b, &j->ac[c->ta]), rr, s;
            if (rs < 0) return -1;
            rr = rs >> 4;
            s = rs & 15;
            if (s == 0) {
                if (rr < 15) {
                    j->eobrun = (1 << rr) - 1;
                    if (rr) j->eobrun += jb_recv(b, rr);
                    break;
                }
                k += 16;
                continue;
            }
            k += rr;
            if (k > 63) return -1;
            blk[zz[k]] = (int16_t)(jextend(jb_recv(b, s), s) * (1 << al));
            k++;
        }
        return 0;
    }
    {
        int p1 = 1 << al, m1 = -(1 << al);
        k = ss;
        if (j->eobrun == 0) {
            for (; k <= se; k++) {
                int rs = jh_decode(b, &j->ac[c->ta]), rr, s, val = 0;
                if (rs < 0) return -1;
                rr = rs >> 4;
                s = rs & 15;
                if (s) {
                    if (s != 1) return -1;
                    val = jb_bit(b) ? p1 : m1;
                } else if (rr != 15) {
                    j->eobrun = 1 << rr;
                    if (rr) j->eobrun += jb_recv(b, rr);
                    break;
                }
                do {
                    int16_t *cf = &blk[zz[k]];
                    if (*cf != 0) {
                        if (jb_bit(b)) {
                            if ((*cf & p1) == 0) *cf = (int16_t)(*cf + (*cf >= 0 ? p1 : m1));
                        }
                    } else {
                        if (--rr < 0) break;
                    }
                    k++;
                } while (k <= se);
                if (val) {
                    if (k > se) return -1;
                    blk[zz[k]] = (int16_t)val;
                }
            }
        }
        if (j->eobrun > 0) {
            for (; k <= se; k++) {
                int16_t *cf = &blk[zz[k]];
                if (*cf != 0 && jb_bit(b)) {
                    if ((*cf & p1) == 0) *cf = (int16_t)(*cf + (*cf >= 0 ? p1 : m1));
                }
            }
            j->eobrun--;
        }
    }
    return 0;
}

static int jpeg_scan(jpeg_t *j, jbits_t *b, jcomp_t **sc, int ns, int ss, int se, int ah, int al)
{
    uint32_t nu, u, sbw = 0;
    int i;
    j->eobrun = 0;
    for (i = 0; i < ns; i++) sc[i]->pred = 0;
    if (ns == 1) {
        jcomp_t *c = sc[0];
        uint32_t cw = (j->w * (uint32_t)c->h + j->hmax - 1) / j->hmax;
        uint32_t ch = (j->h * (uint32_t)c->v + j->vmax - 1) / j->vmax;
        sbw = (cw + 7) / 8;
        nu = sbw * ((ch + 7) / 8);
    } else {
        nu = j->mcux * j->mcuy;
    }
    for (u = 0; u < nu; u++) {
        if (j->ri && u && u % (uint32_t)j->ri == 0) {
            jb_restart(b);
            for (i = 0; i < ns; i++) sc[i]->pred = 0;
            j->eobrun = 0;
        }
        if (ns == 1) {
            jcomp_t *c = sc[0];
            uint32_t bx = u % sbw, by = u / sbw;
            if (jblock(j, b, c, c->coef + ((size_t)by * c->bw + bx) * 64, ss, se, ah, al)) return -1;
        } else {
            uint32_t mx = u % j->mcux, my = u / j->mcux;
            for (i = 0; i < ns; i++) {
                jcomp_t *c = sc[i];
                int hh, vv;
                for (vv = 0; vv < c->v; vv++)
                    for (hh = 0; hh < c->h; hh++) {
                        uint32_t bx = mx * (uint32_t)c->h + hh, by = my * (uint32_t)c->v + vv;
                        if (jblock(j, b, c, c->coef + ((size_t)by * c->bw + bx) * 64, ss, se, ah, al)) return -1;
                    }
            }
        }
    }
    return 0;
}

static int jpeg_dqt(jpeg_t *j, const uint8_t *s, size_t n)
{
    while (n > 0) {
        int pq = s[0] >> 4, tq = s[0] & 15, i;
        size_t need = 1 + (size_t)64 * (pq + 1);
        if (pq > 1 || tq > 3 || n < need) return IMG_ERR_DATA;
        for (i = 0; i < 64; i++)
            j->qt[tq][zz[i]] = pq ? (uint16_t)be16(s + 1 + i * 2) : s[1 + i];
        j->qt_ok[tq] = 1;
        s += need;
        n -= need;
    }
    return IMG_OK;
}

static int jpeg_dht(jpeg_t *j, const uint8_t *s, size_t n)
{
    while (n >= 17) {
        int tc = s[0] >> 4, th = s[0] & 15, i, total = 0;
        jhuff_t *h;
        if (tc > 1 || th > 3) return IMG_ERR_DATA;
        for (i = 1; i <= 16; i++) total += s[i];
        if (total > 256 || n < (size_t)17 + total) return IMG_ERR_DATA;
        h = tc ? &j->ac[th] : &j->dc[th];
        if (jh_build(h, s + 1, s + 17, total)) return IMG_ERR_DATA;
        s += 17 + total;
        n -= 17 + total;
    }
    return IMG_OK;
}

static int jpeg_sof(jpeg_t *j, int m, const uint8_t *s, size_t n)
{
    int i;
    if (j->frame) return IMG_ERR_DATA;
    if (n < 6) return IMG_ERR_DATA;
    if (s[0] != 8) return IMG_ERR_UNSUPPORTED;
    j->h = be16(s + 1);
    j->w = be16(s + 3);
    j->nf = s[5];
    if (j->w == 0 || j->h == 0 || j->w > IMG_MAX_DIM || j->h > IMG_MAX_DIM) return IMG_ERR_UNSUPPORTED;
    if (j->nf != 1 && j->nf != 3) return IMG_ERR_UNSUPPORTED;
    if (n < (size_t)6 + 3 * j->nf) return IMG_ERR_DATA;
    j->progressive = (m == 0xC2);
    j->hmax = j->vmax = 1;
    for (i = 0; i < j->nf; i++) {
        jcomp_t *c = &j->comp[i];
        c->id = s[6 + i * 3];
        c->h = s[7 + i * 3] >> 4;
        c->v = s[7 + i * 3] & 15;
        c->tq = s[8 + i * 3];
        if (j->nf == 1) c->h = c->v = 1;
        if (c->h < 1 || c->h > 4 || c->v < 1 || c->v > 4 || c->tq > 3) return IMG_ERR_DATA;
        if (c->h > j->hmax) j->hmax = c->h;
        if (c->v > j->vmax) j->vmax = c->v;
    }
    j->mcux = (j->w + 8 * (uint32_t)j->hmax - 1) / (8 * (uint32_t)j->hmax);
    j->mcuy = (j->h + 8 * (uint32_t)j->vmax - 1) / (8 * (uint32_t)j->vmax);
    for (i = 0; i < j->nf; i++) {
        jcomp_t *c = &j->comp[i];
        size_t blocks, cbytes, pbytes;
        c->bw = j->mcux * (uint32_t)c->h;
        c->bh = j->mcuy * (uint32_t)c->v;
        if (!mul_ok((size_t)c->bw * c->bh, 64, &blocks)) return IMG_ERR_MEMORY;
        if (!mul_ok(blocks, 2, &cbytes)) return IMG_ERR_MEMORY;
        pbytes = blocks;
        c->coef = im_alloc0(cbytes);
        c->plane = img_malloc(pbytes);
        if (!c->coef || !c->plane) return IMG_ERR_MEMORY;
    }
    j->frame = 1;
    return IMG_OK;
}

static int jpeg_sos(jpeg_t *j, const uint8_t *s, size_t n, const uint8_t *data, const uint8_t *end,
                    const uint8_t **next)
{
    jcomp_t *sc[3];
    jbits_t b;
    int ns, i, k, ss, se, ah, al;
    if (!j->frame) return IMG_ERR_DATA;
    if (n < 1) return IMG_ERR_DATA;
    ns = s[0];
    if (ns < 1 || ns > j->nf || n < (size_t)1 + 2 * ns + 3) return IMG_ERR_DATA;
    for (i = 0; i < ns; i++) {
        int cs = s[1 + i * 2];
        jcomp_t *c = NULL;
        for (k = 0; k < j->nf; k++)
            if (j->comp[k].id == cs) c = &j->comp[k];
        if (!c) return IMG_ERR_DATA;
        c->td = s[2 + i * 2] >> 4;
        c->ta = s[2 + i * 2] & 15;
        if (c->td > 3 || c->ta > 3) return IMG_ERR_DATA;
        if (!c->qlatched) {
            if (!j->qt_ok[c->tq]) return IMG_ERR_DATA;
            for (k = 0; k < 64; k++) c->q[k] = j->qt[c->tq][k];
            c->qlatched = 1;
        }
        sc[i] = c;
    }
    ss = s[1 + ns * 2];
    se = s[2 + ns * 2];
    ah = s[3 + ns * 2] >> 4;
    al = s[3 + ns * 2] & 15;
    if (j->progressive) {
        if (ss > se || se > 63 || al > 13) return IMG_ERR_DATA;
        if (ss == 0 && se != 0) return IMG_ERR_DATA;
        if (ss > 0 && ns != 1) return IMG_ERR_DATA;
    }
    b.p = data;
    b.end = end;
    b.buf = 0;
    b.cnt = 0;
    j->scans++;
    jpeg_scan(j, &b, sc, ns, ss, se, ah, al);
    *next = b.p;
    return IMG_OK;
}

#define K_0541 2217
#define K_M1847 (-7568)
#define K_0765 3135
#define K_1175 4816
#define K_0298 1223
#define K_2053 8410
#define K_3072 12586
#define K_1501 6149
#define K_M0899 (-3686)
#define K_M2562 (-10498)
#define K_M1961 (-8035)
#define K_M0390 (-1598)

static void idct_1d(const int *s, int st, int *r)
{
    int p1, p2, p3, p4, p5, t0, t1, t2, t3, x0, x1, x2, x3;
    p2 = s[2 * st];
    p3 = s[6 * st];
    p1 = (p2 + p3) * K_0541;
    t2 = p1 + p3 * K_M1847;
    t3 = p1 + p2 * K_0765;
    p2 = s[0];
    p3 = s[4 * st];
    t0 = (p2 + p3) * 4096;
    t1 = (p2 - p3) * 4096;
    x0 = t0 + t3;
    x3 = t0 - t3;
    x1 = t1 + t2;
    x2 = t1 - t2;
    t0 = s[7 * st];
    t1 = s[5 * st];
    t2 = s[3 * st];
    t3 = s[st];
    p3 = t0 + t2;
    p4 = t1 + t3;
    p1 = t0 + t3;
    p2 = t1 + t2;
    p5 = (p3 + p4) * K_1175;
    t0 *= K_0298;
    t1 *= K_2053;
    t2 *= K_3072;
    t3 *= K_1501;
    p1 = p5 + p1 * K_M0899;
    p2 = p5 + p2 * K_M2562;
    p3 *= K_M1961;
    p4 *= K_M0390;
    t3 += p1 + p4;
    t2 += p2 + p3;
    t1 += p2 + p4;
    t0 += p1 + p3;
    r[0] = x0 + t3;
    r[7] = x0 - t3;
    r[1] = x1 + t2;
    r[6] = x1 - t2;
    r[2] = x2 + t1;
    r[5] = x2 - t1;
    r[3] = x3 + t0;
    r[4] = x3 - t0;
}

static uint8_t clamp8(int v)
{
    return v < 0 ? 0 : v > 255 ? 255 : (uint8_t)v;
}

static void idct_block(const int16_t *coef, const uint16_t *q, uint8_t *out, size_t stride)
{
    int in[64], tmp[64], r[8], i, k;
    for (i = 0; i < 64; i++) in[i] = coef[i] * q[i];
    for (i = 0; i < 8; i++) {
        idct_1d(in + i, 8, r);
        for (k = 0; k < 8; k++) tmp[i + k * 8] = (r[k] + 512) >> 10;
    }
    for (i = 0; i < 8; i++) {
        idct_1d(tmp + i * 8, 1, r);
        for (k = 0; k < 8; k++) out[(size_t)i * stride + k] = clamp8((r[k] + 65536 + (128 << 17)) >> 17);
    }
}

static void jpeg_free(jpeg_t *j)
{
    int i;
    for (i = 0; i < 3; i++) {
        if (j->comp[i].coef) img_free(j->comp[i].coef);
        if (j->comp[i].plane) img_free(j->comp[i].plane);
    }
    img_free(j);
}

static int jpeg_parse(jpeg_t *j, const uint8_t *d, size_t n)
{
    size_t pos = 2;
    for (;;) {
        int m, r = IMG_OK;
        size_t len;
        const uint8_t *seg;
        while (pos < n && d[pos] != 0xFF) pos++;
        while (pos < n && d[pos] == 0xFF) pos++;
        if (pos >= n) break;
        m = d[pos++];
        if (m == 0 || m == 0x01 || (m >= 0xD0 && m <= 0xD8)) continue;
        if (m == 0xD9) break;
        if (pos + 2 > n) break;
        len = be16(d + pos);
        if (len < 2 || len > n - pos) {
            if (j->frame && j->scans) break;
            return IMG_ERR_DATA;
        }
        seg = d + pos + 2;
        if (m == 0xDB) {
            r = jpeg_dqt(j, seg, len - 2);
        } else if (m == 0xC4) {
            r = jpeg_dht(j, seg, len - 2);
        } else if (m == 0xC0 || m == 0xC1 || m == 0xC2) {
            r = jpeg_sof(j, m, seg, len - 2);
        } else if (m == 0xC3 || (m >= 0xC5 && m <= 0xC7) || (m >= 0xC9 && m <= 0xCB) || (m >= 0xCD && m <= 0xCF)) {
            return IMG_ERR_UNSUPPORTED;
        } else if (m == 0xDD) {
            if (len < 4) r = IMG_ERR_DATA;
            else j->ri = (int)be16(seg);
        } else if (m == 0xEE) {
            if (len >= 14 && seg[0] == 'A' && seg[1] == 'd' && seg[2] == 'o' && seg[3] == 'b' && seg[4] == 'e') {
                j->adobe = 1;
                j->adobe_tf = seg[11];
            }
        } else if (m == 0xDA) {
            const uint8_t *next = d + pos + len;
            r = jpeg_sos(j, seg, len - 2, d + pos + len, d + n, &next);
            if (r == IMG_OK) {
                pos = (size_t)(next - d);
                continue;
            }
        }
        if (r) {
            if (j->frame && j->scans) break;
            return r;
        }
        pos += len;
    }
    return (j->frame && j->scans) ? IMG_OK : IMG_ERR_DATA;
}

static int jpeg_output(jpeg_t *j, image_t *out)
{
    size_t out_size;
    uint8_t *pix;
    uint32_t x, y;
    int i, rgb;
    for (i = 0; i < j->nf; i++) {
        jcomp_t *c = &j->comp[i];
        uint32_t bx, by;
        if (!c->qlatched) {
            for (bx = 0; bx < 64; bx++) c->q[bx] = j->qt[c->tq][bx];
        }
        for (by = 0; by < c->bh; by++)
            for (bx = 0; bx < c->bw; bx++)
                idct_block(c->coef + ((size_t)by * c->bw + bx) * 64, c->q,
                           c->plane + (size_t)by * 8 * c->bw * 8 + (size_t)bx * 8, (size_t)c->bw * 8);
    }
    if (!mul_ok((size_t)j->w * j->h, 4, &out_size)) return IMG_ERR_MEMORY;
    pix = img_malloc(out_size);
    if (!pix) return IMG_ERR_MEMORY;
    rgb = 0;
    if (j->nf == 3) {
        if (j->adobe) rgb = (j->adobe_tf == 0);
        else rgb = (j->comp[0].id == 'R' && j->comp[1].id == 'G' && j->comp[2].id == 'B');
    }
    for (y = 0; y < j->h; y++) {
        for (x = 0; x < j->w; x++) {
            int s[3] = {0, 0, 0};
            uint8_t *o = pix + ((size_t)y * j->w + x) * 4;
            for (i = 0; i < j->nf; i++) {
                jcomp_t *c = &j->comp[i];
                uint32_t sx = x * (uint32_t)c->h / (uint32_t)j->hmax;
                uint32_t sy = y * (uint32_t)c->v / (uint32_t)j->vmax;
                s[i] = c->plane[(size_t)sy * c->bw * 8 + sx];
            }
            if (j->nf == 1) {
                o[0] = o[1] = o[2] = (uint8_t)s[0];
            } else if (rgb) {
                o[0] = (uint8_t)s[0];
                o[1] = (uint8_t)s[1];
                o[2] = (uint8_t)s[2];
            } else {
                int cb = s[1] - 128, cr = s[2] - 128;
                o[0] = clamp8(s[0] + ((91881 * cr) >> 16));
                o[1] = clamp8(s[0] - ((22554 * cb + 46802 * cr) >> 16));
                o[2] = clamp8(s[0] + ((116130 * cb) >> 16));
            }
            o[3] = 255;
        }
    }
    out->width = j->w;
    out->height = j->h;
    out->pixels = pix;
    return IMG_OK;
}

int jpeg_decode(const uint8_t *d, size_t n, image_t *out)
{
    jpeg_t *j;
    int r;
    if (n < 4 || d[0] != 0xFF || d[1] != 0xD8) return IMG_ERR_FORMAT;
    j = im_alloc0(sizeof *j);
    if (!j) return IMG_ERR_MEMORY;
    r = jpeg_parse(j, d, n);
    if (r == IMG_OK) r = jpeg_output(j, out);
    jpeg_free(j);
    return r;
}

/* ======== BMP ======== */

static uint8_t bmp_chan(uint32_t v, uint32_t mask)
{
    int shift = 0, bits = 0;
    uint32_t m, val;
    if (!mask) return 0;
    while (!((mask >> shift) & 1)) shift++;
    m = mask >> shift;
    for (val = m; val; val >>= 1) bits++;
    val = (v >> shift) & m;
    if (bits >= 8) return (uint8_t)(val >> (bits - 8));
    return (uint8_t)(val * 255 / m);
}

int bmp_decode(const uint8_t *d, size_t n, image_t *out)
{
    uint32_t off, hs, w, h, bpp, comp, ncol, palsz, stride, x, y, mr, mg, mb, ma;
    int32_t sw, sh;
    int topdown, i, has_alpha = 0;
    uint8_t pal[256][4];
    size_t out_size, need;
    uint8_t *pix;

    if (n < 26 || d[0] != 'B' || d[1] != 'M') return IMG_ERR_FORMAT;
    off = le32(d + 10);
    hs = le32(d + 14);
    if (hs == 12) {
        sw = (int32_t)le16(d + 18);
        sh = (int32_t)le16(d + 20);
        bpp = le16(d + 24);
        comp = 0;
        ncol = 0;
        palsz = 3;
    } else if (hs >= 40 && n >= 14 + (size_t)hs) {
        sw = (int32_t)le32(d + 18);
        sh = (int32_t)le32(d + 22);
        bpp = le16(d + 28);
        comp = le32(d + 30);
        ncol = le32(d + 46);
        palsz = 4;
    } else {
        return IMG_ERR_DATA;
    }
    topdown = sh < 0;
    w = sw < 0 ? 0 : (uint32_t)sw;
    h = topdown ? (uint32_t)(-sh) : (uint32_t)sh;
    if (w == 0 || h == 0 || w > IMG_MAX_DIM || h > IMG_MAX_DIM) return IMG_ERR_UNSUPPORTED;
    if (bpp != 1 && bpp != 4 && bpp != 8 && bpp != 16 && bpp != 24 && bpp != 32) return IMG_ERR_UNSUPPORTED;
    if (comp != 0 && comp != 3 && comp != 6) return IMG_ERR_UNSUPPORTED;
    if (comp != 0 && bpp != 16 && bpp != 32) return IMG_ERR_UNSUPPORTED;

    mr = bpp == 16 ? 0x7C00 : 0xFF0000;
    mg = bpp == 16 ? 0x03E0 : 0x00FF00;
    mb = bpp == 16 ? 0x001F : 0x0000FF;
    ma = 0;
    if (comp != 0) {
        if (n < 66 || (hs == 40 && n < 14 + 40 + 12)) return IMG_ERR_DATA;
        mr = le32(d + 54);
        mg = le32(d + 58);
        mb = le32(d + 62);
        if ((hs >= 56 || comp == 6) && n >= 70) ma = le32(d + 66);
    }
    has_alpha = ma != 0;

    for (i = 0; i < 256; i++) pal[i][0] = pal[i][1] = pal[i][2] = 0, pal[i][3] = 255;
    if (bpp <= 8) {
        size_t pstart = 14 + (size_t)hs;
        uint32_t cnt = ncol ? ncol : (1u << bpp);
        if (cnt > 256) cnt = 256;
        if (pstart > n || (size_t)cnt * palsz > n - pstart) return IMG_ERR_DATA;
        for (i = 0; i < (int)cnt; i++) {
            const uint8_t *e = d + pstart + (size_t)i * palsz;
            pal[i][0] = e[2];
            pal[i][1] = e[1];
            pal[i][2] = e[0];
        }
    }

    stride = ((w * bpp + 31) / 32) * 4;
    if (!mul_ok(stride, h, &need)) return IMG_ERR_MEMORY;
    if (off > n || need > n - off) return IMG_ERR_DATA;
    if (!mul_ok((size_t)w * h, 4, &out_size)) return IMG_ERR_MEMORY;
    pix = img_malloc(out_size);
    if (!pix) return IMG_ERR_MEMORY;

    for (y = 0; y < h; y++) {
        const uint8_t *row = d + off + (size_t)(topdown ? y : h - 1 - y) * stride;
        for (x = 0; x < w; x++) {
            uint8_t *o = pix + ((size_t)y * w + x) * 4;
            if (bpp <= 8) {
                uint32_t per = 8 / bpp;
                uint32_t byte = row[x / per];
                uint32_t idx = (byte >> (8 - bpp - (x % per) * bpp)) & ((1u << bpp) - 1);
                o[0] = pal[idx][0];
                o[1] = pal[idx][1];
                o[2] = pal[idx][2];
                o[3] = 255;
            } else if (bpp == 24) {
                o[0] = row[x * 3 + 2];
                o[1] = row[x * 3 + 1];
                o[2] = row[x * 3];
                o[3] = 255;
            } else {
                uint32_t v = bpp == 16 ? le16(row + x * 2) : le32(row + x * 4);
                o[0] = bmp_chan(v, mr);
                o[1] = bmp_chan(v, mg);
                o[2] = bmp_chan(v, mb);
                o[3] = has_alpha ? bmp_chan(v, ma) : 255;
            }
        }
    }
    out->width = w;
    out->height = h;
    out->pixels = pix;
    return IMG_OK;
}

/* ======== TrueType ======== */

#define TTF_MAX_PIXELS 1024
#define TTF_MAX_BITMAP 4096
#define TTF_MAX_POINTS 200000
#define TTF_MAX_DEPTH 6
#define TTF_MAX_COMPONENTS 64

typedef struct {
    int32_t x, y;
    uint8_t on;
} pt_t;

typedef struct {
    pt_t *pts;
    uint32_t np, cap;
    uint32_t *ends;
    uint32_t nc, capc;
} outline_t;

typedef struct {
    int32_t *a;
    int stride;
    int w, h;
} accum_t;

static int rd_ok(const ttf_font_t *f, uint32_t off, uint32_t n)
{
    return (uint64_t)off + n <= f->size;
}

static uint32_t rd16(const ttf_font_t *f, uint32_t off)
{
    return rd_ok(f, off, 2) ? be16(f->data + off) : 0;
}

static int32_t rds16(const ttf_font_t *f, uint32_t off)
{
    return (int16_t)rd16(f, off);
}

static uint32_t rd32(const ttf_font_t *f, uint32_t off)
{
    return rd_ok(f, off, 4) ? be32(f->data + off) : 0;
}

int ttf_load(const uint8_t *d, size_t n, ttf_font_t *f)
{
    uint32_t base = 0, nt, i, off, len, best = 0, nsub, score, sub, fmt;
    int have_cff = 0;

    im_zero(f, sizeof *f);
    if (n < 12) return TTF_ERR_FORMAT;
    if (tag_is(d, "ttcf")) {
        if (n < 16) return TTF_ERR_FORMAT;
        base = be32(d + 12);
        if (base > n - 12) return TTF_ERR_DATA;
    }
    if (tag_is(d + base, "OTTO")) return TTF_ERR_UNSUPPORTED;
    if (be32(d + base) != 0x00010000u && !tag_is(d + base, "true")) return TTF_ERR_FORMAT;
    nt = be16(d + base + 4);
    if ((uint64_t)base + 12 + (uint64_t)nt * 16 > n) return TTF_ERR_DATA;
    f->data = d;
    f->size = n;
    for (i = 0; i < nt; i++) {
        const uint8_t *r = d + base + 12 + i * 16;
        off = be32(r + 8);
        len = be32(r + 12);
        if ((uint64_t)off + len > n) continue;
        if (tag_is(r, "glyf")) { f->glyf = off; f->glyf_len = len; }
        else if (tag_is(r, "loca")) { f->loca = off; f->loca_len = len; }
        else if (tag_is(r, "head")) { f->head = off; }
        else if (tag_is(r, "hhea")) { f->hhea = off; }
        else if (tag_is(r, "hmtx")) { f->hmtx = off; f->hmtx_len = len; }
        else if (tag_is(r, "maxp")) { f->maxp = off; }
        else if (tag_is(r, "cmap")) { f->cmap = off; f->cmap_len = len; }
        else if (tag_is(r, "kern")) { f->kern = off; f->kern_len = len; }
        else if (tag_is(r, "CFF ") || tag_is(r, "CFF2")) have_cff = 1;
    }
    if (!f->glyf || !f->loca) return have_cff ? TTF_ERR_UNSUPPORTED : TTF_ERR_DATA;
    if (!f->head || !f->hhea || !f->hmtx || !f->maxp || !f->cmap) return TTF_ERR_DATA;

    f->units_per_em = rd16(f, f->head + 18);
    if (f->units_per_em < 16 || f->units_per_em > 16384) return TTF_ERR_DATA;
    f->loca_long = rds16(f, f->head + 50) != 0;
    f->num_glyphs = rd16(f, f->maxp + 4);
    if (f->num_glyphs == 0) return TTF_ERR_DATA;
    f->ascent = (int)rds16(f, f->hhea + 4);
    f->descent = (int)rds16(f, f->hhea + 6);
    f->line_gap = (int)rds16(f, f->hhea + 8);
    f->num_hmetrics = rd16(f, f->hhea + 34);
    if (f->num_hmetrics == 0 || f->num_hmetrics > f->num_glyphs) return TTF_ERR_DATA;
    if ((uint64_t)f->num_hmetrics * 4 > f->hmtx_len) return TTF_ERR_DATA;
    if ((uint64_t)(f->num_glyphs + 1) * (f->loca_long ? 4 : 2) > f->loca_len) return TTF_ERR_DATA;

    nsub = rd16(f, f->cmap + 2);
    for (i = 0; i < nsub; i++) {
        uint32_t rec = f->cmap + 4 + i * 8;
        uint32_t plat = rd16(f, rec), enc = rd16(f, rec + 2), so = rd32(f, rec + 4);
        if (!rd_ok(f, rec, 8) || so >= f->cmap_len) continue;
        sub = f->cmap + so;
        fmt = rd16(f, sub);
        if (fmt != 0 && fmt != 4 && fmt != 6 && fmt != 12) continue;
        score = 0;
        if (plat == 3 && enc == 10) score = 6;
        else if (plat == 0 && (enc == 4 || enc == 6)) score = 5;
        else if (plat == 3 && enc == 1) score = 4;
        else if (plat == 0) score = 3;
        else if (plat == 1 && enc == 0) score = 1;
        if (score > best) {
            best = score;
            f->cmap_sub = sub;
            f->cmap_fmt = fmt;
        }
    }
    if (!best) return TTF_ERR_UNSUPPORTED;
    return TTF_OK;
}

uint32_t ttf_glyph_index(const ttf_font_t *f, uint32_t cp)
{
    uint32_t s = f->cmap_sub, g = 0;

    if (!s) return 0;
    switch (f->cmap_fmt) {
    case 0:
        if (cp < 256 && rd_ok(f, s + 6 + cp, 1)) g = f->data[s + 6 + cp];
        break;
    case 6: {
        uint32_t first = rd16(f, s + 6), count = rd16(f, s + 8);
        if (cp >= first && cp - first < count) g = rd16(f, s + 10 + 2 * (cp - first));
        break;
    }
    case 4: {
        uint32_t segx2 = rd16(f, s + 6), segs = segx2 / 2, lo = 0, hi = segs, mid;
        uint32_t endc = s + 14, startc = s + 16 + segx2, delta = s + 16 + 2 * segx2, ro = s + 16 + 3 * segx2;
        uint32_t start, roff, dv;
        if (cp > 0xFFFF || segs == 0) break;
        while (lo < hi) {
            mid = (lo + hi) / 2;
            if (rd16(f, endc + 2 * mid) < cp) lo = mid + 1;
            else hi = mid;
        }
        if (lo >= segs) break;
        start = rd16(f, startc + 2 * lo);
        if (cp < start) break;
        dv = rd16(f, delta + 2 * lo);
        roff = rd16(f, ro + 2 * lo);
        if (roff == 0) {
            g = (cp + dv) & 0xFFFF;
        } else {
            g = rd16(f, ro + 2 * lo + roff + 2 * (cp - start));
            if (g) g = (g + dv) & 0xFFFF;
        }
        break;
    }
    case 12: {
        uint32_t ng = rd32(f, s + 12), lo = 0, hi = ng, mid, gs, ge, sg;
        if (!rd_ok(f, s + 16, 0) || (uint64_t)ng * 12 + s + 16 > f->size) break;
        while (lo < hi) {
            mid = (lo + hi) / 2;
            if (rd32(f, s + 16 + mid * 12 + 4) < cp) lo = mid + 1;
            else hi = mid;
        }
        if (lo >= ng) break;
        gs = rd32(f, s + 16 + lo * 12);
        ge = rd32(f, s + 16 + lo * 12 + 4);
        sg = rd32(f, s + 16 + lo * 12 + 8);
        if (cp >= gs && cp <= ge) g = sg + (cp - gs);
        break;
    }
    default:
        break;
    }
    if (g >= f->num_glyphs) return 0;
    return g;
}

int ttf_advance_units(const ttf_font_t *f, uint32_t g)
{
    uint32_t idx;

    if (g >= f->num_glyphs) return 0;
    idx = g < f->num_hmetrics ? g : f->num_hmetrics - 1;
    if (idx * 4 + 2 > f->hmtx_len) return 0;
    return (int)rd16(f, f->hmtx + idx * 4);
}

int ttf_kern_units(const ttf_font_t *f, uint32_t l, uint32_t r)
{
    uint32_t nt, i, p, end, total = 0;
    int sum = 0;

    if (!f->kern || f->kern_len < 4) return 0;
    nt = rd16(f, f->kern + 2);
    p = f->kern + 4;
    end = f->kern + f->kern_len;
    for (i = 0; i < nt && p + 6 <= end; i++) {
        uint32_t len = rd16(f, p + 2), cov = rd16(f, p + 4);
        if (len < 14) break;
        if ((cov >> 8) == 0 && (cov & 1)) {
            uint32_t np = rd16(f, p + 6), lo = 0, hi = np, mid, key = (l << 16) | r, k;
            if ((uint64_t)p + 14 + (uint64_t)np * 6 <= end) {
                while (lo < hi) {
                    mid = (lo + hi) / 2;
                    k = rd32(f, p + 14 + mid * 6);
                    if (k < key) lo = mid + 1;
                    else hi = mid;
                }
                if (lo < np && rd32(f, p + 14 + lo * 6) == key) sum += (int)rds16(f, p + 14 + lo * 6 + 4);
            }
        }
        total += len;
        p += len;
    }
    (void)total;
    return sum;
}

int ttf_scale_units(const ttf_font_t *f, int units, uint32_t px)
{
    int64_t v = (int64_t)units * (int64_t)px;
    int64_t h = (int64_t)f->units_per_em / 2;

    if (v < 0) return (int)((v - h) / (int64_t)f->units_per_em);
    return (int)((v + h) / (int64_t)f->units_per_em);
}

static int grow_pts(outline_t *o, uint32_t need)
{
    uint32_t ncap;
    pt_t *np;

    if ((uint64_t)o->np + need > TTF_MAX_POINTS) return 0;
    if (o->np + need <= o->cap) return 1;
    ncap = o->cap ? o->cap : 256;
    while (ncap < o->np + need) ncap *= 2;
    np = img_malloc((size_t)ncap * sizeof(pt_t));
    if (!np) return 0;
    if (o->pts) {
        im_copy(np, o->pts, (size_t)o->np * sizeof(pt_t));
        img_free(o->pts);
    }
    o->pts = np;
    o->cap = ncap;
    return 1;
}

static int grow_ends(outline_t *o, uint32_t need)
{
    uint32_t ncap;
    uint32_t *ne;

    if (o->nc + need <= o->capc) return 1;
    ncap = o->capc ? o->capc : 32;
    while (ncap < o->nc + need) ncap *= 2;
    ne = img_malloc((size_t)ncap * sizeof(uint32_t));
    if (!ne) return 0;
    if (o->ends) {
        im_copy(ne, o->ends, (size_t)o->nc * sizeof(uint32_t));
        img_free(o->ends);
    }
    o->ends = ne;
    o->capc = ncap;
    return 1;
}

static int glyph_range(const ttf_font_t *f, uint32_t g, uint32_t *off, uint32_t *len)
{
    uint32_t a, b;

    if (g >= f->num_glyphs) return 0;
    if (f->loca_long) {
        a = rd32(f, f->loca + 4 * g);
        b = rd32(f, f->loca + 4 * g + 4);
    } else {
        a = rd16(f, f->loca + 2 * g) * 2;
        b = rd16(f, f->loca + 2 * g + 2) * 2;
    }
    if (b < a || b > f->glyf_len) return 0;
    *off = f->glyf + a;
    *len = b - a;
    return 1;
}

static int load_simple(const ttf_font_t *f, uint32_t g, uint32_t len, int nc, outline_t *o)
{
    const uint8_t *d = f->data + g;
    const uint8_t *p = d + 10, *end = d + len;
    uint32_t npts, i, base = o->np, ins;
    uint32_t prev = 0;
    int32_t v;

    if ((uint64_t)nc * 2 + 12 > len) return TTF_ERR_DATA;
    for (i = 0; i < (uint32_t)nc; i++) {
        uint32_t e = be16(p + i * 2);
        if (i && e < prev) return TTF_ERR_DATA;
        prev = e;
    }
    npts = prev + 1;
    p += (size_t)nc * 2;
    ins = be16(p);
    p += 2;
    if ((size_t)(end - p) < ins) return TTF_ERR_DATA;
    p += ins;
    if (!grow_pts(o, npts) || !grow_ends(o, (uint32_t)nc)) return TTF_ERR_MEMORY;

    i = 0;
    while (i < npts) {
        uint8_t fl;
        if (p >= end) return TTF_ERR_DATA;
        fl = *p++;
        o->pts[base + i++].on = fl;
        if (fl & 8) {
            uint32_t rep;
            if (p >= end) return TTF_ERR_DATA;
            rep = *p++;
            while (rep-- && i < npts) o->pts[base + i++].on = fl;
        }
    }
    v = 0;
    for (i = 0; i < npts; i++) {
        uint8_t fl = o->pts[base + i].on;
        if (fl & 2) {
            if (p >= end) return TTF_ERR_DATA;
            v += (fl & 16) ? (int32_t)*p : -(int32_t)*p;
            p++;
        } else if (!(fl & 16)) {
            if (end - p < 2) return TTF_ERR_DATA;
            v += (int16_t)be16(p);
            p += 2;
        }
        o->pts[base + i].x = v;
    }
    v = 0;
    for (i = 0; i < npts; i++) {
        uint8_t fl = o->pts[base + i].on;
        if (fl & 4) {
            if (p >= end) return TTF_ERR_DATA;
            v += (fl & 32) ? (int32_t)*p : -(int32_t)*p;
            p++;
        } else if (!(fl & 32)) {
            if (end - p < 2) return TTF_ERR_DATA;
            v += (int16_t)be16(p);
            p += 2;
        }
        o->pts[base + i].y = v;
    }
    for (i = 0; i < npts; i++) o->pts[base + i].on &= 1;
    for (i = 0; i < (uint32_t)nc; i++) o->ends[o->nc++] = base + be16(d + 10 + i * 2);
    o->np += npts;
    return TTF_OK;
}

static int load_glyph(const ttf_font_t *f, uint32_t g, int depth, outline_t *o)
{
    uint32_t off, len;
    const uint8_t *d;
    int nc;

    if (depth > TTF_MAX_DEPTH) return TTF_ERR_DATA;
    if (!glyph_range(f, g, &off, &len)) return TTF_ERR_DATA;
    if (len == 0) return TTF_OK;
    if (len < 10) return TTF_ERR_DATA;
    d = f->data + off;
    nc = (int16_t)be16(d);
    if (nc >= 0) {
        if (nc == 0) return TTF_OK;
        return load_simple(f, off, len, nc, o);
    } else {
        const uint8_t *p = d + 10, *end = d + len;
        uint32_t fl, count = 0;
        do {
            int32_t m[4] = {0x4000, 0, 0, 0x4000}, dx, dy;
            uint32_t cg, start = o->np, i;
            int r;
            if (end - p < 4 || ++count > TTF_MAX_COMPONENTS) return TTF_ERR_DATA;
            fl = be16(p);
            cg = be16(p + 2);
            p += 4;
            if (fl & 1) {
                if (end - p < 4) return TTF_ERR_DATA;
                dx = (int16_t)be16(p);
                dy = (int16_t)be16(p + 2);
                p += 4;
            } else {
                if (end - p < 2) return TTF_ERR_DATA;
                dx = (int8_t)p[0];
                dy = (int8_t)p[1];
                p += 2;
            }
            if (!(fl & 2)) { dx = 0; dy = 0; }
            if (fl & 8) {
                if (end - p < 2) return TTF_ERR_DATA;
                m[0] = m[3] = (int16_t)be16(p);
                p += 2;
            } else if (fl & 0x40) {
                if (end - p < 4) return TTF_ERR_DATA;
                m[0] = (int16_t)be16(p);
                m[3] = (int16_t)be16(p + 2);
                p += 4;
            } else if (fl & 0x80) {
                if (end - p < 8) return TTF_ERR_DATA;
                m[0] = (int16_t)be16(p);
                m[1] = (int16_t)be16(p + 2);
                m[2] = (int16_t)be16(p + 4);
                m[3] = (int16_t)be16(p + 6);
                p += 8;
            }
            r = load_glyph(f, cg, depth + 1, o);
            if (r != TTF_OK) return r;
            for (i = start; i < o->np; i++) {
                int64_t x = o->pts[i].x, y = o->pts[i].y;
                o->pts[i].x = (int32_t)((x * m[0] + y * m[2]) >> 14) + dx;
                o->pts[i].y = (int32_t)((x * m[1] + y * m[3]) >> 14) + dy;
            }
        } while (fl & 0x20);
    }
    return TTF_OK;
}

static void acc_line(const accum_t *c, int32_t ax, int32_t ay, int32_t bx, int32_t by)
{
    int dir = 1, y;
    int64_t x, dxdy, wmax = (int64_t)c->w * 65536;
    int32_t *a = c->a;

    if (ay == by) return;
    if (ay > by) {
        int32_t t = ax; ax = bx; bx = t;
        t = ay; ay = by; by = t;
        dir = -1;
    }
    dxdy = ((int64_t)(bx - ax) * 65536) / (int64_t)(by - ay);
    x = ax;
    y = 0;
    if (ay < 0) x += ((int64_t)(-ay) * dxdy) >> 16;
    else y = ay >> 16;
    for (; y < c->h && ((int64_t)y * 65536) < by; y++) {
        int32_t top = (int32_t)((int64_t)y * 65536), bot = (int32_t)(((int64_t)y + 1) * 65536), dy, d;
        int64_t xn, xa, xb, x0, x1;
        int x0i, x1i;
        int32_t *row = a + (size_t)y * c->stride;

        if (top < ay) top = ay;
        if (bot > by) bot = by;
        dy = bot - top;
        xn = x + ((dxdy * dy) >> 16);
        xa = x < 0 ? 0 : (x > wmax ? wmax : x);
        xb = xn < 0 ? 0 : (xn > wmax ? wmax : xn);
        d = dir > 0 ? dy : -dy;
        if (xa < xb) { x0 = xa; x1 = xb; }
        else { x0 = xb; x1 = xa; }
        x0i = (int)(x0 >> 16);
        x1i = (int)((x1 + 0xFFFF) >> 16);
        if (x1i <= x0i + 1) {
            int64_t xmf = ((xa + xb) >> 1) - (int64_t)x0i * 65536;
            row[x0i] += d - (int32_t)(((int64_t)d * xmf) >> 16);
            row[x0i + 1] += (int32_t)(((int64_t)d * xmf) >> 16);
        } else {
            int64_t s = ((int64_t)1 << 32) / (x1 - x0);
            int64_t x0f = x0 - (int64_t)x0i * 65536;
            int64_t u = 65536 - x0f;
            int64_t a0 = (((s * u) >> 16) * u) >> 17;
            int64_t x1f = x1 - (int64_t)x1i * 65536 + 65536;
            int64_t am = (((s * x1f) >> 16) * x1f) >> 17;
            row[x0i] += (int32_t)(((int64_t)d * a0) >> 16);
            if (x1i == x0i + 2) {
                row[x0i + 1] += (int32_t)(((int64_t)d * (65536 - a0 - am)) >> 16);
            } else {
                int64_t a1 = (s * (98304 - x0f)) >> 16;
                int xi;
                int64_t a2;
                row[x0i + 1] += (int32_t)(((int64_t)d * (a1 - a0)) >> 16);
                for (xi = x0i + 2; xi < x1i - 1; xi++) row[xi] += (int32_t)(((int64_t)d * s) >> 16);
                a2 = a1 + (int64_t)(x1i - x0i - 3) * s;
                row[x1i - 1] += (int32_t)(((int64_t)d * (65536 - a2 - am)) >> 16);
            }
            row[x1i] += (int32_t)(((int64_t)d * am) >> 16);
        }
        x = xn;
    }
}

typedef struct {
    int32_t x, y;
} fpt_t;

static void acc_quad(const accum_t *c, fpt_t p0, fpt_t p1, fpt_t p2)
{
    int64_t dx = (int64_t)p0.x - 2 * (int64_t)p1.x + p2.x;
    int64_t dy = (int64_t)p0.y - 2 * (int64_t)p1.y + p2.y;
    int64_t dd;
    int n = 1, i;
    fpt_t prev = p0;

    if (dx < 0) dx = -dx;
    if (dy < 0) dy = -dy;
    dd = dx > dy ? dx : dy;
    while (n < 64 && (int64_t)n * n * 16384 < dd) n++;
    for (i = 1; i <= n; i++) {
        int64_t a = (int64_t)(n - i) * (n - i), b = 2 * (int64_t)i * (n - i), cc = (int64_t)i * i, nn = (int64_t)n * n;
        fpt_t q;
        q.x = (int32_t)((a * p0.x + b * p1.x + cc * p2.x) / nn);
        q.y = (int32_t)((a * p0.y + b * p1.y + cc * p2.y) / nn);
        acc_line(c, prev.x, prev.y, q.x, q.y);
        prev = q;
    }
}

static fpt_t conv(const pt_t *p, int64_t scale, int32_t left, int32_t top)
{
    fpt_t r;
    r.x = (int32_t)((int64_t)p->x * scale - (int64_t)left * 65536);
    r.y = (int32_t)((int64_t)top * 65536 - (int64_t)p->y * scale);
    return r;
}

static void flatten(const accum_t *c, const pt_t *p, uint32_t n, int64_t scale, int32_t left, int32_t top)
{
    fpt_t start, cur, ctl, q;
    uint32_t first, last, i;
    int have_ctl = 0;

    if (n < 2) return;
    if (p[0].on) {
        start = conv(&p[0], scale, left, top);
        first = 1;
        last = n - 1;
    } else if (p[n - 1].on) {
        start = conv(&p[n - 1], scale, left, top);
        first = 0;
        last = n - 2;
    } else {
        fpt_t a = conv(&p[0], scale, left, top), b = conv(&p[n - 1], scale, left, top);
        start.x = (int32_t)(((int64_t)a.x + b.x) / 2);
        start.y = (int32_t)(((int64_t)a.y + b.y) / 2);
        first = 0;
        last = n - 1;
    }
    cur = start;
    ctl.x = ctl.y = 0;
    for (i = first; i <= last; i++) {
        q = conv(&p[i], scale, left, top);
        if (p[i].on) {
            if (have_ctl) acc_quad(c, cur, ctl, q);
            else acc_line(c, cur.x, cur.y, q.x, q.y);
            cur = q;
            have_ctl = 0;
        } else {
            if (have_ctl) {
                fpt_t m;
                m.x = (int32_t)(((int64_t)ctl.x + q.x) / 2);
                m.y = (int32_t)(((int64_t)ctl.y + q.y) / 2);
                acc_quad(c, cur, ctl, m);
                cur = m;
            }
            ctl = q;
            have_ctl = 1;
        }
    }
    if (have_ctl) acc_quad(c, cur, ctl, start);
    else acc_line(c, cur.x, cur.y, start.x, start.y);
}

static int32_t floor_px(int64_t v)
{
    return (int32_t)(v >> 16);
}

static int32_t ceil_px(int64_t v)
{
    return (int32_t)((v + 0xFFFF) >> 16);
}

int ttf_render_glyph(const ttf_font_t *f, uint32_t glyph, uint32_t px, ttf_bitmap_t *out)
{
    outline_t o;
    int r;
    int64_t scale;
    int32_t minx, maxx, miny, maxy, left, right, top, bottom;
    uint32_t i, w, h, cs, c, x, y;
    size_t cells;
    accum_t ac;

    im_zero(out, sizeof *out);
    if (px < 1 || px > TTF_MAX_PIXELS) return TTF_ERR_UNSUPPORTED;
    out->advance = ttf_scale_units(f, ttf_advance_units(f, glyph), px);
    im_zero(&o, sizeof o);
    r = load_glyph(f, glyph, 0, &o);
    if (r != TTF_OK || o.np == 0 || o.nc == 0) {
        if (o.pts) img_free(o.pts);
        if (o.ends) img_free(o.ends);
        return r;
    }
    scale = ((int64_t)px * 65536) / (int64_t)f->units_per_em;
    minx = maxx = o.pts[0].x;
    miny = maxy = o.pts[0].y;
    for (i = 1; i < o.np; i++) {
        if (o.pts[i].x < minx) minx = o.pts[i].x;
        if (o.pts[i].x > maxx) maxx = o.pts[i].x;
        if (o.pts[i].y < miny) miny = o.pts[i].y;
        if (o.pts[i].y > maxy) maxy = o.pts[i].y;
    }
    left = floor_px((int64_t)minx * scale);
    right = ceil_px((int64_t)maxx * scale);
    bottom = floor_px((int64_t)miny * scale);
    top = ceil_px((int64_t)maxy * scale);
    w = (uint32_t)(right - left) + 1;
    h = (uint32_t)(top - bottom) + 1;
    if (w > TTF_MAX_BITMAP || h > TTF_MAX_BITMAP) {
        img_free(o.pts);
        img_free(o.ends);
        return TTF_ERR_UNSUPPORTED;
    }
    if (!mul_ok((size_t)(w + 2), (size_t)h * sizeof(int32_t), &cells)) {
        img_free(o.pts);
        img_free(o.ends);
        return TTF_ERR_MEMORY;
    }
    ac.a = im_alloc0(cells);
    out->pixels = img_malloc((size_t)w * h);
    if (!ac.a || !out->pixels) {
        if (ac.a) img_free(ac.a);
        if (out->pixels) img_free(out->pixels);
        out->pixels = 0;
        img_free(o.pts);
        img_free(o.ends);
        return TTF_ERR_MEMORY;
    }
    ac.stride = (int)(w + 2);
    ac.w = (int)w;
    ac.h = (int)h;
    cs = 0;
    for (c = 0; c < o.nc; c++) {
        uint32_t ce = o.ends[c];
        if (ce >= o.np || ce < cs) break;
        flatten(&ac, o.pts + cs, ce - cs + 1, scale, left, top);
        cs = ce + 1;
    }
    for (y = 0; y < h; y++) {
        int32_t sum = 0;
        const int32_t *row = ac.a + (size_t)y * ac.stride;
        for (x = 0; x < w; x++) {
            int32_t v;
            sum += row[x];
            v = sum < 0 ? -sum : sum;
            if (v > 65536) v = 65536;
            out->pixels[(size_t)y * w + x] = (uint8_t)((v * 255 + 32768) >> 16);
        }
    }
    out->width = w;
    out->height = h;
    out->left = left;
    out->top = top;
    img_free(ac.a);
    img_free(o.pts);
    img_free(o.ends);
    return TTF_OK;
}

void ttf_bitmap_free(ttf_bitmap_t *bmp)
{
    if (bmp->pixels) img_free(bmp->pixels);
    bmp->pixels = 0;
    bmp->width = bmp->height = 0;
}

/* ======== format detection and memory ======== */

#ifdef IMGDEC_USE_LIBC
#include <stdlib.h>
void *img_malloc(size_t size) { return malloc(size); }
void img_free(void *ptr) { free(ptr); }
#endif

int image_decode(const uint8_t *d, size_t n, image_t *out)
{
    if (n >= 8 && d[0] == 137 && d[1] == 80 && d[2] == 78 && d[3] == 71) return png_decode(d, n, out);
    if (n >= 3 && d[0] == 0xFF && d[1] == 0xD8) return jpeg_decode(d, n, out);
    if (n >= 2 && d[0] == 'B' && d[1] == 'M') return bmp_decode(d, n, out);
    return IMG_ERR_FORMAT;
}

void image_free(image_t *img)
{
    if (img->pixels) img_free(img->pixels);
    img->pixels = NULL;
    img->width = 0;
    img->height = 0;
}

void image_blit(uint32_t *fb, uint32_t pitch_px, uint32_t fb_w, uint32_t fb_h,
                int32_t x0, int32_t y0, const image_t *img)
{
    uint32_t x, y;
    for (y = 0; y < img->height; y++) {
        int32_t ty = y0 + (int32_t)y;
        if (ty < 0 || (uint32_t)ty >= fb_h) continue;
        for (x = 0; x < img->width; x++) {
            int32_t tx = x0 + (int32_t)x;
            const uint8_t *px;
            uint32_t a, *dst;
            if (tx < 0 || (uint32_t)tx >= fb_w) continue;
            px = img->pixels + ((size_t)y * img->width + x) * 4;
            a = px[3];
            if (a == 0) continue;
            dst = fb + (size_t)ty * pitch_px + tx;
            if (a == 255) {
                *dst = ((uint32_t)px[0] << 16) | ((uint32_t)px[1] << 8) | px[2];
            } else {
                uint32_t d = *dst;
                uint32_t dr = (d >> 16) & 255, dg = (d >> 8) & 255, db = d & 255;
                uint32_t r = (px[0] * a + dr * (255 - a) + 127) / 255;
                uint32_t g = (px[1] * a + dg * (255 - a) + 127) / 255;
                uint32_t b = (px[2] * a + db * (255 - a) + 127) / 255;
                *dst = (r << 16) | (g << 8) | b;
            }
        }
    }
}

