#!/bin/bash
set -e
cd "$(dirname "$(readlink -f "$0")")"
"${CC:-cc}" -O2 -Wall -Wextra -std=c11 -c decoders.c -o decoders.o
echo "Done: decoders.o (define IMGDEC_USE_LIBC to use malloc/free)"
