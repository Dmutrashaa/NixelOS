#ifndef NX_DECODERS_H
#define NX_DECODERS_H

#include <stddef.h>
#include <stdint.h>

/* ---- images (PNG, JPEG, BMP) ---- */
#define IMG_OK 0
#define IMG_ERR_FORMAT 1
#define IMG_ERR_DATA 2
#define IMG_ERR_MEMORY 3
#define IMG_ERR_UNSUPPORTED 4

typedef struct {
    uint32_t width;
    uint32_t height;
    uint8_t *pixels;
} image_t;

void *img_malloc(size_t size);
void img_free(void *ptr);

int png_decode(const uint8_t *data, size_t size, image_t *out);
int jpeg_decode(const uint8_t *data, size_t size, image_t *out);
int bmp_decode(const uint8_t *data, size_t size, image_t *out);
int image_decode(const uint8_t *data, size_t size, image_t *out);
void image_free(image_t *img);

void image_blit(uint32_t *fb, uint32_t pitch_px, uint32_t fb_w, uint32_t fb_h,
                int32_t x, int32_t y, const image_t *img);

/* ---- internal helpers shared by the decoders ---- */
#define IMG_MAX_DIM 16384

static inline void im_zero(void *p, size_t n)
{
    uint8_t *b = p;
    while (n--) *b++ = 0;
}

static inline void im_copy(void *d, const void *s, size_t n)
{
    uint8_t *a = d;
    const uint8_t *b = s;
    while (n--) *a++ = *b++;
}

static inline void *im_alloc0(size_t n)
{
    void *p = img_malloc(n);
    if (p) im_zero(p, n);
    return p;
}

static inline int mul_ok(size_t a, size_t b, size_t *r)
{
    if (a && b > (size_t)-1 / a) return 0;
    *r = a * b;
    return 1;
}

static inline uint32_t be16(const uint8_t *p)
{
    return ((uint32_t)p[0] << 8) | p[1];
}

static inline uint32_t be32(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3];
}

static inline uint32_t le16(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8);
}

static inline uint32_t le32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static inline int tag_is(const uint8_t *p, const char *s)
{
    return p[0] == (uint8_t)s[0] && p[1] == (uint8_t)s[1] && p[2] == (uint8_t)s[2] && p[3] == (uint8_t)s[3];
}

int zlib_inflate(const uint8_t *src, size_t len, uint8_t *out, size_t outlen);

/* ---- TrueType fonts ---- */
#define TTF_OK 0
#define TTF_ERR_FORMAT 1
#define TTF_ERR_DATA 2
#define TTF_ERR_MEMORY 3
#define TTF_ERR_UNSUPPORTED 4

typedef struct {
    const uint8_t *data;
    size_t size;
    uint32_t glyf, loca, head, hhea, hmtx, maxp, cmap, kern;
    uint32_t glyf_len, loca_len, hmtx_len, cmap_len, kern_len;
    uint32_t cmap_sub;
    uint32_t cmap_fmt;
    uint32_t units_per_em;
    uint32_t num_glyphs;
    uint32_t num_hmetrics;
    int loca_long;
    int ascent, descent, line_gap;
} ttf_font_t;

typedef struct {
    uint32_t width;
    uint32_t height;
    int32_t left;
    int32_t top;
    int32_t advance;
    uint8_t *pixels;
} ttf_bitmap_t;

int ttf_load(const uint8_t *data, size_t size, ttf_font_t *font);
uint32_t ttf_glyph_index(const ttf_font_t *font, uint32_t codepoint);
int ttf_advance_units(const ttf_font_t *font, uint32_t glyph);
int ttf_kern_units(const ttf_font_t *font, uint32_t left, uint32_t right);
int ttf_scale_units(const ttf_font_t *font, int units, uint32_t pixel_height);
int ttf_render_glyph(const ttf_font_t *font, uint32_t glyph, uint32_t pixel_height, ttf_bitmap_t *out);
void ttf_bitmap_free(ttf_bitmap_t *bmp);

#endif
