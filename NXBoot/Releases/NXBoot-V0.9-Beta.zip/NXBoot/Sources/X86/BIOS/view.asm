[BITS 16]
[ORG 0x2000]

V_INFO      equ 0x2800
V_MINFO     equ 0x2A00

view_entry:
    mov [v_file], eax
    mov [v_size], ecx
    mov byte [v_set], 0
    call v_unreal
    call v_parse
    test al, al
    jnz .out
    call v_pick
    test al, al
    jnz .out
    call v_unreal
    call v_draw
    call v_keys
    xor al, al
.out:
    mov ah, [v_set]
    ret

v_unreal:
    cli
    lgdt [v_gdtp]
    mov eax, cr0
    or al, 1
    mov cr0, eax
    jmp .pm
.pm:
    mov ax, 0x08
    mov fs, ax
    mov gs, ax
    mov eax, cr0
    and al, 0xFE
    mov cr0, eax
    sti
    ret

v_parse:
    mov esi, [v_file]
    mov ecx, [v_size]
    cmp ecx, 2
    jb .notbmp
    cmp word [gs:esi], 0x4D42
    jne .notbmp
    cmp ecx, 54
    jb .corrupt
    mov eax, [gs:esi + 14]
    cmp eax, 40
    jb .unsup
    cmp eax, 4096
    ja .corrupt
    mov [v_hs], eax
    mov eax, [gs:esi + 18]
    test eax, eax
    jle .corrupt
    cmp eax, 16384
    ja .unsup
    mov [v_w], eax
    mov eax, [gs:esi + 22]
    mov byte [v_top], 0
    test eax, eax
    jz .corrupt
    jns .hpos
    neg eax
    mov byte [v_top], 1
.hpos:
    cmp eax, 16384
    ja .unsup
    mov [v_h], eax
    movzx eax, word [gs:esi + 28]
    mov [v_bpp], eax
    cmp eax, 8
    je .bpp_ok
    cmp eax, 24
    je .bpp_ok
    cmp eax, 32
    jne .unsup
.bpp_ok:
    mov edx, [gs:esi + 30]
    test edx, edx
    jz .comp_ok
    cmp edx, 3
    jne .unsup
    cmp eax, 32
    jne .unsup
    cmp dword [gs:esi + 54], 0x00FF0000
    jne .unsup
    cmp dword [gs:esi + 58], 0x0000FF00
    jne .unsup
    cmp dword [gs:esi + 62], 0x000000FF
    jne .unsup
.comp_ok:
    mov dword [v_ncol], 0
    cmp eax, 8
    jne .nopal
    mov ebx, [gs:esi + 46]
    test ebx, ebx
    jnz .ncol_set
    mov ebx, 256
.ncol_set:
    cmp ebx, 256
    ja .unsup
    mov [v_ncol], ebx
    mov edx, [v_hs]
    add edx, 14
    shl ebx, 2
    add ebx, edx
    cmp ebx, [v_size]
    ja .corrupt
    mov [v_pal], edx
.nopal:
    mov eax, [v_w]
    mul dword [v_bpp]
    add eax, 31
    shr eax, 5
    shl eax, 2
    mov [v_stride], eax
    mul dword [v_h]
    mov ebx, eax
    mov eax, [gs:esi + 10]
    mov [v_off], eax
    cmp eax, [v_size]
    ja .corrupt
    mov edx, [v_size]
    sub edx, eax
    cmp edx, ebx
    jb .corrupt
    xor al, al
    ret
.notbmp:
    mov al, 1
    ret
.unsup:
    mov al, 2
    ret
.corrupt:
    mov al, 3
    ret

v_pick:
    mov word [v_bmode], 0
    mov byte [v_bfit], 0
    mov dword [v_barea], 0
    mov di, V_INFO
    mov ax, 0x4F00
    int 0x10
    cmp ax, 0x004F
    jne .none
    cmp dword [V_INFO], 0x41534556
    jne .none
    mov ax, [V_INFO + 0x10]
    mov [v_lseg], ax
    mov si, [V_INFO + 0x0E]
.next:
    mov fs, [v_lseg]
    mov cx, [fs:si]
    cmp cx, 0xFFFF
    je .scanned
    add si, 2
    push si
    mov [v_cand], cx
    mov di, V_MINFO
    mov ax, 0x4F01
    int 0x10
    pop si
    cmp ax, 0x004F
    jne .next
    mov ax, [V_MINFO]
    and ax, 0x0091
    cmp ax, 0x0091
    jne .next
    cmp byte [V_MINFO + 0x19], 32
    jne .next
    mov eax, [V_MINFO + 0x28]
    test eax, eax
    jz .next
    movzx ebx, word [V_MINFO + 0x12]
    movzx edx, word [V_MINFO + 0x14]
    cmp ebx, 640
    jb .next
    cmp edx, 480
    jb .next
    mov [v_cw], ebx
    mov [v_ch], edx
    mov eax, ebx
    mul edx
    mov [v_carea], eax
    mov byte [v_cfit], 0
    mov ebx, [v_cw]
    cmp ebx, [v_w]
    jb .fitdone
    mov ebx, [v_ch]
    cmp ebx, [v_h]
    jb .fitdone
    mov byte [v_cfit], 1
.fitdone:
    cmp word [v_bmode], 0
    je .take
    mov al, [v_cfit]
    mov ah, [v_bfit]
    cmp al, ah
    ja .take
    jb .next
    mov eax, [v_carea]
    cmp byte [v_cfit], 1
    jne .larger
    cmp eax, [v_barea]
    jb .take
    jmp .next
.larger:
    cmp eax, [v_barea]
    ja .take
    jmp .next
.take:
    mov ax, [v_cand]
    mov [v_bmode], ax
    mov al, [v_cfit]
    mov [v_bfit], al
    mov eax, [v_carea]
    mov [v_barea], eax
    mov eax, [v_cw]
    mov [v_sw], eax
    mov eax, [v_ch]
    mov [v_sh], eax
    movzx eax, word [V_MINFO + 0x10]
    mov [v_pitch], eax
    mov eax, [V_MINFO + 0x28]
    mov [v_lfb], eax
    jmp .next
.scanned:
    cmp word [v_bmode], 0
    je .none
    mov bx, [v_bmode]
    or bx, 0x4000
    mov ax, 0x4F02
    int 0x10
    cmp ax, 0x004F
    jne .none
    mov byte [v_set], 1
    xor al, al
    ret
.none:
    mov al, 4
    ret

v_draw:
    mov edi, [v_lfb]
    mov eax, [v_pitch]
    mul dword [v_sh]
    shr eax, 2
    mov ecx, eax
    xor eax, eax
.clr:
    mov [fs:edi], eax
    add edi, 4
    dec ecx
    jnz .clr
    mov dword [v_step], 0x10000
    mov eax, [v_w]
    mov [v_dw], eax
    mov eax, [v_h]
    mov [v_dh], eax
    mov eax, [v_w]
    cmp eax, [v_sw]
    ja .scale
    mov eax, [v_h]
    cmp eax, [v_sh]
    jbe .placed
.scale:
    mov eax, [v_w]
    shl eax, 16
    xor edx, edx
    div dword [v_sw]
    mov ebx, eax
    mov eax, [v_h]
    shl eax, 16
    xor edx, edx
    div dword [v_sh]
    cmp eax, ebx
    jae .maxok
    mov eax, ebx
.maxok:
    inc eax
    mov [v_step], eax
    mov ebx, eax
    mov eax, [v_w]
    shl eax, 16
    xor edx, edx
    div ebx
    test eax, eax
    jnz .dw_ok
    inc eax
.dw_ok:
    mov [v_dw], eax
    mov eax, [v_h]
    shl eax, 16
    xor edx, edx
    div ebx
    test eax, eax
    jnz .dh_ok
    inc eax
.dh_ok:
    mov [v_dh], eax
.placed:
    mov eax, [v_sw]
    sub eax, [v_dw]
    shr eax, 1
    shl eax, 2
    add eax, [v_lfb]
    mov [v_x0b], eax
    mov eax, [v_sh]
    sub eax, [v_dh]
    shr eax, 1
    mul dword [v_pitch]
    add eax, [v_x0b]
    mov [v_drow], eax
    mov dword [v_dy], 0
.row:
    mov eax, [v_dy]
    mul dword [v_step]
    shr eax, 16
    cmp byte [v_top], 1
    je .rowok
    mov edx, [v_h]
    dec edx
    sub edx, eax
    mov eax, edx
.rowok:
    mul dword [v_stride]
    add eax, [v_off]
    add eax, [v_file]
    mov esi, eax
    mov edi, [v_drow]
    mov ecx, [v_dw]
    xor ebx, ebx
.px:
    mov eax, ebx
    shr eax, 16
    cmp dword [v_bpp], 24
    je .p24
    cmp dword [v_bpp], 32
    je .p32
    movzx edx, byte [gs:esi + eax]
    cmp edx, [v_ncol]
    jae .black
    shl edx, 2
    add edx, [v_file]
    add edx, [v_pal]
    mov eax, [gs:edx]
    jmp .put
.black:
    xor eax, eax
    jmp .put
.p24:
    lea eax, [eax + eax * 2]
    movzx edx, word [gs:esi + eax]
    movzx eax, byte [gs:esi + eax + 2]
    shl eax, 16
    or eax, edx
    jmp .put
.p32:
    mov eax, [gs:esi + eax * 4]
.put:
    and eax, 0x00FFFFFF
    mov [fs:edi], eax
    add edi, 4
    add ebx, [v_step]
    dec ecx
    jnz .px
    mov eax, [v_drow]
    add eax, [v_pitch]
    mov [v_drow], eax
    inc dword [v_dy]
    mov eax, [v_dy]
    cmp eax, [v_dh]
    jb .row
    ret

v_keys:
.flush:
    mov ah, 1
    int 0x16
    jz .wait
    xor ax, ax
    int 0x16
    jmp .flush
.wait:
    xor ax, ax
    int 0x16
    ret

v_gdt:
    dq 0
    dw 0xFFFF, 0x0000
    db 0x00, 10010010b, 11001111b, 0x00
v_gdtp:
    dw v_gdtp - v_gdt - 1
    dd v_gdt

v_set       db 0
v_top       db 0
v_cfit      db 0
v_bfit      db 0
v_bmode     dw 0
v_cand      dw 0
v_lseg      dw 0
v_file      dd 0
v_size      dd 0
v_hs        dd 0
v_w         dd 0
v_h         dd 0
v_bpp       dd 0
v_ncol      dd 0
v_pal       dd 0
v_off       dd 0
v_stride    dd 0
v_cw        dd 0
v_ch        dd 0
v_carea     dd 0
v_barea     dd 0
v_sw        dd 0
v_sh        dd 0
v_pitch     dd 0
v_lfb       dd 0
v_step      dd 0
v_dw        dd 0
v_dh        dd 0
v_x0b       dd 0
v_drow      dd 0
v_dy        dd 0

times 2048 - ($ - $$) db 0
