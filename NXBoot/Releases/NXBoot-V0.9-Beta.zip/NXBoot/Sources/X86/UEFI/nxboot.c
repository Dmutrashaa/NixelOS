/* NXBoot UEFI (x86-64) - the whole loader in one file */

/* ======== declarations ======== */

#include "efi.h"
#include "decoders.h"

#define NX_VERSION "v0.9 BETA"
#define NX_BUILD_DATE "4.11.2026"
#define NX_PROMPT "NXBoot>"

#define MAX_COLS 160
#define MAX_ROWS 60

extern EFI_SYSTEM_TABLE *gST;
extern EFI_BOOT_SERVICES *gBS;
extern EFI_HANDLE gImage;
extern EFI_HANDLE gBootDevice;

#ifndef NX_HOSTED
void *memcpy(void *d, const void *s, size_t n);
void *memmove(void *d, const void *s, size_t n);
void *memset(void *d, int c, size_t n);
int memcmp(const void *a, const void *b, size_t n);
#else
#include <string.h>
#endif

size_t nx_strlen(const char *s);
int nx_streq(const char *a, const char *b);
int nx_strieq(const char *a, const char *b);
char nx_upper(char c);
void nx_strcpy(char *d, const char *s, size_t max);
int nx_parse_hex(const char *s, uint64_t *out, const char **end);

void t_init(void);
void t_puts(const char *s);
void t_putc(char c);
void t_putw(CHAR16 c);
void t_puts16(const CHAR16 *s);
void t_hex(uint64_t v, int digits);
void t_dec(uint64_t v);
void t_attr(unsigned a);
unsigned t_get_attr(void);
void t_cls(void);
void t_cursor(int on);
void t_size(int *cols, int *rows);
void t_goto(int col, int row);
void t_fill(int col, int row, int n, CHAR16 ch, unsigned attr);
void t_text(int col, int row, const char *s, unsigned attr);
void t_text_n(int col, int row, const char *s, int n, unsigned attr);
void t_center(int row, const char *s, unsigned attr);
void t_cell(int col, int row, CHAR16 ch, unsigned attr);
#define T_RECT_MAX 640
typedef struct {
    int x;
    int y;
    int w;
    int h;
    CHAR16 ch[T_RECT_MAX];
    uint8_t at[T_RECT_MAX];
} t_rect_t;
void t_rect_save(t_rect_t *r, int x, int y, int w, int h);
void t_rect_restore(const t_rect_t *r);
void t_snapshot(void);
void t_restore(void);
void t_repaint(void);
void t_getkey(EFI_INPUT_KEY *k);
int t_pollkey(EFI_INPUT_KEY *k);
void t_flush_keys(void);
int t_readline(char *buf, int max);
void t_delay_ms(unsigned ms);
void t_pause_steps(int steps);
int t_confirm(int restart);

#define KEY_UP 1
#define KEY_DOWN 2
#define KEY_RIGHT 3
#define KEY_LEFT 4
#define KEY_HOME 5
#define KEY_END 6
#define KEY_PGUP 9
#define KEY_PGDN 10
#define KEY_ESC 0x17

#define BOX_TL 0x2554
#define BOX_TR 0x2557
#define BOX_BL 0x255A
#define BOX_BR 0x255D
#define BOX_H 0x2550
#define BOX_V 0x2551
#define BOX_ML 0x255F
#define BOX_MR 0x2562
#define BOX_SH 0x2500
#define BOX_STL 0x250C
#define BOX_STR 0x2510
#define BOX_SBL 0x2514
#define BOX_SBR 0x2518
#define BOX_SV 0x2502
#define BOX_SML 0x251C
#define BOX_SMR 0x2524
#define CH_UP 0x25B2
#define CH_DOWN 0x25BC
#define CH_BLOCK 0x2588
#define CH_MID 0x2593
#define CH_LIGHT 0x2591

typedef struct {
    uint64_t base;
    uint64_t length;
    uint32_t type;
    uint32_t attr;
} nx_e820_t;

typedef struct {
    uint32_t magic;
    uint32_t drive;
    uint32_t entry;
    uint32_t lo;
    uint32_t hi;
    uint32_t ram_top;
    uint32_t bits;
    uint32_t firmware;
    uint64_t entry64;
    uint64_t lo64;
    uint64_t hi64;
    uint64_t ram_top64;
    uint64_t memmap;
    uint32_t memmap_count;
    uint32_t memmap_entry_size;
    uint64_t acpi_rsdp;
    uint64_t system_table;
    uint64_t fb_base;
    uint32_t fb_width;
    uint32_t fb_height;
    uint32_t fb_pitch;
    uint32_t fb_bpp;
} nx_boot_info_t;

#define NX_BOOT_MAGIC 0x5442584EU
#define NX_FIRMWARE_UEFI 2

int fs_init(void);
int fs_volume_count(void);
int fs_select(int idx);
int fs_current(void);
const char *fs_cwd(void);
void fs_reset_cwd(void);
int fs_open_path(const char *path, EFI_FILE **out);
int fs_open_rel(const char *name, EFI_FILE **out);
int fs_cd(const char *arg);
void fs_dir(void);
void fs_type(const char *name);
int fs_read_file(const char *name, uint8_t **buf, uint64_t *size, int *is_dir);
int fs_read_abs(int vol, const char *abs, uint8_t **buf, uint64_t *size);
void fs_free(void *p);
int fs_boot_volume(void);

#define FS_OK 0
#define FS_ERR_NOVOL 1
#define FS_ERR_NAME 2
#define FS_ERR_NOFILE 3
#define FS_ERR_NOTDIR 4
#define FS_ERR_ISDIR 5
#define FS_ERR_READ 6
#define FS_ERR_MEM 7

extern const char *const MSG_FAT_ERR;
extern const char *const MSG_FAT_NOFILE;
extern const char *const MSG_FAT_NOTDIR;
extern const char *const MSG_FAT_ISDIR;
extern const char *const MSG_FAT_BADNAME;
extern const char *const MSG_FAT_READERR;

const char *fs_err_text(int code);

void splash_play(void);

void cmd_run(char *line);
void cmd_boot_args(char *args);
void cmd_multiboot(char *args);
int terminal_run(void);
extern int g_skip_gap;
extern int g_close_requested;

void boot_log_reset(void);
void bprint(const char *s);
void bprint_hex(uint64_t v, int digits);
void boot_fail(const char *file, const char *reason);
void boot_error_screen(const char *file, const char *reason);
void boot_do(char *args);

void do_reboot(void);
void do_shutdown(void);

typedef struct {
    const char *title;
    const char *map_title;
    const char *amount_label;
    const char *press_msg;
    const char *scanning_msg;
    const char *cracked_msg;
    const char *exit_msg;
    const char *about_msg;
    const char *fail_msg;
    const char *intro[3];
    uint64_t align;
    int (*begin)(uint64_t *total);
    void (*amount)(char *out, int max);
    uint64_t (*test)(uint64_t first, uint64_t count, int mode);
    void (*end)(void);
} diag_info_t;

void diag_run(const diag_info_t *d, int mode);
void diag_fmt_size(char *out, int max, uint64_t mb);
void memdiag_cmd(const char *arg);
void diagisk_cmd(const char *arg);
void cmd_view(const char *arg);
void *nx_alloc(size_t n);
void nx_free(void *p);

uint64_t sys_ram_bytes(void);
void sys_time_print(void);

int error_screen(void);
void early_gate(void);

/* ======== nxlib ======== */

#ifndef NX_HOSTED
void *memcpy(void *d, const void *s, size_t n)
{
    uint8_t *a = d;
    const uint8_t *b = s;
    while (n--) {
        *a++ = *b++;
        __asm__ volatile("" ::: "memory");
    }
    return d;
}

void *memmove(void *d, const void *s, size_t n)
{
    uint8_t *a = d;
    const uint8_t *b = s;
    if (a == b || n == 0) return d;
    if (a < b) {
        while (n--) {
            *a++ = *b++;
            __asm__ volatile("" ::: "memory");
        }
    } else {
        a += n;
        b += n;
        while (n--) {
            *--a = *--b;
            __asm__ volatile("" ::: "memory");
        }
    }
    return d;
}

void *memset(void *d, int c, size_t n)
{
    uint8_t *a = d;
    while (n--) {
        *a++ = (uint8_t)c;
        __asm__ volatile("" ::: "memory");
    }
    return d;
}

int memcmp(const void *x, const void *y, size_t n)
{
    const uint8_t *a = x;
    const uint8_t *b = y;
    while (n--) {
        if (*a != *b) return *a < *b ? -1 : 1;
        a++;
        b++;
    }
    return 0;
}
#endif

void *nx_alloc(size_t n)
{
    void *p = 0;
    if (EFI_ERROR(gBS->AllocatePool(EfiLoaderData, (UINTN)n, &p))) return 0;
    return p;
}

void nx_free(void *p)
{
    if (p) gBS->FreePool(p);
}

size_t nx_strlen(const char *s)
{
    size_t n = 0;
    while (s[n]) n++;
    return n;
}

char nx_upper(char c)
{
    if (c >= 'a' && c <= 'z') return (char)(c - 32);
    return c;
}

int nx_streq(const char *a, const char *b)
{
    while (*a && *a == *b) {
        a++;
        b++;
    }
    return *a == *b;
}

int nx_strieq(const char *a, const char *b)
{
    while (*a && nx_upper(*a) == nx_upper(*b)) {
        a++;
        b++;
    }
    return nx_upper(*a) == nx_upper(*b);
}

void nx_strcpy(char *d, const char *s, size_t max)
{
    size_t i = 0;
    if (max == 0) return;
    while (s[i] && i + 1 < max) {
        d[i] = s[i];
        i++;
    }
    d[i] = 0;
}

int nx_parse_hex(const char *s, uint64_t *out, const char **end)
{
    uint64_t v = 0;
    int n = 0;
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) s += 2;
    for (;;) {
        char c = *s;
        int d;
        if (c >= '0' && c <= '9') d = c - '0';
        else if (c >= 'a' && c <= 'f') d = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') d = c - 'A' + 10;
        else break;
        if (n >= 16) return 0;
        v = (v << 4) | (uint64_t)d;
        n++;
        s++;
    }
    if (n == 0) return 0;
    if (*s != 0 && *s != ' ') return 0;
    *out = v;
    if (end) *end = s;
    return 1;
}

/* ======== term ======== */

static int cols = 80;
static int rows = 25;
static int cx = 0;
static int cy = 0;
static unsigned cur = 0x07;
static int cursor_on = 1;

static CHAR16 sh_ch[MAX_ROWS][MAX_COLS];
static uint8_t sh_at[MAX_ROWS][MAX_COLS];
static CHAR16 sn_ch[MAX_ROWS][MAX_COLS];
static uint8_t sn_at[MAX_ROWS][MAX_COLS];
static int sn_cx;
static int sn_cy;
static unsigned sn_cur;

static CHAR16 ob[256];
static int on;

static void flush(void)
{
    if (on == 0) return;
    ob[on] = 0;
    gST->ConOut->OutputString(gST->ConOut, ob);
    on = 0;
}

static void shadow_clear(void)
{
    int r, c;
    for (r = 0; r < MAX_ROWS; r++) {
        for (c = 0; c < MAX_COLS; c++) {
            sh_ch[r][c] = ' ';
            sh_at[r][c] = (uint8_t)cur;
        }
    }
}

static void shadow_scroll(void)
{
    int r, c;
    for (r = 1; r < rows; r++) {
        memcpy(sh_ch[r - 1], sh_ch[r], sizeof(sh_ch[0]));
        memcpy(sh_at[r - 1], sh_at[r], sizeof(sh_at[0]));
    }
    for (c = 0; c < MAX_COLS; c++) {
        sh_ch[rows - 1][c] = ' ';
        sh_at[rows - 1][c] = (uint8_t)cur;
    }
}

static void push(CHAR16 c)
{
    if (on >= 250) flush();
    ob[on++] = c;
}

static void wrap_state(void)
{
    cx = 0;
    cy++;
    if (cy >= rows) {
        shadow_scroll();
        cy = rows - 1;
    }
}

void t_putw(CHAR16 ch)
{
    if (ch == '\n') {
        push('\r');
        push('\n');
        wrap_state();
        return;
    }
    if (ch == '\r') {
        push('\r');
        cx = 0;
        return;
    }
    if (ch == '\b') {
        push('\b');
        if (cx > 0) cx--;
        return;
    }
    if (ch == '\t') {
        do {
            push(' ');
            sh_ch[cy][cx] = ' ';
            sh_at[cy][cx] = (uint8_t)cur;
            cx++;
            if (cx >= cols) {
                wrap_state();
                break;
            }
        } while (cx % 8);
        return;
    }
    if (ch < 0x20) return;
    push(ch);
    sh_ch[cy][cx] = ch;
    sh_at[cy][cx] = (uint8_t)cur;
    cx++;
    if (cx >= cols) wrap_state();
}

static CHAR16 u8next(const char **p)
{
    const uint8_t *s = (const uint8_t *)*p;
    uint32_t c = s[0];
    if (c < 0x80) {
        *p += 1;
        return (CHAR16)c;
    }
    if ((c & 0xE0) == 0xC0 && (s[1] & 0xC0) == 0x80) {
        *p += 2;
        return (CHAR16)(((c & 0x1F) << 6) | (s[1] & 0x3F));
    }
    if ((c & 0xF0) == 0xE0 && (s[1] & 0xC0) == 0x80 && (s[2] & 0xC0) == 0x80) {
        *p += 3;
        return (CHAR16)(((c & 0x0F) << 12) | ((s[1] & 0x3F) << 6) | (s[2] & 0x3F));
    }
    *p += 1;
    return '?';
}

void t_puts(const char *s)
{
    while (*s) t_putw(u8next(&s));
    flush();
}

void t_putc(char c)
{
    t_putw((CHAR16)(uint8_t)c);
    flush();
}

void t_puts16(const CHAR16 *s)
{
    while (*s) t_putw(*s++);
    flush();
}

void t_hex(uint64_t v, int digits)
{
    int i;
    for (i = digits - 1; i >= 0; i--) {
        int d = (int)((v >> (i * 4)) & 0xF);
        t_putw((CHAR16)(d < 10 ? '0' + d : 'A' + d - 10));
    }
    flush();
}

void t_dec(uint64_t v)
{
    char tmp[24];
    int n = 0;
    if (v == 0) tmp[n++] = '0';
    while (v) {
        tmp[n++] = (char)('0' + (int)(v % 10));
        v /= 10;
    }
    while (n) t_putw((CHAR16)tmp[--n]);
    flush();
}

void t_attr(unsigned a)
{
    flush();
    cur = a & 0xFF;
    gST->ConOut->SetAttribute(gST->ConOut, a & 0x7F);
}

unsigned t_get_attr(void)
{
    return cur;
}

static void place_cursor(void)
{
    gST->ConOut->SetCursorPosition(gST->ConOut, (UINTN)cx, (UINTN)cy);
}

void t_cls(void)
{
    flush();
    gST->ConOut->SetAttribute(gST->ConOut, cur & 0x7F);
    gST->ConOut->ClearScreen(gST->ConOut);
    shadow_clear();
    cx = 0;
    cy = 0;
    place_cursor();
}

void t_cursor(int on_)
{
    flush();
    cursor_on = on_;
    gST->ConOut->EnableCursor(gST->ConOut, (BOOLEAN)(on_ != 0));
}

void t_size(int *c, int *r)
{
    *c = cols;
    *r = rows;
}

void t_goto(int c, int r)
{
    flush();
    if (c < 0) c = 0;
    if (r < 0) r = 0;
    if (c >= cols) c = cols - 1;
    if (r >= rows) r = rows - 1;
    cx = c;
    cy = r;
    place_cursor();
}

static void draw_run(int col, int row, const CHAR16 *s, int n, unsigned attr)
{
    CHAR16 tmp[MAX_COLS + 1];
    int i;
    flush();
    if (row < 0 || row >= rows || col < 0 || col >= cols) return;
    if (col + n > cols) n = cols - col;
    for (i = 0; i < n; i++) {
        tmp[i] = s[i];
        sh_ch[row][col + i] = s[i];
        sh_at[row][col + i] = (uint8_t)attr;
    }
    if (row == rows - 1 && col + n == cols) n--;
    if (n <= 0) return;
    tmp[n] = 0;
    gST->ConOut->SetAttribute(gST->ConOut, attr & 0x7F);
    gST->ConOut->SetCursorPosition(gST->ConOut, (UINTN)col, (UINTN)row);
    gST->ConOut->OutputString(gST->ConOut, tmp);
    gST->ConOut->SetAttribute(gST->ConOut, cur & 0x7F);
    place_cursor();
}

void t_fill(int col, int row, int n, CHAR16 ch, unsigned attr)
{
    CHAR16 tmp[MAX_COLS + 1];
    int i;
    if (n > MAX_COLS) n = MAX_COLS;
    for (i = 0; i < n; i++) tmp[i] = ch;
    draw_run(col, row, tmp, n, attr);
}

void t_text_n(int col, int row, const char *s, int n, unsigned attr)
{
    CHAR16 tmp[MAX_COLS + 1];
    int i = 0;
    while (*s && i < n && i < MAX_COLS) tmp[i++] = u8next(&s);
    draw_run(col, row, tmp, i, attr);
}

void t_text(int col, int row, const char *s, unsigned attr)
{
    t_text_n(col, row, s, MAX_COLS, attr);
}

void t_center(int row, const char *s, unsigned attr)
{
    const char *p = s;
    int n = 0;
    while (*p) {
        (void)u8next(&p);
        n++;
    }
    t_text((cols - n) / 2, row, s, attr);
}

void t_cell(int col, int row, CHAR16 ch, unsigned attr)
{
    draw_run(col, row, &ch, 1, attr);
}

void t_snapshot(void)
{
    flush();
    memcpy(sn_ch, sh_ch, sizeof(sh_ch));
    memcpy(sn_at, sh_at, sizeof(sh_at));
    sn_cx = cx;
    sn_cy = cy;
    sn_cur = cur;
}

void t_repaint(void)
{
    int r, c, start;
    flush();
    for (r = 0; r < rows; r++) {
        c = 0;
        while (c < cols) {
            unsigned a = sh_at[r][c];
            start = c;
            while (c < cols && sh_at[r][c] == a) c++;
            {
                CHAR16 tmp[MAX_COLS + 1];
                int i, n = c - start;
                for (i = 0; i < n; i++) tmp[i] = sh_ch[r][start + i];
                draw_run(start, r, tmp, n, a);
            }
        }
    }
    gST->ConOut->SetAttribute(gST->ConOut, cur & 0x7F);
    place_cursor();
}

void t_rect_save(t_rect_t *r, int x, int y, int w, int h)
{
    int i, j;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x + w > cols) w = cols - x;
    if (y + h > rows) h = rows - y;
    if (w < 0) w = 0;
    if (h < 0) h = 0;
    if (w * h > T_RECT_MAX) h = T_RECT_MAX / (w ? w : 1);
    r->x = x;
    r->y = y;
    r->w = w;
    r->h = h;
    for (i = 0; i < h; i++) {
        for (j = 0; j < w; j++) {
            r->ch[i * w + j] = sh_ch[y + i][x + j];
            r->at[i * w + j] = sh_at[y + i][x + j];
        }
    }
}

void t_rect_restore(const t_rect_t *r)
{
    int i, j, start;
    for (i = 0; i < r->h; i++) {
        j = 0;
        while (j < r->w) {
            unsigned a = r->at[i * r->w + j];
            CHAR16 tmp[MAX_COLS + 1];
            int n;
            start = j;
            while (j < r->w && r->at[i * r->w + j] == a) j++;
            for (n = 0; n < j - start; n++) tmp[n] = r->ch[i * r->w + start + n];
            draw_run(r->x + start, r->y + i, tmp, j - start, a);
        }
    }
}

void t_restore(void)
{
    memcpy(sh_ch, sn_ch, sizeof(sh_ch));
    memcpy(sh_at, sn_at, sizeof(sh_at));
    cx = sn_cx;
    cy = sn_cy;
    cur = sn_cur;
    t_repaint();
}

void t_init(void)
{
    UINTN c = 80, r = 25;
    gST->ConOut->SetMode(gST->ConOut, 0);
    if (!EFI_ERROR(gST->ConOut->QueryMode(gST->ConOut, (UINTN)gST->ConOut->Mode->Mode, &c, &r))) {
        if (c > MAX_COLS) c = MAX_COLS;
        if (r > MAX_ROWS) r = MAX_ROWS;
        if (c < 40) c = 40;
        if (r < 10) r = 10;
        cols = (int)c;
        rows = (int)r;
    }
    cur = 0x07;
    gST->ConOut->SetAttribute(gST->ConOut, 0x07);
    shadow_clear();
    gST->ConOut->ClearScreen(gST->ConOut);
    gST->ConOut->EnableCursor(gST->ConOut, 1);
    cursor_on = 1;
    cx = 0;
    cy = 0;
    on = 0;
    place_cursor();
}

void t_getkey(EFI_INPUT_KEY *k)
{
    UINTN idx;
    flush();
    for (;;) {
        EFI_STATUS s = gST->ConIn->ReadKeyStroke(gST->ConIn, k);
        if (!EFI_ERROR(s)) return;
        gBS->WaitForEvent(1, &gST->ConIn->WaitForKey, &idx);
    }
}

int t_pollkey(EFI_INPUT_KEY *k)
{
    return !EFI_ERROR(gST->ConIn->ReadKeyStroke(gST->ConIn, k));
}

void t_flush_keys(void)
{
    EFI_INPUT_KEY k;
    int guard = 0;
    gST->ConIn->Reset(gST->ConIn, 0);
    while (guard++ < 256 && t_pollkey(&k)) {
    }
}

int t_readline(char *buf, int max)
{
    int len = 0;
    EFI_INPUT_KEY k;
    for (;;) {
        t_getkey(&k);
        if (k.UnicodeChar == 0x0D || k.UnicodeChar == 0x0A) {
            t_putw('\n');
            flush();
            buf[len] = 0;
            return len;
        }
        if (k.UnicodeChar == 0x08) {
            if (len > 0) {
                len--;
                t_putw('\b');
                t_putw(' ');
                t_putw('\b');
                flush();
            }
            continue;
        }
        if (k.UnicodeChar >= 0x20 && k.UnicodeChar < 0x7F && len < max - 1) {
            buf[len++] = (char)k.UnicodeChar;
            t_putw(k.UnicodeChar);
            flush();
        }
    }
}

void t_delay_ms(unsigned ms)
{
    flush();
    gBS->Stall((UINTN)ms * 1000);
}

void t_pause_steps(int steps)
{
    while (steps-- > 0) t_delay_ms(150);
}

#define DLG_W 42
#define DLG_H 7
#define DLG_ATTR 0x1F
#define DLG_ATTR_SEL 0x71

static const char *const dlg_shut[2] = {
    "          Do you want to shut           ",
    "             down your PC?              "
};

static const char *const dlg_reboot[2] = {
    "         Do you want to restart         ",
    "                your PC?                "
};

static void dlg_buttons(int x, int y, int sel)
{
    t_text(x + 9, y + DLG_H - 1, "[ Yes ]", sel == 0 ? DLG_ATTR_SEL : DLG_ATTR);
    t_text(x + 27, y + DLG_H - 1, "[ No ]", sel == 1 ? DLG_ATTR_SEL : DLG_ATTR);
}

int t_confirm(int restart)
{
    int x = (cols - DLG_W) / 2;
    int y = (rows - DLG_H) / 2;
    int sel = 1;
    int i;
    EFI_INPUT_KEY k;
    const char *const *txt = restart ? dlg_reboot : dlg_shut;
    int was_cursor = cursor_on;

    t_snapshot();
    t_cursor(0);

    t_fill(x, y, 1, BOX_TL, DLG_ATTR);
    t_fill(x + 1, y, DLG_W - 2, BOX_H, DLG_ATTR);
    t_fill(x + DLG_W - 1, y, 1, BOX_TR, DLG_ATTR);
    for (i = 1; i < DLG_H - 1; i++) {
        t_fill(x, y + i, 1, BOX_V, DLG_ATTR);
        t_fill(x + 1, y + i, DLG_W - 2, ' ', DLG_ATTR);
        t_fill(x + DLG_W - 1, y + i, 1, BOX_V, DLG_ATTR);
    }
    t_fill(x, y + DLG_H - 1, 1, BOX_BL, DLG_ATTR);
    t_fill(x + 1, y + DLG_H - 1, DLG_W - 2, BOX_H, DLG_ATTR);
    t_fill(x + DLG_W - 1, y + DLG_H - 1, 1, BOX_BR, DLG_ATTR);
    t_text(x + 1, y + 2, txt[0], DLG_ATTR);
    t_text(x + 1, y + 3, txt[1], DLG_ATTR);

    for (;;) {
        dlg_buttons(x, y, sel);
        t_getkey(&k);
        if (k.ScanCode == KEY_LEFT) sel = 0;
        else if (k.ScanCode == KEY_RIGHT) sel = 1;
        else if (k.UnicodeChar == 0x0D) break;
        else if (k.ScanCode == KEY_ESC) {
            sel = 1;
            break;
        }
    }

    t_restore();
    t_cursor(was_cursor);
    return sel == 0;
}

/* ======== fs ======== */

#define MAX_VOLS 16
#define PATH_MAX_LEN 250

static const EFI_GUID g_fs_guid = EFI_SIMPLE_FS_GUID;
static const EFI_GUID g_info_guid = EFI_FILE_INFO_GUID;

static EFI_HANDLE *vol_handles;
static EFI_HANDLE vol_list[MAX_VOLS];
static int vol_count;
static int cur_vol;
static char cwd[PATH_MAX_LEN + 1] = "\\";

const char *const MSG_FAT_ERR = "FAT32 volume not found or unreadable.\n";
const char *const MSG_FAT_NOFILE = "File or directory not found.\n";
const char *const MSG_FAT_NOTDIR = "Not a directory.\n";
const char *const MSG_FAT_ISDIR = "This is a directory, not a file.\n";
const char *const MSG_FAT_BADNAME = "Invalid file name.\n";
const char *const MSG_FAT_READERR = "Disk read error.\n";

const char *fs_err_text(int code)
{
    switch (code) {
    case FS_ERR_NOVOL: return MSG_FAT_ERR;
    case FS_ERR_NAME: return MSG_FAT_BADNAME;
    case FS_ERR_NOFILE: return MSG_FAT_NOFILE;
    case FS_ERR_NOTDIR: return MSG_FAT_NOTDIR;
    case FS_ERR_ISDIR: return MSG_FAT_ISDIR;
    case FS_ERR_READ: return MSG_FAT_READERR;
    case FS_ERR_MEM: return "Not enough RAM to load the kernel.\n";
    default: return MSG_FAT_ERR;
    }
}

int fs_init(void)
{
    UINTN n = 0;
    EFI_HANDLE *h = 0;
    UINTN i;
    int k = 0;

    vol_count = 0;
    cur_vol = 0;
    cwd[0] = '\\';
    cwd[1] = 0;

    if (EFI_ERROR(gBS->LocateHandleBuffer(ByProtocol, &g_fs_guid, 0, &n, &h)) || n == 0) return 0;
    vol_handles = h;

    if (gBootDevice) {
        for (i = 0; i < n && k < MAX_VOLS; i++) {
            if (h[i] == gBootDevice) {
                vol_list[k++] = h[i];
                break;
            }
        }
    }
    for (i = 0; i < n && k < MAX_VOLS; i++) {
        if (k > 0 && h[i] == vol_list[0] && gBootDevice == vol_list[0]) continue;
        vol_list[k++] = h[i];
    }
    vol_count = k;
    return vol_count;
}

int fs_volume_count(void)
{
    return vol_count;
}

int fs_current(void)
{
    return cur_vol;
}

int fs_boot_volume(void)
{
    return 0;
}

const char *fs_cwd(void)
{
    return cwd;
}

void fs_reset_cwd(void)
{
    cwd[0] = '\\';
    cwd[1] = 0;
}

int fs_select(int idx)
{
    if (idx < 0 || idx >= vol_count) return 0;
    cur_vol = idx;
    fs_reset_cwd();
    return 1;
}

static int root_of(int vol, EFI_FILE **root)
{
    EFI_SIMPLE_FS *fs = 0;
    if (vol < 0 || vol >= vol_count) return FS_ERR_NOVOL;
    if (EFI_ERROR(gBS->HandleProtocol(vol_list[vol], &g_fs_guid, (void **)&fs)) || !fs) return FS_ERR_NOVOL;
    if (EFI_ERROR(fs->OpenVolume(fs, root)) || !*root) return FS_ERR_NOVOL;
    return FS_OK;
}

static int name_char_ok(char c)
{
    if ((uint8_t)c < 0x20) return 0;
    switch (c) {
    case '"': case '*': case ':': case '<': case '>': case '?': case '|': return 0;
    default: return 1;
    }
}

static int normalize(const char *base, const char *rel, char *out)
{
    char comps[24][64];
    int ncomp = 0;
    const char *p;
    int i, len;

    if (rel[0] == '\\' || rel[0] == '/') {
        p = rel;
    } else {
        p = base;
        while (*p) {
            const char *q;
            while (*p == '\\' || *p == '/') p++;
            if (!*p) break;
            q = p;
            len = 0;
            while (*q && *q != '\\' && *q != '/') {
                if (len < 63) comps[ncomp][len++] = *q;
                q++;
            }
            comps[ncomp][len] = 0;
            if (ncomp < 23) ncomp++;
            p = q;
        }
        p = rel;
    }

    while (*p) {
        const char *q;
        while (*p == '\\' || *p == '/') p++;
        if (!*p) break;
        q = p;
        len = 0;
        while (*q && *q != '\\' && *q != '/') {
            if (!name_char_ok(*q)) return 0;
            if (len < 63) comps[ncomp][len++] = *q;
            q++;
        }
        comps[ncomp][len] = 0;
        if (len == 1 && comps[ncomp][0] == '.') {
        } else if (len == 2 && comps[ncomp][0] == '.' && comps[ncomp][1] == '.') {
            if (ncomp > 0) ncomp--;
        } else {
            if (ncomp >= 23) return 0;
            ncomp++;
        }
        p = q;
    }

    len = 0;
    out[len++] = '\\';
    for (i = 0; i < ncomp; i++) {
        int j = 0;
        if (i > 0) {
            if (len >= PATH_MAX_LEN) return 0;
            out[len++] = '\\';
        }
        while (comps[i][j]) {
            if (len >= PATH_MAX_LEN) return 0;
            out[len++] = comps[i][j++];
        }
    }
    out[len] = 0;
    return 1;
}

static void to16(const char *s, CHAR16 *d, int max)
{
    int i = 0;
    while (s[i] && i < max - 1) {
        d[i] = (CHAR16)(uint8_t)s[i];
        i++;
    }
    d[i] = 0;
}

static int open_on(int vol, const char *abs, EFI_FILE **out)
{
    EFI_FILE *root = 0;
    EFI_FILE *f = 0;
    CHAR16 p16[PATH_MAX_LEN + 2];
    int r = root_of(vol, &root);
    if (r != FS_OK) return r;
    to16(abs, p16, PATH_MAX_LEN + 2);
    if (EFI_ERROR(root->Open(root, &f, p16, EFI_FILE_MODE_READ, 0)) || !f) {
        root->Close(root);
        return FS_ERR_NOFILE;
    }
    root->Close(root);
    *out = f;
    return FS_OK;
}

int fs_open_path(const char *path, EFI_FILE **out)
{
    char abs[PATH_MAX_LEN + 2];
    if (!normalize("\\", path, abs)) return FS_ERR_NAME;
    return open_on(cur_vol, abs, out);
}

int fs_open_rel(const char *name, EFI_FILE **out)
{
    char abs[PATH_MAX_LEN + 2];
    if (!name[0]) return FS_ERR_NAME;
    if (!normalize(cwd, name, abs)) return FS_ERR_NAME;
    return open_on(cur_vol, abs, out);
}

static int file_info(EFI_FILE *f, uint64_t *size, int *is_dir)
{
    uint8_t buf[600];
    UINTN sz = sizeof(buf);
    EFI_FILE_INFO *info = (EFI_FILE_INFO *)buf;
    if (EFI_ERROR(f->GetInfo(f, &g_info_guid, &sz, info))) return 0;
    if (size) *size = info->FileSize;
    if (is_dir) *is_dir = (info->Attribute & EFI_FILE_DIRECTORY) != 0;
    return 1;
}

void fs_free(void *p)
{
    if (p) gBS->FreePool(p);
}

static int read_whole(EFI_FILE *f, uint8_t **buf, uint64_t *size)
{
    uint64_t sz = 0;
    int dir = 0;
    UINTN want;
    UINTN got;
    uint8_t *b = 0;
    UINTN done = 0;

    if (!file_info(f, &sz, &dir)) return FS_ERR_READ;
    if (dir) return FS_ERR_ISDIR;
    *size = sz;
    if (sz == 0) {
        *buf = 0;
        return FS_OK;
    }
    if (sz > 0x7FFFFFFFULL) return FS_ERR_MEM;
    if (EFI_ERROR(gBS->AllocatePool(EfiLoaderData, (UINTN)sz, (void **)&b))) return FS_ERR_MEM;
    while (done < sz) {
        want = (UINTN)(sz - done);
        if (want > 0x100000) want = 0x100000;
        got = want;
        if (EFI_ERROR(f->Read(f, &got, b + done)) || got == 0) {
            gBS->FreePool(b);
            return FS_ERR_READ;
        }
        done += got;
    }
    *buf = b;
    return FS_OK;
}

int fs_read_file(const char *name, uint8_t **buf, uint64_t *size, int *is_dir)
{
    EFI_FILE *f = 0;
    int r;
    int dir = 0;
    uint64_t sz = 0;
    *buf = 0;
    *size = 0;
    if (is_dir) *is_dir = 0;
    r = fs_open_rel(name, &f);
    if (r != FS_OK) return r;
    if (!file_info(f, &sz, &dir)) {
        f->Close(f);
        return FS_ERR_READ;
    }
    if (dir) {
        f->Close(f);
        if (is_dir) *is_dir = 1;
        return FS_ERR_ISDIR;
    }
    r = read_whole(f, buf, size);
    f->Close(f);
    return r;
}

int fs_read_abs(int vol, const char *abs, uint8_t **buf, uint64_t *size)
{
    EFI_FILE *f = 0;
    int r = open_on(vol, abs, &f);
    *buf = 0;
    *size = 0;
    if (r != FS_OK) return r;
    r = read_whole(f, buf, size);
    f->Close(f);
    return r;
}

static void print_name16(const CHAR16 *s)
{
    while (*s) {
        t_putw(*s < 0x20 ? '?' : *s);
        s++;
    }
}

void fs_dir(void)
{
    EFI_FILE *d = 0;
    uint8_t buf[1024];
    int r = open_on(cur_vol, cwd, &d);
    if (r != FS_OK) {
        t_puts(MSG_FAT_ERR);
        return;
    }
    for (;;) {
        UINTN sz = sizeof(buf);
        EFI_FILE_INFO *info = (EFI_FILE_INFO *)buf;
        if (EFI_ERROR(d->Read(d, &sz, buf))) {
            t_puts(MSG_FAT_ERR);
            break;
        }
        if (sz == 0) break;
        print_name16(info->FileName);
        if (info->Attribute & EFI_FILE_DIRECTORY) {
            t_puts("  <DIR>\n");
        } else {
            t_puts("  ");
            t_dec(info->FileSize);
            t_puts(" bytes\n");
        }
    }
    d->Close(d);
}

int fs_cd(const char *arg)
{
    char abs[PATH_MAX_LEN + 2];
    EFI_FILE *f = 0;
    int dir = 0;
    int r;

    if (arg[0] && arg[1] == ':' && arg[2] == 0 && arg[0] >= '1' && arg[0] <= '9') {
        int idx = arg[0] - '1';
        if (idx < 0 || idx >= vol_count) {
            t_puts("Partition not found.\n");
            return 0;
        }
        fs_select(idx);
        t_puts("Partition ");
        t_putc(arg[0]);
        t_puts(" selected.\n");
        return 0;
    }

    if (!normalize(cwd, arg, abs)) {
        t_puts(MSG_FAT_BADNAME);
        return 0;
    }
    if (abs[1] == 0) {
        if (vol_count == 0) {
            t_puts(MSG_FAT_ERR);
            return 0;
        }
        fs_reset_cwd();
        return 1;
    }
    r = open_on(cur_vol, abs, &f);
    if (r != FS_OK) {
        t_puts(fs_err_text(r));
        return 0;
    }
    if (!file_info(f, 0, &dir) || !dir) {
        f->Close(f);
        t_puts(MSG_FAT_NOTDIR);
        return 0;
    }
    f->Close(f);
    nx_strcpy(cwd, abs, sizeof(cwd));
    return 1;
}

void fs_type(const char *name)
{
    uint8_t *buf = 0;
    uint64_t size = 0;
    uint64_t i;
    int dir = 0;
    int r = fs_read_file(name, &buf, &size, &dir);
    if (r != FS_OK) {
        t_puts(fs_err_text(r));
        return;
    }
    for (i = 0; i < size; i++) {
        uint8_t c = buf[i];
        if (c == '\n') t_putw('\n');
        else if (c == '\r') continue;
        else if (c == '\t') t_putw('\t');
        else if (c >= 0x20 && c < 0x7F) t_putw(c);
        else t_putw('.');
        if ((i & 0xFF) == 0xFF) t_puts("");
    }
    t_puts("");
    t_puts("\n");
    fs_free(buf);
}

/* ======== splash ======== */

#define ANIM_GAP 128
#define ANIM_INF_LOOPS 2

static uint16_t rd16(const uint8_t *p)
{
    return (uint16_t)(p[0] | (p[1] << 8));
}

static void expand(EFI_BLT_PIXEL *dst, const uint8_t *bgr, uint32_t n)
{
    uint32_t i;
    for (i = 0; i < n; i++) {
        dst[i].Blue = bgr[i * 3];
        dst[i].Green = bgr[i * 3 + 1];
        dst[i].Red = bgr[i * 3 + 2];
        dst[i].Reserved = 0;
    }
}

static void play(EFI_GOP *gop, const uint8_t *frames, unsigned count, unsigned w, unsigned h, unsigned x, unsigned y, EFI_BLT_PIXEL *tmp)
{
    unsigned f;
    for (f = 0; f < count; f++) {
        expand(tmp, frames + (uint64_t)f * w * h * 3, w * h);
        gop->Blt(gop, tmp, EfiBltBufferToVideo, 0, 0, x, y, w, h, 0);
        gBS->Stall(16667);
    }
}

void splash_play(void)
{
    static const EFI_GUID gopg = EFI_GOP_GUID;
    EFI_GOP *gop = 0;
    uint8_t *logo = 0, *anim = 0;
    uint64_t lsz = 0, asz = 0;
    EFI_BLT_PIXEL *buf = 0, *fill = 0;
    unsigned W, H, lw, lh, aw, ah, ns, nl, lx, ly, ax, ay;
    unsigned loop;
    EFI_BLT_PIXEL black = {0, 0, 0, 0};

    if (fs_volume_count() == 0) return;
    if (EFI_ERROR(gBS->LocateProtocol(&gopg, 0, (void **)&gop)) || !gop || !gop->Mode || !gop->Mode->Info) return;
    if (fs_read_abs(fs_boot_volume(), "\\NXBoot\\LOGO.NXI", &logo, &lsz) != FS_OK || lsz < 8 || memcmp(logo, "NXIM", 4) != 0) {
        fs_free(logo);
        return;
    }
    W = gop->Mode->Info->HorizontalResolution;
    H = gop->Mode->Info->VerticalResolution;
    lw = rd16(logo + 4);
    lh = rd16(logo + 6);
    if (lsz < 8 + (uint64_t)lw * lh * 3 || lw > W || lh > H) {
        fs_free(logo);
        return;
    }
    if (EFI_ERROR(gBS->AllocatePool(EfiLoaderData, (UINTN)lw * lh * sizeof(EFI_BLT_PIXEL), (void **)&buf))) {
        fs_free(logo);
        return;
    }
    gop->Blt(gop, &black, EfiBltVideoFill, 0, 0, 0, 0, W, H, 0);
    expand(buf, logo + 8, lw * lh);
    lx = (W - lw) / 2;
    ly = (H - lh) / 2;
    gop->Blt(gop, buf, EfiBltBufferToVideo, 0, 0, lx, ly, lw, lh, 0);
    gBS->FreePool(buf);
    fs_free(logo);
    (void)fill;

    if (fs_read_abs(fs_boot_volume(), "\\NXBoot\\ANIM.NXA", &anim, &asz) != FS_OK || asz < 12 || memcmp(anim, "NXAN", 4) != 0) {
        fs_free(anim);
        t_delay_ms(2400);
        return;
    }
    aw = rd16(anim + 4);
    ah = rd16(anim + 6);
    ns = rd16(anim + 8);
    nl = rd16(anim + 10);
    ax = (W - aw) / 2;
    ay = ly + lh + ANIM_GAP;
    if (asz < 12 + (uint64_t)(ns + nl) * aw * ah * 3 || ay + ah > H || EFI_ERROR(gBS->AllocatePool(EfiLoaderData, (UINTN)aw * ah * sizeof(EFI_BLT_PIXEL), (void **)&buf))) {
        fs_free(anim);
        t_delay_ms(2400);
        return;
    }
    play(gop, anim + 12, ns, aw, ah, ax, ay, buf);
    for (loop = 0; loop < ANIM_INF_LOOPS; loop++) play(gop, anim + 12 + (uint64_t)ns * aw * ah * 3, nl, aw, ah, ax, ay, buf);
    gBS->FreePool(buf);
    fs_free(anim);
}

/* ======== boot ======== */

#define LOG_MAX 3072
#define KERNEL_BASE_DEF 0x100000ULL

static char logbuf[LOG_MAX];
static int loglen;

static const uint8_t tramp32[] = {
    0x66, 0xB8, 0x10, 0x00, 0x8E, 0xD8, 0x8E, 0xC0, 0x8E, 0xE0, 0x8E, 0xE8, 0x8E, 0xD0, 0x0F, 0x20,
    0xC0, 0x25, 0xFF, 0xFF, 0xFF, 0x7F, 0x0F, 0x22, 0xC0, 0xB9, 0x80, 0x00, 0x00, 0xC0, 0x0F, 0x32,
    0x25, 0xFF, 0xFE, 0xFF, 0xFF, 0x0F, 0x30, 0x0F, 0x20, 0xE0, 0x83, 0xE0, 0xDF, 0x0F, 0x22, 0xE0,
    0x89, 0xF4, 0xB8, 0x4E, 0x58, 0x42, 0x54, 0xFF, 0xE7
};

static uint64_t gdt[4] = {
    0, 0x00209A0000000000ULL, 0x00CF92000000FFFFULL, 0x00CF9A000000FFFFULL
};

static struct {
    uint16_t limit;
    uint64_t base;
} __attribute__((packed)) gdtr;

void boot_log_reset(void)
{
    loglen = 0;
    logbuf[0] = 0;
}

static void log_add(const char *s)
{
    while (*s && loglen < LOG_MAX - 1) logbuf[loglen++] = *s++;
    logbuf[loglen] = 0;
}

void bprint(const char *s)
{
    t_puts(s);
    log_add(s);
}

void bprint_hex(uint64_t v, int digits)
{
    char tmp[17];
    int i;
    for (i = 0; i < digits; i++) {
        int d = (int)((v >> ((digits - 1 - i) * 4)) & 0xF);
        tmp[i] = (char)(d < 10 ? '0' + d : 'A' + d - 10);
    }
    tmp[digits] = 0;
    bprint(tmp);
}

void boot_fail(const char *file, const char *reason)
{
    log_add("! ");
    log_add(reason);
    boot_error_screen(file, reason);
}

static int count_lines(void)
{
    int n = 0, i;
    if (loglen == 0) return 0;
    for (i = 0; i < loglen; i++) {
        if (logbuf[i] == '\n') n++;
    }
    if (logbuf[loglen - 1] != '\n') n++;
    return n;
}

static const char *line_ptr(int idx, int *len)
{
    int i = 0, n = 0;
    const char *start = logbuf;
    for (i = 0; i <= loglen; i++) {
        if (i == loglen || logbuf[i] == '\n') {
            if (n == idx) {
                int l = (int)(logbuf + i - start);
                while (l > 0 && start[l - 1] == '\r') l--;
                *len = l;
                return start;
            }
            n++;
            start = logbuf + i + 1;
        }
    }
    *len = 0;
    return logbuf;
}

static void draw_log(int top, int x, int y, int w, int h, int total)
{
    int i;
    for (i = 0; i < h; i++) {
        int len = 0;
        const char *p;
        char tmp[96];
        t_fill(x, y + i, w, ' ', 0x07);
        if (top + i < total) {
            p = line_ptr(top + i, &len);
            if (len > w) len = w;
            if (len > 90) len = 90;
            memcpy(tmp, p, (size_t)len);
            tmp[len] = 0;
            t_text(x, y + i, tmp, tmp[0] == '!' ? 0x0C : 0x07);
        }
    }
    for (i = 0; i < h; i++) t_fill(x + w + 2, y + i, 1, CH_LIGHT, 0x08);
    if (total > h) {
        int th = (top * (h - 1)) / (total - h);
        t_fill(x + w + 2, y + th, 1, CH_BLOCK, 0x0F);
    } else {
        t_fill(x + w + 2, y, 1, CH_BLOCK, 0x0F);
    }
}

void boot_error_screen(const char *file, const char *reason)
{
    int c, r, bx, by, i;
    const int W = 66, H = 17, LH = 10, LW = 60;
    int total = count_lines();
    int top = total > LH ? total - LH : 0;
    EFI_INPUT_KEY k;
    size_t fl, rl;

    t_cursor(0);
    t_attr(0x07);
    t_cls();
    t_size(&c, &r);
    bx = (c - W) / 2;
    by = 3;

    t_text(bx, 1, "Booting from ", 0x07);
    t_text_n(bx + 13, 1, file, 40, 0x0F);
    t_text(bx + 13 + (int)(nx_strlen(file) > 40 ? 40 : nx_strlen(file)), 1, "...", 0x07);

    t_fill(bx, by, 1, BOX_TL, 0x0C);
    t_fill(bx + 1, by, W - 2, BOX_H, 0x0C);
    t_fill(bx + W - 1, by, 1, BOX_TR, 0x0C);
    t_text(bx + 29, by, " Error! ", 0x4F);
    for (i = 1; i < H - 1; i++) {
        t_fill(bx, by + i, 1, BOX_V, 0x0C);
        t_fill(bx + 1, by + i, W - 2, ' ', 0x07);
        t_fill(bx + W - 1, by + i, 1, BOX_V, 0x0C);
    }
    t_fill(bx, by + 5, 1, BOX_ML, 0x0C);
    t_fill(bx + 1, by + 5, W - 2, BOX_SH, 0x08);
    t_fill(bx + W - 1, by + 5, 1, BOX_MR, 0x0C);
    t_text(bx + 2, by + 5, " Logs ", 0x0F);
    t_fill(bx, by + H - 1, 1, BOX_BL, 0x0C);
    t_fill(bx + 1, by + H - 1, W - 2, BOX_H, 0x0C);
    t_fill(bx + W - 1, by + H - 1, 1, BOX_BR, 0x0C);
    t_text(bx + 30, by + H - 1, "[ OK ]", 0x70);

    fl = nx_strlen(file);
    if (fl > 36) fl = 36;
    {
        int total_len = 17 + (int)fl + 1;
        int sx = bx + (W - total_len) / 2;
        t_text(sx, by + 2, "Cannot boot from ", 0x0F);
        t_text_n(sx + 17, by + 2, file, 36, 0x0E);
        t_text(sx + 17 + (int)fl, by + 2, "!", 0x0F);
    }
    rl = nx_strlen(reason);
    if (rl > 54) rl = 54;
    {
        int total_len = 8 + (int)rl;
        int sx = bx + (W - total_len) / 2;
        t_text(sx, by + 3, "Reason: ", 0x07);
        t_text_n(sx + 8, by + 3, reason, 54, 0x0C);
    }
    t_text(bx + 4, by + H + 1, "\xE2\x96\xB2\xE2\x96\xBC PgUp PgDn - scroll      Enter / Space - OK", 0x07);

    draw_log(top, bx + 2, by + 6, LW, LH, total);
    t_flush_keys();
    for (;;) {
        t_getkey(&k);
        if (k.UnicodeChar == 0x0D || k.UnicodeChar == ' ') break;
        if (k.ScanCode == KEY_UP && top > 0) top--;
        else if (k.ScanCode == KEY_DOWN) top++;
        else if (k.ScanCode == KEY_PGUP) top -= LH;
        else if (k.ScanCode == KEY_PGDN) top += LH;
        else if (k.ScanCode == KEY_HOME) top = 0;
        else if (k.ScanCode == KEY_END) top = 0x7FFF;
        else continue;
        if (top > total - LH) top = total - LH;
        if (top < 0) top = 0;
        draw_log(top, bx + 2, by + 6, LW, LH, total);
    }
    t_attr(0x07);
    t_cls();
    t_cursor(1);
    t_puts("Returned to the terminal.\n");
}

static uint32_t rd32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static uint64_t rd64(const uint8_t *p)
{
    return (uint64_t)rd32(p) | ((uint64_t)rd32(p + 4) << 32);
}

typedef struct {
    uint64_t dst;
    uint64_t off;
    uint64_t fsz;
    uint64_t msz;
} seg_t;

static int alloc_below(UINTN pages, uint64_t *addr)
{
    *addr = 0xFFFFFFFFULL;
    return !EFI_ERROR(gBS->AllocatePages(AllocateMaxAddress, EfiLoaderData, pages, addr));
}

static void e820_fill(nx_e820_t *out, uint32_t *count, EFI_MEMORY_DESCRIPTOR *map, UINTN size, UINTN dsz, uint64_t *top)
{
    UINTN i, n = size / dsz;
    uint32_t k = 0;
    *top = 0;
    for (i = 0; i < n && k < 900; i++) {
        EFI_MEMORY_DESCRIPTOR *d = (EFI_MEMORY_DESCRIPTOR *)((uint8_t *)map + i * dsz);
        uint32_t t;
        switch (d->Type) {
        case EfiLoaderCode: case EfiLoaderData: case EfiBootServicesCode: case EfiBootServicesData:
        case EfiConventionalMemory: t = 1; break;
        case EfiACPIReclaimMemory: t = 3; break;
        case EfiACPIMemoryNVS: t = 4; break;
        default: t = 2; break;
        }
        if (t == 1 && d->PhysicalStart + d->NumberOfPages * 4096 > *top) *top = d->PhysicalStart + d->NumberOfPages * 4096;
        if (k > 0 && out[k - 1].type == t && out[k - 1].base + out[k - 1].length == d->PhysicalStart) {
            out[k - 1].length += d->NumberOfPages * 4096;
        } else {
            out[k].base = d->PhysicalStart;
            out[k].length = d->NumberOfPages * 4096;
            out[k].type = t;
            out[k].attr = 1;
            k++;
        }
    }
    *count = k;
}

static void handoff(uint64_t entry, uint64_t info, uint64_t pml4, uint64_t stack, int want64, uint64_t tramp)
{
    gdtr.limit = sizeof(gdt) - 1;
    gdtr.base = (uint64_t)(uintptr_t)gdt;
    if (want64) {
        __asm__ volatile(
            "cli\n\t"
            "lgdt %[g]\n\t"
            "movq %%rsi, %%cr3\n\t"
            "pushq $0x08\n\t"
            "leaq 1f(%%rip), %%rax\n\t"
            "pushq %%rax\n\t"
            "lretq\n"
            "1:\n\t"
            "movw $0x10, %%ax\n\t"
            "movw %%ax, %%ds\n\t"
            "movw %%ax, %%es\n\t"
            "movw %%ax, %%fs\n\t"
            "movw %%ax, %%gs\n\t"
            "movw %%ax, %%ss\n\t"
            "movq %%rdx, %%rsp\n\t"
            "xorq %%rbp, %%rbp\n\t"
            "movl $0x5442584E, %%eax\n\t"
            "jmp *%%rcx\n\t"
            :
            : [g] "m"(gdtr), "c"(entry), "S"(pml4), "b"(info), "D"(info), "d"(stack)
            : "rax", "memory");
    } else {
        __asm__ volatile(
            "cli\n\t"
            "lgdt %[g]\n\t"
            "movq %%rax, %%cr3\n\t"
            "pushq $0x18\n\t"
            "pushq %%rcx\n\t"
            "lretq\n\t"
            :
            : [g] "m"(gdtr), "a"(pml4), "D"(entry), "b"(info), "S"(stack), "c"(tramp)
            : "memory");
    }
    for (;;) {
    }
}

static void launch(uint64_t entry, uint64_t lo, uint64_t hi, int want64, const char *file)
{
    uint64_t pt = 0, stk = 0, e820a = 0, infoa = 0, tr = 0;
    uint64_t *tab;
    nx_boot_info_t *bi;
    nx_e820_t *e8;
    EFI_MEMORY_DESCRIPTOR *map = 0;
    UINTN msz, key, dsz, tries;
    uint32_t ver, cnt = 0;
    uint64_t top = 0;
    EFI_GOP *gop = 0;
    static const EFI_GUID gopg = EFI_GOP_GUID;
    int i, j;

    if (!alloc_below(6, &pt) || !alloc_below(16, &stk) || !alloc_below(8, &e820a) || !alloc_below(1, &infoa) || !alloc_below(1, &tr)) {
        boot_fail(file, "Not enough RAM to load the kernel.\n");
        return;
    }
    memset((void *)(uintptr_t)pt, 0, 6 * 4096);
    tab = (uint64_t *)(uintptr_t)pt;
    tab[0] = (pt + 0x1000) | 3;
    tab[511] = (pt + 0x1000) | 3;
    {
        uint64_t *pdpt = tab + 512;
        uint64_t *pd = tab + 1024;
        for (i = 0; i < 4; i++) pdpt[i] = (pt + 0x2000 + (uint64_t)i * 0x1000) | 3;
        pdpt[510] = (pt + 0x2000) | 3;
        pdpt[511] = (pt + 0x3000) | 3;
        for (j = 0; j < 2048; j++) pd[j] = ((uint64_t)j * 0x200000ULL) | 0x83;
    }
    memcpy((void *)(uintptr_t)tr, tramp32, sizeof(tramp32));

    bi = (nx_boot_info_t *)(uintptr_t)infoa;
    memset(bi, 0, sizeof(*bi));
    e8 = (nx_e820_t *)(uintptr_t)e820a;

    if (!EFI_ERROR(gBS->LocateProtocol(&gopg, 0, (void **)&gop)) && gop && gop->Mode && gop->Mode->Info) {
        bi->fb_base = gop->Mode->FrameBufferBase;
        bi->fb_width = gop->Mode->Info->HorizontalResolution;
        bi->fb_height = gop->Mode->Info->VerticalResolution;
        bi->fb_pitch = gop->Mode->Info->PixelsPerScanLine * 4;
        bi->fb_bpp = 32;
    }
    {
        static const EFI_GUID acpi = EFI_ACPI20_GUID;
        UINTN k;
        for (k = 0; k < gST->NumberOfTableEntries; k++) {
            if (memcmp(&gST->ConfigurationTable[k].VendorGuid, &acpi, sizeof(acpi)) == 0) bi->acpi_rsdp = (uint64_t)(uintptr_t)gST->ConfigurationTable[k].VendorTable;
        }
    }

    msz = 0;
    gBS->GetMemoryMap(&msz, 0, &key, &dsz, &ver);
    msz += 8192;
    if (EFI_ERROR(gBS->AllocatePool(EfiLoaderData, msz, (void **)&map))) {
        boot_fail(file, "Not enough RAM to load the kernel.\n");
        return;
    }

    bi->magic = NX_BOOT_MAGIC;
    bi->drive = 0x80;
    bi->entry = (uint32_t)entry;
    bi->lo = (uint32_t)lo;
    bi->hi = (uint32_t)hi;
    bi->bits = want64 ? 64 : 32;
    bi->firmware = NX_FIRMWARE_UEFI;
    bi->entry64 = entry;
    bi->lo64 = lo;
    bi->hi64 = hi;
    bi->memmap = e820a;
    bi->memmap_entry_size = sizeof(nx_e820_t);
    bi->system_table = (uint64_t)(uintptr_t)gST;

    for (tries = 0; tries < 4; tries++) {
        UINTN sz = msz;
        if (EFI_ERROR(gBS->GetMemoryMap(&sz, map, &key, &dsz, &ver))) continue;
        e820_fill(e8, &cnt, map, sz, dsz, &top);
        bi->memmap_count = cnt;
        bi->ram_top = top > 0xFFFFFFFFULL ? 0xFFFFFFFFU : (uint32_t)top;
        bi->ram_top64 = top;
        if (!EFI_ERROR(gBS->ExitBootServices(gImage, key))) {
            handoff(entry, infoa, pt, stk + 16 * 4096, want64, tr);
        }
    }
    boot_fail(file, "Cannot leave UEFI boot services.\n");
}

void boot_do(char *args)
{
    char *file;
    char *p;
    uint64_t base = KERNEL_BASE_DEF;
    int want_long = 0;
    uint8_t *buf = 0;
    uint64_t size = 0;
    int dir = 0, r;
    seg_t seg[16];
    int nseg = 0;
    int kind;
    uint64_t entry = 0, lo = ~0ULL, hi = 0, entry_phys;
    uint64_t pg_lo, pg_hi, addr;
    EFI_STATUS st;
    int i;

    while (*args == ' ') args++;
    if (!*args) {
        t_puts("Usage: boot [file] [hex address] [long]\n");
        return;
    }
    file = args;
    p = args;
    while (*p && *p != ' ') p++;
    if (*p) *p++ = 0;
    while (*p) {
        while (*p == ' ') p++;
        if (!*p) break;
        if (nx_strieq(p, "long") || (p[0] == 'l' && p[1] == 'o' && p[2] == 'n' && p[3] == 'g' && (p[4] == 0 || p[4] == ' '))) {
            want_long = 1;
            p += 4;
        } else {
            uint64_t v;
            const char *e;
            if (!nx_parse_hex(p, &v, &e)) {
                t_puts("Usage: boot [file] [hex address] [long]\n");
                return;
            }
            base = v;
            p = (char *)e;
        }
    }

    boot_log_reset();
    bprint("Booting from ");
    bprint(file);
    bprint("...\n");

    if (fs_volume_count() == 0) {
        boot_fail(file, MSG_FAT_ERR);
        return;
    }
    if (fs_current() != fs_boot_volume()) fs_select(fs_boot_volume());
    r = fs_read_file(file, &buf, &size, &dir);
    if (r != FS_OK) {
        boot_fail(file, fs_err_text(r));
        return;
    }
    if (size == 0) {
        boot_fail(file, "File is empty.\n");
        return;
    }

    kind = 0;
    if (size >= 52 && buf[0] == 0x7F && buf[1] == 'E' && buf[2] == 'L' && buf[3] == 'F') {
        if (buf[5] != 1) {
            fs_free(buf);
            boot_fail(file, "Invalid File, or contents\n");
            return;
        }
        if (buf[4] == 2 && size >= 64 && rd16(buf + 18) == 62) {
            uint64_t phoff = rd64(buf + 32);
            unsigned phes = rd16(buf + 54), phn = rd16(buf + 56);
            kind = 2;
            entry = rd64(buf + 24);
            if (phn == 0 || phes < 56 || phoff + (uint64_t)phn * phes > size) kind = -1;
            for (i = 0; kind == 2 && i < (int)phn; i++) {
                const uint8_t *ph = buf + phoff + (uint64_t)i * phes;
                if (rd32(ph) != 1) continue;
                if (nseg >= 16 || rd64(ph + 32) > rd64(ph + 40) || rd64(ph + 8) + rd64(ph + 32) > size) {
                    kind = -1;
                    break;
                }
                seg[nseg].dst = rd64(ph + 24);
                if (seg[nseg].dst == 0 && rd64(ph + 16) >= 0xFFFFFFFF80000000ULL) seg[nseg].dst = rd64(ph + 16) - 0xFFFFFFFF80000000ULL;
                seg[nseg].off = rd64(ph + 8);
                seg[nseg].fsz = rd64(ph + 32);
                seg[nseg].msz = rd64(ph + 40);
                nseg++;
            }
        } else if (buf[4] == 1 && rd16(buf + 18) == 3) {
            uint32_t phoff = rd32(buf + 28);
            unsigned phes = rd16(buf + 42), phn = rd16(buf + 44);
            kind = 1;
            entry = rd32(buf + 24);
            if (phn == 0 || phes < 32 || (uint64_t)phoff + (uint64_t)phn * phes > size) kind = -1;
            for (i = 0; kind == 1 && i < (int)phn; i++) {
                const uint8_t *ph = buf + phoff + (uint64_t)i * phes;
                if (rd32(ph) != 1) continue;
                if (nseg >= 16 || rd32(ph + 16) > rd32(ph + 20) || (uint64_t)rd32(ph + 4) + rd32(ph + 16) > size) {
                    kind = -1;
                    break;
                }
                seg[nseg].dst = rd32(ph + 12);
                seg[nseg].off = rd32(ph + 4);
                seg[nseg].fsz = rd32(ph + 16);
                seg[nseg].msz = rd32(ph + 20);
                nseg++;
            }
        } else {
            kind = -1;
        }
        if (kind < 0 || nseg == 0) {
            fs_free(buf);
            boot_fail(file, "Invalid File, or contents\n");
            return;
        }
    } else {
        seg[0].dst = base;
        seg[0].off = 0;
        seg[0].fsz = size;
        seg[0].msz = size;
        nseg = 1;
        entry = base;
    }

    for (i = 0; i < nseg; i++) {
        if (seg[i].msz == 0) continue;
        if (seg[i].dst < lo) lo = seg[i].dst;
        if (seg[i].dst + seg[i].msz > hi) hi = seg[i].dst + seg[i].msz;
    }
    if (hi == 0 || lo == ~0ULL) {
        fs_free(buf);
        boot_fail(file, "Invalid File, or contents\n");
        return;
    }

    if (kind == 1 && want_long) {
        fs_free(buf);
        boot_fail(file, "Kernel is 32-bit, but Long Mode was requested.\n");
        return;
    }
    if (kind == 2) want_long = 1;

    if (lo < 0x100000) {
        fs_free(buf);
        boot_fail(file, "Kernel overlaps reserved memory below 1 MB.\n");
        return;
    }
    if (!want_long && hi > 0xFFFFFFFFULL) {
        fs_free(buf);
        boot_fail(file, "Entry point is outside the kernel image.\n");
        return;
    }

    entry_phys = entry;
    if (kind == 2 && (entry >> 32) == 0xFFFFFFFFULL && (entry & 0xFFFFFFFFULL) >= 0x80000000ULL) entry_phys = entry - 0xFFFFFFFF80000000ULL;
    if (entry_phys < lo || entry_phys >= hi) {
        fs_free(buf);
        boot_fail(file, "Entry point is outside the kernel image.\n");
        return;
    }

    pg_lo = lo & ~0xFFFULL;
    pg_hi = (hi + 0xFFF) & ~0xFFFULL;
    addr = pg_lo;
    st = gBS->AllocatePages(AllocateAddress, EfiLoaderData, (UINTN)((pg_hi - pg_lo) >> 12), &addr);
    if (EFI_ERROR(st)) {
        fs_free(buf);
        boot_fail(file, st == EFI_NOT_FOUND ? "Not enough RAM to load the kernel.\n" : "Memory at the kernel address is not writable.\n");
        return;
    }
    memset((void *)(uintptr_t)lo, 0, (size_t)(hi - lo));
    for (i = 0; i < nseg; i++) {
        if (seg[i].fsz) memcpy((void *)(uintptr_t)seg[i].dst, buf + seg[i].off, (size_t)seg[i].fsz);
    }
    fs_free(buf);

    bprint("Format: ");
    bprint(kind == 2 ? "ELF64\n" : kind == 1 ? "ELF32\n" : "flat binary\n");
    bprint("Entry:  0x");
    if (want_long) bprint_hex(entry >> 32, 8);
    bprint_hex(entry & 0xFFFFFFFFULL, 8);
    bprint("\nImage:  0x");
    bprint_hex(lo, 8);
    bprint(" - 0x");
    bprint_hex(hi, 8);
    bprint("\nStarting kernel...\n");
    t_pause_steps(4);
    launch(entry, lo, hi, want_long, file);
}

void cmd_boot_args(char *args)
{
    boot_do(args);
}

/* ======== diag ======== */

#define MAX_REG 64
#define CHUNK_BYTES (256ULL * 4096ULL)
#define DISK_CHUNK 64

typedef struct {
    uint64_t base;
    uint64_t len;
} reg_t;

static reg_t reg[MAX_REG];
static int nreg;

static EFI_BLOCK_IO *dbio;
static uint8_t *dbuf1;
static uint8_t *dbuf2;
static UINTN dbs;
static uint64_t dtotal;
static int disk_pick = 1;

static int word_ok(volatile uint32_t *p, uint32_t v)
{
    *p = v;
    return *p == v;
}

static uint64_t test_words(volatile uint32_t *p, uint64_t n, int mode)
{
    uint64_t bad = 0, i;
    for (i = 0; i < n; i++) {
        volatile uint32_t *q = p + i;
        uint32_t saved = *q;
        uint32_t a = (uint32_t)(uintptr_t)q;
        int ok = word_ok(q, 0xAAAAAAAAu) && word_ok(q, 0x55555555u);
        if (ok && mode > 0) ok = word_ok(q, a) && word_ok(q, ~a) && word_ok(q, 0) && word_ok(q, 0xFFFFFFFFu);
        if (ok && mode > 1) {
            uint32_t v = 1;
            do {
                ok = word_ok(q, v) && word_ok(q, ~v);
                v <<= 1;
            } while (ok && v);
        }
        *q = saved;
        if (!ok) bad++;
    }
    return bad;
}

static int mem_begin(uint64_t *total)
{
    UINTN size = 0, key, dsz, i, n;
    uint32_t ver;
    EFI_MEMORY_DESCRIPTOR *map = 0;
    uint8_t *mp;
    uint64_t sum = 0;
    nreg = 0;
    gBS->GetMemoryMap(&size, 0, &key, &dsz, &ver);
    size += 8192;
    if (EFI_ERROR(gBS->AllocatePool(EfiLoaderData, size, (void **)&map))) return 1;
    if (EFI_ERROR(gBS->GetMemoryMap(&size, map, &key, &dsz, &ver))) {
        gBS->FreePool(map);
        return 1;
    }
    n = size / dsz;
    mp = (uint8_t *)map;
    for (i = 0; i < n; i++) {
        EFI_MEMORY_DESCRIPTOR *d = (EFI_MEMORY_DESCRIPTOR *)(mp + i * dsz);
        uint64_t len;
        if (d->Type != EfiConventionalMemory || d->PhysicalStart < 0x100000) continue;
        len = d->NumberOfPages * 4096;
        if (nreg > 0 && reg[nreg - 1].base + reg[nreg - 1].len == d->PhysicalStart) {
            reg[nreg - 1].len += len;
        } else if (nreg < MAX_REG) {
            reg[nreg].base = d->PhysicalStart;
            reg[nreg].len = len;
            nreg++;
        } else {
            continue;
        }
        sum += len;
    }
    gBS->FreePool(map);
    *total = sum;
    return sum == 0;
}

static void mem_amount(char *out, int max)
{
    diag_fmt_size(out, max, sys_ram_bytes() >> 20);
}

static uint64_t mem_test(uint64_t first, uint64_t count, int mode)
{
    uint64_t bad = 0;
    int i;
    for (i = 0; i < nreg && first >= reg[i].len; i++) first -= reg[i].len;
    for (; i < nreg && count > 0; i++) {
        uint64_t addr = reg[i].base + first;
        uint64_t take = reg[i].len - first;
        if (take > count) take = count;
        count -= take;
        while (take > 0) {
            uint64_t step = take > CHUNK_BYTES ? CHUNK_BYTES : take;
            uint64_t pages = (step + 4095) / 4096;
            uint64_t a = addr;
            if (!EFI_ERROR(gBS->AllocatePages(AllocateAddress, EfiLoaderData, (UINTN)pages, &a))) {
                bad += test_words((volatile uint32_t *)(uintptr_t)addr, step / 4, mode);
                gBS->FreePages(addr, (UINTN)pages);
            }
            addr += step;
            take -= step;
        }
        first = 0;
    }
    return bad;
}

static void mem_end(void)
{
    nreg = 0;
}

static const diag_info_t mem_info = {
    " NXMemDiag 1.2 ",
    " Memory map ",
    "Memory Amount detected:",
    "Press \"Scan\" to start scanning your memory.",
    "Scanning your memory... That's will not take long.",
    "Your level of errors: Cracked Memory",
    "Do you want to exit from NXMemDiag?",
    "NXMemDiag 1.2. Made by NX Tech Community.",
    "Cannot read the memory map.",
    {"Welcome to MemDiag 1.2.", "This utility can help you with", "Memory diagnostic."},
    4096,
    mem_begin,
    mem_amount,
    mem_test,
    mem_end
};

static int disk_read(uint64_t lba, UINTN cnt, void *buf)
{
    return EFI_ERROR(dbio->ReadBlocks(dbio, dbio->Media->MediaId, lba, cnt * dbs, buf));
}

static int disk_begin(uint64_t *total)
{
    static const EFI_GUID bio = EFI_BLOCK_IO_GUID;
    UINTN n = 0, i;
    EFI_HANDLE *h = 0;
    int shown = 0;
    dbio = 0;
    dbuf1 = 0;
    dbuf2 = 0;
    if (EFI_ERROR(gBS->LocateHandleBuffer(ByProtocol, &bio, 0, &n, &h)) || n == 0) return 1;
    for (i = 0; i < n; i++) {
        EFI_BLOCK_IO *b = 0;
        if (EFI_ERROR(gBS->HandleProtocol(h[i], &bio, (void **)&b)) || !b || !b->Media) continue;
        if (!b->Media->MediaPresent || b->Media->LogicalPartition || b->Media->BlockSize == 0) continue;
        shown++;
        if (shown == disk_pick) {
            dbio = b;
            break;
        }
    }
    gBS->FreePool(h);
    if (!dbio) return 1;
    dbs = dbio->Media->BlockSize;
    dtotal = dbio->Media->LastBlock + 1;
    dbuf1 = nx_alloc(DISK_CHUNK * dbs);
    dbuf2 = nx_alloc(DISK_CHUNK * dbs);
    if (!dbuf1 || !dbuf2 || dtotal == 0) {
        nx_free(dbuf1);
        nx_free(dbuf2);
        dbuf1 = 0;
        dbuf2 = 0;
        return 1;
    }
    *total = dtotal;
    return 0;
}

static void disk_amount(char *out, int max)
{
    diag_fmt_size(out, max, (dtotal * dbs) >> 20);
}

static uint64_t disk_probe(uint64_t lba, uint64_t cnt, int mode)
{
    uint64_t bad = 0;
    while (cnt--) {
        int fail = disk_read(lba, 1, dbuf1);
        if (!fail && mode >= 2) fail = disk_read(lba, 1, dbuf2) || memcmp(dbuf1, dbuf2, dbs) != 0;
        if (fail) bad++;
        lba++;
    }
    if (bad == 0) bad = 1;
    return bad;
}

static uint64_t disk_range(uint64_t first, uint64_t count, int mode)
{
    uint64_t bad = 0;
    while (count) {
        uint64_t c = count > DISK_CHUNK ? DISK_CHUNK : count;
        int fail = disk_read(first, (UINTN)c, dbuf1);
        if (!fail && mode >= 2) fail = disk_read(first, (UINTN)c, dbuf2) || memcmp(dbuf1, dbuf2, (size_t)(c * dbs)) != 0;
        if (fail) bad += disk_probe(first, c, mode);
        first += c;
        count -= c;
    }
    return bad;
}

static uint64_t disk_test(uint64_t first, uint64_t count, int mode)
{
    uint64_t bad = 0;
    if (mode == 0) {
        if (disk_read(first, 1, dbuf1)) bad++;
        if (disk_read(first + count / 2, 1, dbuf1)) bad++;
        if (disk_read(first + count - 1, 1, dbuf1)) bad++;
        return bad;
    }
    return disk_range(first, count, mode);
}

static void disk_end(void)
{
    nx_free(dbuf1);
    nx_free(dbuf2);
    dbuf1 = 0;
    dbuf2 = 0;
    dbio = 0;
}

static const diag_info_t disk_info = {
    " NXDiagisk 1.0 ",
    " Disk map ",
    "Disk size detected:",
    "Press \"Scan\" to start scanning your disk.",
    "Scanning your disk... That's will not take long.",
    "Your level of errors: Cracked Disk",
    "Do you want to exit from NXDiagisk?",
    "NXDiagisk 1.0. Made by NX Tech Community.",
    "Cannot read the disk.",
    {"Welcome to NXDiagisk 1.0.", "This utility will scan your disk", "for defects."},
    4,
    disk_begin,
    disk_amount,
    disk_test,
    disk_end
};

static int parse_args(const char *arg, int *num)
{
    int mode = 0;
    char word[16];
    *num = 0;
    while (*arg) {
        int n = 0;
        while (*arg == ' ') arg++;
        if (!*arg) break;
        while (*arg && *arg != ' ' && n < 15) word[n++] = *arg++;
        word[n] = 0;
        while (*arg && *arg != ' ') arg++;
        if (word[0] >= '0' && word[0] <= '9') {
            int i, v = 0;
            for (i = 0; word[i] >= '0' && word[i] <= '9'; i++) v = v * 10 + (word[i] - '0');
            *num = v;
        } else if (nx_strieq(word, "normal")) {
            mode = 1;
        } else if (nx_strieq(word, "hard") || nx_strieq(word, "full")) {
            mode = 2;
        } else if (nx_strieq(word, "fast")) {
            mode = 0;
        }
    }
    return mode;
}

void memdiag_cmd(const char *arg)
{
    int num;
    int mode = parse_args(arg, &num);
    diag_run(&mem_info, mode);
}

void diagisk_cmd(const char *arg)
{
    int num;
    int mode = parse_args(arg, &num);
    disk_pick = num > 0 ? num : 1;
    diag_run(&disk_info, mode);
}

/* ======== diagui ======== */

#define A_BASE 0x1F
#define A_OK 0x1A
#define A_UNK 0x16
#define A_BAD 0x1C
#define A_DIM 0x17
#define A_WARN 0x1E
#define A_SEL 0x70
#define A_MENU 0x70
#define A_MENUSEL 0x0F
#define A_DLG 0x70
#define A_DLGSEL 0x1F

#define FRAME_W 80
#define FRAME_H 25
#define MAX_CELLS 462
#define CELL_COLS 42
#define CELL_ROW0 4
#define CELL_COL0 5
#define BAR_W 50
#define LVL_HARD 9
#define LVL_CRACKED 257

static const CHAR16 cs_dbl[6] = {0x2554, 0x2550, 0x2557, 0x2551, 0x255A, 0x255D};
static const CHAR16 cs_sng[6] = {0x250C, 0x2500, 0x2510, 0x2502, 0x2514, 0x2518};

static const diag_info_t *D;
static int ox, oy, scr_c, scr_r;
static int mode, phase, focus, bsel, mtop, paused, quit, found, almost;
static uint64_t total, cell_b, nc, idx, bad;
static t_rect_t rect;

static void put(int r, int c, const char *s, unsigned a)
{
    t_text(ox + c, oy + r, s, a);
}

static void fill(int r, int c, int n, CHAR16 ch, unsigned a)
{
    t_fill(ox + c, oy + r, n, ch, a);
}

static void pcen(int r, int c, int w, const char *s, unsigned a)
{
    int off = (w - (int)nx_strlen(s)) / 2;
    if (off < 0) off = 0;
    put(r, c + off, s, a);
}

static void box(int r, int c, int h, int w, const CHAR16 *cs, unsigned a)
{
    int i;
    fill(r, c, 1, cs[0], a);
    fill(r, c + 1, w - 2, cs[1], a);
    fill(r, c + w - 1, 1, cs[2], a);
    for (i = 1; i < h - 1; i++) {
        fill(r + i, c, 1, cs[3], a);
        fill(r + i, c + 1, w - 2, ' ', a);
        fill(r + i, c + w - 1, 1, cs[3], a);
    }
    fill(r + h - 1, c, 1, cs[4], a);
    fill(r + h - 1, c + 1, w - 2, cs[1], a);
    fill(r + h - 1, c + w - 1, 1, cs[5], a);
}

static void save(int r, int c, int h, int w)
{
    t_rect_save(&rect, ox + c, oy + r, w, h);
}

static int dec_str(char *out, uint64_t v)
{
    char tmp[24];
    int n = 0, i;
    if (v == 0) tmp[n++] = '0';
    while (v) {
        tmp[n++] = (char)('0' + (int)(v % 10));
        v /= 10;
    }
    for (i = 0; i < n; i++) out[i] = tmp[n - 1 - i];
    out[n] = 0;
    return n;
}

void diag_fmt_size(char *out, int max, uint64_t mb)
{
    char num[24];
    int n = 0;
    if (max < 24) {
        if (max > 0) out[0] = 0;
        return;
    }
    if (mb >= 1024) {
        uint64_t g = mb >> 10;
        uint64_t f = ((mb & 1023) * 10) >> 10;
        n += dec_str(out + n, g);
        if (f) {
            out[n++] = '.';
            dec_str(num, f);
            nx_strcpy(out + n, num, (size_t)(max - n));
            n += (int)nx_strlen(num);
        }
        nx_strcpy(out + n, " GB", (size_t)(max - n));
    } else {
        n += dec_str(out + n, mb);
        nx_strcpy(out + n, " MB", (size_t)(max - n));
    }
}

static void cell(uint64_t i, CHAR16 ch, unsigned a)
{
    t_cell(ox + CELL_COL0 + (int)(i % CELL_COLS), oy + CELL_ROW0 + (int)(i / CELL_COLS), ch, a);
}

static void draw_cells(void)
{
    uint64_t i;
    for (i = 0; i < MAX_CELLS; i++) {
        if (i < nc) cell(i, CH_LIGHT, A_DIM);
        else cell(i, ' ', A_BASE);
    }
}

static void show_errors(void)
{
    char buf[24];
    fill(11, 51, 12, ' ', A_BASE);
    dec_str(buf, bad);
    put(11, 51, buf, bad ? A_BAD : A_BASE);
}

static void progress(uint64_t done)
{
    uint64_t f = nc ? done * BAR_W / nc : BAR_W;
    uint64_t pct = nc ? done * 100 / nc : 100;
    char buf[24];
    int n;
    if (f > BAR_W) f = BAR_W;
    if (f) fill(19, 12, (int)f, CH_BLOCK, A_OK);
    if (f < BAR_W) fill(19, 12 + (int)f, BAR_W - (int)f, CH_LIGHT, A_DIM);
    put(19, 63, "    ", A_BASE);
    n = dec_str(buf, pct);
    put(19, 63 + 3 - n, buf, A_BASE);
    put(19, 66, "%", A_BASE);
}

static void set_msg(void)
{
    const char *m = almost ? "Almost done..." : D->scanning_msg;
    unsigned a = A_BASE;
    fill(18, 5, 70, ' ', A_BASE);
    if (paused) {
        m = "Scan paused.";
        a = A_WARN;
    }
    pcen(18, 5, 70, m, a);
}

static unsigned btn_attr(int i)
{
    return focus == 0 && bsel == i ? A_SEL : A_BASE;
}

static void draw_buttons(void)
{
    fill(20, 5, 70, ' ', A_BASE);
    if (phase == 2) {
        put(20, 37, "[Exit]", btn_attr(0));
        return;
    }
    put(20, 31, phase == 0 ? "[Scan]" : (paused ? "[Resume]" : "[Pause]"), btn_attr(0));
    put(20, 41, "[Exit]", btn_attr(1));
}

static void draw_menu(void)
{
    put(1, 2, " Help ", focus == 1 && mtop == 0 ? A_MENUSEL : A_MENU);
    put(1, 8, " Settings ", focus == 1 && mtop == 1 ? A_MENUSEL : A_MENU);
}

static int dialog(const char *title, const char *l1, const char *l2, int yn)
{
    int dsel = yn ? 1 : 0;
    int res = 0;
    EFI_INPUT_KEY k;
    save(8, 14, 7, 52);
    box(8, 14, 7, 52, cs_dbl, A_DLG);
    pcen(8, 14, 52, title, A_DLG);
    pcen(10, 14, 52, l1, A_DLG);
    if (l2) pcen(11, 14, 52, l2, A_DLG);
    for (;;) {
        int c;
        if (!yn) {
            put(13, 38, "[OK]", A_DLGSEL);
        } else {
            put(13, 33, "[Yes]", dsel == 0 ? A_DLGSEL : A_DLG);
            put(13, 42, "[No]", dsel == 1 ? A_DLGSEL : A_DLG);
        }
        t_getkey(&k);
        if (!yn) {
            if (k.UnicodeChar == 0x0D || k.UnicodeChar == ' ' || k.ScanCode == KEY_ESC) break;
            continue;
        }
        if (k.ScanCode == KEY_LEFT) {
            dsel = 0;
        } else if (k.ScanCode == KEY_RIGHT) {
            dsel = 1;
        } else if (k.ScanCode == KEY_ESC) {
            res = 0;
            break;
        } else if (k.UnicodeChar == 0x0D) {
            res = dsel == 0;
            break;
        } else {
            c = k.UnicodeChar | 0x20;
            if (c == 'y') {
                res = 1;
                break;
            }
            if (c == 'n') {
                res = 0;
                break;
            }
        }
    }
    t_rect_restore(&rect);
    return res;
}

static void exit_req(void)
{
    const char *q = phase == 1 ? "Scan Didn't ended up yet. Do you want to exit?" : D->exit_msg;
    if (dialog(" Confirmation ", q, 0, 1)) quit = 1;
}

static int drop(void)
{
    int sel = 0;
    EFI_INPUT_KEY k;
    save(2, 2, 5, 12);
    for (;;) {
        box(2, 2, 5, 12, cs_sng, A_MENU);
        put(3, 3, " About    ", sel == 0 ? A_MENUSEL : A_MENU);
        put(4, 3, " Creators ", sel == 1 ? A_MENUSEL : A_MENU);
        put(5, 3, " Exit     ", sel == 2 ? A_MENUSEL : A_MENU);
        t_getkey(&k);
        if (k.ScanCode == KEY_UP) {
            if (sel > 0) sel--;
        } else if (k.ScanCode == KEY_DOWN) {
            if (sel < 2) sel++;
        } else if (k.UnicodeChar == 0x0D) {
            break;
        } else if (k.ScanCode == KEY_ESC) {
            sel = -1;
            break;
        }
    }
    t_rect_restore(&rect);
    return sel;
}

static void settings(void)
{
    static const char *const uns[3] = {" Fast        ", " Normal Scan ", " Hard Scan   "};
    static const char *const sel_txt[3] = {">Fast<       ", ">Normal Scan<", ">Hard Scan<  "};
    int sel = mode, busy = 0, i;
    EFI_INPUT_KEY k;
    save(2, 8, 6, 22);
    for (;;) {
        box(2, 8, 6, 22, cs_sng, A_MENU);
        put(3, 9, "Select scan mode:", A_MENU);
        for (i = 0; i < 3; i++) {
            put(4 + i, 9, sel == i ? sel_txt[i] : uns[i], sel == i ? A_MENUSEL : A_MENU);
            put(4 + i, 23, mode == i ? "*" : " ", A_MENU);
        }
        t_getkey(&k);
        if (k.ScanCode == KEY_UP) {
            if (sel > 0) sel--;
        } else if (k.ScanCode == KEY_DOWN) {
            if (sel < 2) sel++;
        } else if (k.UnicodeChar == 0x0D) {
            if (phase == 1) busy = 1;
            else mode = sel;
            break;
        } else if (k.ScanCode == KEY_ESC) {
            break;
        }
    }
    t_rect_restore(&rect);
    if (busy) dialog(" Settings ", "Mode can't be changed while a scan is running.", 0, 0);
}

static void menu_open(void)
{
    int a;
    if (mtop == 1) {
        settings();
        return;
    }
    a = drop();
    if (a == 0) dialog(" About ", D->about_msg, "All rights reserved (c).", 0);
    else if (a == 1) dialog(" Creators ", "NXTech Community - Code, Algorithm.", "DakSeek (DmutriSHP) - Design, controls", 0);
    else if (a == 2) exit_req();
}

static void start_scan(void)
{
    phase = 1;
    paused = 0;
    bsel = 0;
    found = 0;
    almost = 0;
    fill(16, 5, 70, ' ', A_BASE);
    set_msg();
    progress(0);
    idx = 0;
    draw_buttons();
}

static void scan_done(void)
{
    const char *m = "Your level of errors: Safe";
    unsigned a = A_OK;
    phase = 2;
    paused = 0;
    bsel = 0;
    fill(18, 5, 70, ' ', A_BASE);
    if (bad) {
        a = A_WARN;
        m = "Your level of errors: Defects";
        if (bad >= LVL_HARD) {
            a = A_BAD;
            m = "Your level of errors: Hard";
        }
        if (bad >= LVL_CRACKED) m = D->cracked_msg;
    }
    pcen(18, 5, 70, m, a);
    draw_buttons();
}

static void scan_step(void)
{
    uint64_t first, count, errs;
    if (idx >= nc) {
        scan_done();
        return;
    }
    first = idx * cell_b;
    count = total - first < cell_b ? total - first : cell_b;
    errs = D->test(first, count, mode);
    bad += errs;
    if (errs == 0) cell(idx, CH_BLOCK, A_OK);
    else cell(idx, CH_LIGHT, A_BAD);
    show_errors();
    if (bad && !found) {
        found = 1;
        pcen(16, 5, 70, "Found Error!", A_BAD);
    }
    idx++;
    progress(idx);
    if (!almost && idx * 5 >= nc * 4) {
        almost = 1;
        set_msg();
    }
    if (idx >= nc) scan_done();
}

static void button_act(void)
{
    if (phase == 2 || bsel == 1) {
        exit_req();
        return;
    }
    if (phase == 0) {
        start_scan();
        return;
    }
    paused ^= 1;
    set_msg();
    draw_buttons();
}

static void handle_key(const EFI_INPUT_KEY *k)
{
    int c = k->UnicodeChar | 0x20;
    if (k->ScanCode == KEY_LEFT) {
        if (focus == 0) {
            if (bsel > 0) {
                bsel--;
                draw_buttons();
            }
        } else {
            mtop = 0;
            draw_menu();
        }
    } else if (k->ScanCode == KEY_RIGHT) {
        if (focus == 0) {
            int mx = phase == 2 ? 0 : 1;
            if (bsel < mx) {
                bsel++;
                draw_buttons();
            }
        } else {
            mtop = 1;
            draw_menu();
        }
    } else if (k->ScanCode == KEY_DOWN) {
        if (focus == 1) menu_open();
    } else if (k->ScanCode == KEY_UP) {
        return;
    } else if (k->ScanCode == KEY_ESC) {
        if (focus == 1) {
            focus = 0;
            draw_menu();
            draw_buttons();
        } else {
            exit_req();
        }
    } else if (k->UnicodeChar == 0x0D || k->UnicodeChar == ' ') {
        if (focus == 1) menu_open();
        else button_act();
    } else if (c == 'm') {
        focus = 1;
        draw_menu();
        draw_buttons();
    } else if (c == 's') {
        focus = 0;
        draw_menu();
        draw_buttons();
    }
}

static void paint(void)
{
    char sz[32];
    int r;
    for (r = 0; r < scr_r; r++) t_fill(0, r, scr_c, ' ', A_BASE);
    box(0, 0, 24, 80, cs_dbl, A_BASE);
    box(3, 4, 13, 44, cs_sng, A_BASE);
    box(3, 49, 13, 27, cs_sng, A_BASE);
    box(17, 4, 5, 72, cs_sng, A_BASE);
    put(0, 62, D->title, A_BASE);
    pcen(3, 4, 44, D->map_title, A_BASE);
    pcen(3, 49, 27, " Help ", A_BASE);
    pcen(17, 4, 72, " Scan ", A_BASE);
    fill(5, 51, 1, CH_BLOCK, A_OK);
    fill(6, 51, 1, CH_MID, A_UNK);
    fill(7, 51, 1, CH_LIGHT, A_BAD);
    fill(8, 51, 1, CH_LIGHT, A_DIM);
    put(5, 52, " - No errors", A_BASE);
    put(6, 52, " - Unknown", A_BASE);
    put(7, 52, " - Bad Sector", A_BASE);
    put(8, 52, " - Didn't scanned yet", A_BASE);
    put(10, 51, "Errors found:", A_BASE);
    put(12, 51, D->amount_label, A_BASE);
    D->amount(sz, sizeof(sz));
    put(13, 51, sz, A_BASE);
    bad = 0;
    show_errors();
    draw_cells();
    fill(1, 1, 78, ' ', A_MENU);
    fill(24, 0, 80, ' ', A_MENU);
    put(24, 1, "\xE2\x86\x90\xE2\x86\x91\xE2\x86\x93\xE2\x86\x92 - Move   M - Menu Section   S - Buttons section.", A_MENU);
    phase = 0;
    focus = 0;
    bsel = 0;
    paused = 0;
    quit = 0;
    pcen(18, 5, 70, D->press_msg, A_BASE);
    draw_menu();
    draw_buttons();
}

static int intro(void)
{
    int sel = 0;
    EFI_INPUT_KEY k;
    box(8, 20, 9, 40, cs_dbl, A_BASE);
    pcen(8, 20, 40, D->title, A_BASE);
    pcen(10, 20, 40, D->intro[0], A_BASE);
    pcen(11, 20, 40, D->intro[1], A_BASE);
    pcen(12, 20, 40, D->intro[2], A_BASE);
    pcen(14, 20, 40, "Press \"Start\" to Open Utility.", A_BASE);
    for (;;) {
        put(16, 31, "[Start]", sel == 0 ? A_SEL : A_BASE);
        put(16, 40, "[Cancel]", sel == 1 ? A_SEL : A_BASE);
        t_getkey(&k);
        if (k.ScanCode == KEY_LEFT) sel = 0;
        else if (k.ScanCode == KEY_RIGHT) sel = 1;
        else if (k.UnicodeChar == 0x0D) return sel == 0;
        else if (k.ScanCode == KEY_ESC) return 0;
    }
}

static void ui_loop(void)
{
    EFI_INPUT_KEY k;
    while (!quit) {
        if (phase == 1 && !paused) {
            if (t_pollkey(&k)) handle_key(&k);
            else scan_step();
        } else {
            t_getkey(&k);
            handle_key(&k);
        }
    }
}

void diag_run(const diag_info_t *d, int m)
{
    uint64_t per;
    t_size(&scr_c, &scr_r);
    if (scr_c < FRAME_W || scr_r < FRAME_H) {
        t_puts("The console is too small for this utility.\n");
        return;
    }
    D = d;
    mode = m;
    ox = (scr_c - FRAME_W) / 2;
    oy = (scr_r - FRAME_H) / 2;
    t_snapshot();
    t_cursor(0);
    if (intro()) {
        if (D->begin(&total)) {
            dialog(" Error ", D->fail_msg, 0, 0);
        } else {
            per = (total + MAX_CELLS - 1) / MAX_CELLS;
            cell_b = (per + D->align - 1) / D->align * D->align;
            if (cell_b == 0) cell_b = D->align;
            nc = (total + cell_b - 1) / cell_b;
            idx = 0;
            paint();
            ui_loop();
            D->end();
        }
    }
    t_restore();
    t_cursor(1);
    t_flush_keys();
}

/* ======== view ======== */

void *img_malloc(size_t size)
{
    return nx_alloc(size);
}

void img_free(void *ptr)
{
    nx_free(ptr);
}

static const char *decode_error(int r)
{
    switch (r) {
    case IMG_ERR_FORMAT: return "Unknown image format. PNG, JPEG and BMP are supported.\n";
    case IMG_ERR_MEMORY: return "Not enough RAM to load the image.\n";
    case IMG_ERR_UNSUPPORTED: return "This image type is not supported.\n";
    default: return "Invalid File, or contents\n";
    }
}

static void draw_image(EFI_GOP *gop, const image_t *img, unsigned W, unsigned H)
{
    EFI_BLT_PIXEL black = {0, 0, 0, 0};
    EFI_BLT_PIXEL *row;
    unsigned dw, dh, x0, y0, x, y;

    if (img->width <= W && img->height <= H) {
        dw = img->width;
        dh = img->height;
    } else if ((uint64_t)img->width * H > (uint64_t)img->height * W) {
        dw = W;
        dh = (unsigned)((uint64_t)img->height * W / img->width);
    } else {
        dh = H;
        dw = (unsigned)((uint64_t)img->width * H / img->height);
    }
    if (dw == 0) dw = 1;
    if (dh == 0) dh = 1;
    row = nx_alloc((size_t)dw * sizeof(EFI_BLT_PIXEL));
    if (!row) return;
    x0 = (W - dw) / 2;
    y0 = (H - dh) / 2;
    gop->Blt(gop, &black, EfiBltVideoFill, 0, 0, 0, 0, W, H, 0);
    for (y = 0; y < dh; y++) {
        uint32_t sy = (uint32_t)((uint64_t)y * img->height / dh);
        for (x = 0; x < dw; x++) {
            uint32_t sx = (uint32_t)((uint64_t)x * img->width / dw);
            const uint8_t *px = img->pixels + ((size_t)sy * img->width + sx) * 4;
            uint32_t a = px[3];
            row[x].Red = (uint8_t)(px[0] * a / 255);
            row[x].Green = (uint8_t)(px[1] * a / 255);
            row[x].Blue = (uint8_t)(px[2] * a / 255);
            row[x].Reserved = 0;
        }
        gop->Blt(gop, row, EfiBltBufferToVideo, 0, 0, x0, y0 + y, dw, 1, 0);
    }
    nx_free(row);
}

void cmd_view(const char *arg)
{
    static const EFI_GUID gopg = EFI_GOP_GUID;
    EFI_GOP *gop = 0;
    EFI_BLT_PIXEL black = {0, 0, 0, 0};
    EFI_INPUT_KEY k;
    uint8_t *buf = 0;
    uint64_t size = 0;
    int dir = 0, r, c, rws;
    image_t img;
    unsigned W, H;

    if (!*arg) {
        t_puts("Usage: view [file]\n");
        return;
    }
    if (EFI_ERROR(gBS->LocateProtocol(&gopg, 0, (void **)&gop)) || !gop || !gop->Mode || !gop->Mode->Info) {
        t_puts("Graphics output is not available.\n");
        return;
    }
    r = fs_read_file(arg, &buf, &size, &dir);
    if (r != FS_OK) {
        t_puts(fs_err_text(r));
        return;
    }
    if (size == 0) {
        fs_free(buf);
        t_puts("File is empty.\n");
        return;
    }
    r = image_decode(buf, (size_t)size, &img);
    fs_free(buf);
    if (r != IMG_OK) {
        t_puts(decode_error(r));
        return;
    }
    W = gop->Mode->Info->HorizontalResolution;
    H = gop->Mode->Info->VerticalResolution;
    t_size(&c, &rws);
    t_snapshot();
    t_cursor(0);
    draw_image(gop, &img, W, H);
    t_text(0, rws - 1, " Press any key to return. ", 0x70);
    image_free(&img);
    t_flush_keys();
    t_getkey(&k);
    gop->Blt(gop, &black, EfiBltVideoFill, 0, 0, 0, 0, W, H, 0);
    gST->ConOut->ClearScreen(gST->ConOut);
    t_restore();
    t_cursor(1);
}

/* ======== cmd ======== */

int g_skip_gap;
int g_close_requested;

static const char MSG_HELP[] =
    "Available commands:\n"
    "  help          - shows this help message\n"
    "  boot [file]   - loads and starts a kernel (ELF32, ELF64 or flat BIN)\n"
    "                  BIN options: boot [file] [hex address] [long]\n"
    "  dir           - lists files in the current FAT32 directory\n"
    "  cd [dir|N:]   - changes directory or partition (1:, 2:)\n"
    "  type [file]   - prints the contents of a FAT32 file\n"
    "  multiboot [file] - opens the boot menu (file lines: Name=file [address] [long])\n"
    "  remode [mode] - changes the current mode (real, protected, long)\n"
    "  color [c]     - changes text color (r g b y c m w d reset fcr)\n"
    "  cls           - clears the screen\n"
    "  view [file]   - shows a PNG, JPEG or BMP image from a FAT32 file\n"
    "  memdiag [mode] - starts the memory diagnostic utility (fast, normal, hard)\n"
    "  diagisk [N] [mode] - starts the disk diagnostic utility for disk N\n"
    "  close         - closes the terminal and returns to the error screen\n"
    "  exit          - reboots your machine\n"
    "  time          - shows the current time\n"
    "  shutdown      - shuts down your machine\n"
    "  about         - shows info about the bootloader and the terminal\n"
    "  sysinf        - shows your current system specification\n";

typedef struct {
    const char *a;
    const char *b;
    unsigned attr;
} color_t;

static const color_t colors[] = {
    {"r", "red", 0x0C}, {"g", "green", 0x0A}, {"b", "blue", 0x09}, {"y", "yellow", 0x0E},
    {"c", "cyan", 0x0B}, {"m", "magenta", 0x0D}, {"w", "white", 0x0F}, {"d", "default", 0x07},
    {"reset", "reset", 0x07}, {"fcr", "fcr", 0x07}, {0, 0, 0}
};

static char *skip(char *s)
{
    while (*s == ' ') s++;
    return s;
}

static int match(char *line, const char *cmd, char **args)
{
    size_t n = nx_strlen(cmd);
    size_t i;
    for (i = 0; i < n; i++) {
        if (nx_upper(line[i]) != nx_upper(cmd[i])) return 0;
    }
    if (line[n] != 0 && line[n] != ' ') return 0;
    *args = skip(line + n);
    return 1;
}

uint64_t sys_ram_bytes(void)
{
    UINTN size = 0, key, dsz;
    uint32_t ver;
    EFI_MEMORY_DESCRIPTOR *map = 0;
    uint64_t total = 0;
    UINTN i;
    uint8_t *p;
    gBS->GetMemoryMap(&size, 0, &key, &dsz, &ver);
    size += 4096;
    if (EFI_ERROR(gBS->AllocatePool(EfiLoaderData, size, (void **)&map))) return 0;
    if (!EFI_ERROR(gBS->GetMemoryMap(&size, map, &key, &dsz, &ver))) {
        p = (uint8_t *)map;
        for (i = 0; i < size / dsz; i++) {
            EFI_MEMORY_DESCRIPTOR *d = (EFI_MEMORY_DESCRIPTOR *)(p + i * dsz);
            switch (d->Type) {
            case EfiLoaderCode: case EfiLoaderData: case EfiBootServicesCode: case EfiBootServicesData:
            case EfiConventionalMemory: case EfiACPIReclaimMemory: case EfiACPIMemoryNVS:
            case EfiRuntimeServicesCode: case EfiRuntimeServicesData:
                total += d->NumberOfPages * 4096;
                break;
            default: break;
            }
        }
    }
    gBS->FreePool(map);
    return total;
}

static void two(unsigned v)
{
    t_putc((char)('0' + v / 10));
    t_putc((char)('0' + v % 10));
}

void sys_time_print(void)
{
    EFI_TIME t;
    if (EFI_ERROR(gST->RuntimeServices->GetTime(&t, 0))) {
        t_puts("Cannot read the clock.\n");
        return;
    }
    two(t.Hour);
    t_putc(':');
    two(t.Minute);
    t_putc(':');
    two(t.Second);
    t_putc('\n');
}

void do_reboot(void)
{
    gST->RuntimeServices->ResetSystem(EfiResetCold, 0, 0, 0);
    for (;;) {
    }
}

void do_shutdown(void)
{
    gST->RuntimeServices->ResetSystem(EfiResetShutdown, 0, 0, 0);
    for (;;) {
    }
}

static void cmd_sysinf(void)
{
    static const char *art[6] = {
        " NN   NN   XX   XX        ", " NNN  NN    XX XX         ", " NN N NN     XXX          ",
        " NN  NNN    XX XX         ", " NN   NN   XX   XX        ", " B    O     O    T v0.9   "
    };
    static const char *lab[6] = {"Build Date:", "Terminal:", "RAM:", "CPU:", "NOS:", "Mode:"};
    uint64_t mb = sys_ram_bytes() >> 20;
    int i;
    unsigned saved = t_get_attr();
    for (i = 0; i < 6; i++) {
        t_attr(0x0B);
        t_puts(art[i]);
        t_puts(lab[i]);
        t_attr(0x0F);
        t_putc(' ');
        switch (i) {
        case 0: t_puts(NX_BUILD_DATE); break;
        case 1: t_puts("NXBoot " NX_VERSION); break;
        case 2: t_dec(mb); t_puts(" MB"); break;
        case 3: t_puts("X64"); break;
        case 4:
            if (mb >= 3) {
                t_attr(0x0A);
                t_puts("Can run NixelOS.");
            } else {
                t_attr(0x0C);
                t_puts("Can't run NixelOS.");
            }
            break;
        default: t_puts("UEFI Long"); break;
        }
        t_putc('\n');
    }
    t_attr(saved);
}

static void cmd_color(char *a)
{
    const color_t *c;
    if (!*a) {
        t_puts("Usage: color [r|g|b|y|c|m|w|d|reset|fcr]\n");
        return;
    }
    for (c = colors; c->a; c++) {
        if (nx_strieq(a, c->a) || nx_strieq(a, c->b)) {
            t_attr(c->attr);
            t_puts("Text color changed.\n");
            return;
        }
    }
    t_puts("Unknown color. Use: r red, g green, b blue, y yellow,\n"
           "c cyan, m magenta, w white, d default, reset, fcr (full reset).\n");
}

static void cmd_remode(char *a)
{
    if (!*a) {
        t_puts("Usage: remode [real|protected|long]\n");
        return;
    }
    if (nx_strieq(a, "long")) {
        t_puts("You are already in this mode.\n");
        return;
    }
    if (nx_strieq(a, "real") || nx_strieq(a, "protected") || nx_strieq(a, "prot")) {
        t_puts("UEFI runs in Long Mode (64-bit) only. Use the BIOS boot to change modes.\n");
        return;
    }
    t_puts("Unknown mode. Available modes: real, protected, long.\n");
}

void cmd_run(char *line)
{
    char *a;
    g_skip_gap = 0;
    if (!line[0]) return;
    if (match(line, "help", &a)) t_puts(MSG_HELP);
    else if (match(line, "exit", &a)) {
        if (t_confirm(1)) do_reboot();
    } else if (match(line, "time", &a)) sys_time_print();
    else if (match(line, "boot", &a)) cmd_boot_args(a);
    else if (match(line, "shutdown", &a)) {
        if (t_confirm(0)) do_shutdown();
    } else if (match(line, "about", &a))
        t_puts("NXBoot - a bootloader made by Nixel Tech community for NixelOS.\n\nNixelOS (c). All rights reserved!\n");
    else if (match(line, "sysinf", &a)) cmd_sysinf();
    else if (match(line, "dir", &a)) fs_dir();
    else if (match(line, "cd", &a)) {
        if (!*a) t_puts("Usage: cd [dir | / | 1: | 2:]\n");
        else if (fs_cd(a)) g_skip_gap = 1;
    } else if (match(line, "type", &a)) {
        if (!*a) t_puts("Usage: type [file]\n");
        else fs_type(a);
    } else if (match(line, "remode", &a)) cmd_remode(a);
    else if (match(line, "close", &a)) {
        t_pause_steps(4);
        g_close_requested = 1;
    } else if (match(line, "color", &a)) cmd_color(a);
    else if (match(line, "multiboot", &a)) cmd_multiboot(a);
    else if (match(line, "cls", &a)) {
        t_cls();
        g_skip_gap = 1;
    } else if (match(line, "memdiag", &a)) memdiag_cmd(a);
    else if (match(line, "diagisk", &a)) diagisk_cmd(a);
    else if (match(line, "view", &a)) cmd_view(a);
    else t_puts("Unknown command. Type 'help' for a list of commands.\n");
}

int terminal_run(void)
{
    char line[128];
    int tc, tr;
    g_close_requested = 0;
    t_size(&tc, &tr);
    t_center(tr - 1, "Please wait...", 0x07);
    splash_play();
    t_attr(0x07);
    t_cls();
    t_attr(0x0F);
    t_puts("Welcome to NXBoot Terminal!\n");
    t_attr(0x07);
    t_puts("Type \"help\" to see list of all commands.\n");
    t_flush_keys();
    while (!g_close_requested) {
        t_puts(NX_PROMPT);
        t_readline(line, sizeof(line));
        cmd_run(line);
        if (g_close_requested) break;
        if (line[0] && !g_skip_gap) t_putc('\n');
    }
    fs_reset_cwd();
    fs_select(0);
    t_attr(0x07);
    return 0;
}

#define MB_MAX 16
#define MB_VIS 8

typedef struct {
    char name[40];
    char args[72];
} mb_entry_t;

static mb_entry_t mb_ent[MB_MAX];

static int mb_parse(char *text, uint64_t len)
{
    int n = 0;
    uint64_t i = 0;
    while (i < len && n < MB_MAX) {
        char *ls = text + i;
        char *eq = 0;
        char *p;
        while (i < len && text[i] != '\n') i++;
        if (i < len) text[i++] = 0;
        else text[len] = 0;
        p = ls;
        while (*p) {
            if (*p == '\r') *p = 0;
            p++;
        }
        for (p = ls; *p; p++) {
            if (*p == '=') {
                eq = p;
                break;
            }
        }
        if (!eq || eq == ls) continue;
        *eq = 0;
        {
            char *nm = skip(ls);
            char *ar = skip(eq + 1);
            if (!*ar) continue;
            nx_strcpy(mb_ent[n].name, nm, sizeof(mb_ent[n].name));
            nx_strcpy(mb_ent[n].args, ar, sizeof(mb_ent[n].args));
            n++;
        }
    }
    return n;
}

void cmd_multiboot(char *args)
{
    uint8_t *buf = 0;
    uint64_t size = 0;
    int dir = 0;
    int r, n, sel = 0, top = 0, rows_n, c, rws, y0, i, x0;
    EFI_INPUT_KEY k;
    char *text;

    if (!*args) {
        t_puts("Usage: multiboot [file]\n");
        return;
    }
    if (fs_current() != fs_boot_volume()) fs_select(fs_boot_volume());
    r = fs_read_file(args, &buf, &size, &dir);
    if (r != FS_OK) {
        t_puts(fs_err_text(r));
        return;
    }
    if (size == 0) {
        t_puts("File is empty.\n");
        return;
    }
    if (size > 4095) {
        fs_free(buf);
        t_puts("Invalid File, or contents\n");
        return;
    }
    if (EFI_ERROR(gBS->AllocatePool(EfiLoaderData, (UINTN)size + 1, (void **)&text))) {
        fs_free(buf);
        t_puts("Not enough RAM to load the kernel.\n");
        return;
    }
    memcpy(text, buf, (size_t)size);
    text[size] = 0;
    fs_free(buf);
    n = mb_parse(text, size);
    gBS->FreePool(text);
    if (n == 0) {
        t_puts("No boot entries found. Line format: Name=file [hex address] [long]\n");
        return;
    }

    t_size(&c, &rws);
    rows_n = n > MB_VIS ? MB_VIS : n;
    y0 = (rws - 4 - rows_n) / 2;
    x0 = (c - 60) / 2;
    t_snapshot();
    t_cursor(0);
    t_fill(0, 0, c, ' ', 0x07);
    for (i = 0; i < rws; i++) t_fill(0, i, c, ' ', 0x07);
    for (;;) {
        t_fill(x0, y0, 1, BOX_STL, 0x1F);
        t_fill(x0 + 1, y0, 58, BOX_SH, 0x1F);
        t_fill(x0 + 59, y0, 1, BOX_STR, 0x1F);
        t_text(x0 + 21, y0, " NXBoot Multiboot ", 0x1F);
        t_fill(x0, y0 + 1, 1, BOX_SV, 0x1F);
        t_text(x0 + 1, y0 + 1, " Select operating system.                                 ", 0x1F);
        t_fill(x0 + 59, y0 + 1, 1, BOX_SV, 0x1F);
        t_fill(x0, y0 + 2, 1, BOX_SML, 0x1F);
        t_fill(x0 + 1, y0 + 2, 58, BOX_SH, 0x1F);
        t_fill(x0 + 59, y0 + 2, 1, BOX_SMR, 0x1F);
        for (i = 0; i < rows_n; i++) {
            int idx = top + i;
            unsigned at = idx == sel ? 0x70 : 0x1F;
            t_fill(x0, y0 + 3 + i, 1, BOX_SV, 0x1F);
            t_fill(x0 + 1, y0 + 3 + i, 58, ' ', at);
            t_text_n(x0 + 2, y0 + 3 + i, mb_ent[idx].name, 40, at);
            t_fill(x0 + 59, y0 + 3 + i, 1, BOX_SV, 0x1F);
        }
        t_fill(x0, y0 + 3 + rows_n, 1, BOX_SBL, 0x1F);
        t_fill(x0 + 1, y0 + 3 + rows_n, 58, BOX_SH, 0x1F);
        t_fill(x0 + 59, y0 + 3 + rows_n, 1, BOX_SBR, 0x1F);
        t_getkey(&k);
        if (k.ScanCode == KEY_UP && sel > 0) {
            sel--;
            if (sel < top) top = sel;
        } else if (k.ScanCode == KEY_DOWN && sel + 1 < n) {
            sel++;
            if (sel >= top + rows_n) top = sel - rows_n + 1;
        } else if (k.UnicodeChar == 0x0D || k.UnicodeChar == ' ') {
            break;
        } else if (k.ScanCode == KEY_ESC) {
            sel = -1;
            break;
        }
    }
    t_restore();
    t_cursor(1);
    if (sel >= 0) {
        char line[96];
        nx_strcpy(line, mb_ent[sel].args, sizeof(line));
        cmd_boot_args(line);
    }
}

/* ======== main ======== */

EFI_SYSTEM_TABLE *gST;
EFI_BOOT_SERVICES *gBS;
EFI_HANDLE gImage;
EFI_HANDLE gBootDevice;

static const char *err_msg = "Cannot boot NixelOS. Error code: CANNOT_BOOT";

void early_gate(void)
{
}

static int early_poll(void)
{
    int i;
    EFI_INPUT_KEY k;
    t_cls();
    t_cursor(1);
    t_goto(0, 0);
    for (i = 0; i < 8; i++) {
        if (t_pollkey(&k) && (k.UnicodeChar == 't' || k.UnicodeChar == 'T')) return 1;
        t_delay_ms(150);
    }
    return 0;
}

static void err_draw_buttons(int sel)
{
    static const char *const names[3] = {"     Reboot     ", "    Shutdown    ", "Run BL Terminal "};
    int c, r, i;
    t_size(&c, &r);
    for (i = 0; i < 3; i++) t_center(14 + i, names[i], sel == i ? 0x70 : 0x07);
}

int error_screen(void)
{
    int sel = 0;
    EFI_INPUT_KEY k;
    t_attr(0x07);
    t_cls();
    t_cursor(0);
    t_center(7, "Error!", 0x04);
    t_center(9, err_msg, 0x0F);
    t_center(11, "Check https://t.me/NixelOS for more information.", 0x07);
    t_center(12, "Try to Reboot your PC, or shutdown it...", 0x07);
    for (;;) {
        err_draw_buttons(sel);
        t_getkey(&k);
        if (k.ScanCode == KEY_UP) {
            if (sel > 0) sel--;
        } else if (k.ScanCode == KEY_DOWN) {
            if (sel < 2) sel++;
        } else if (k.UnicodeChar == 't' || k.UnicodeChar == 'T') {
            return 1;
        } else if (k.UnicodeChar == 0x0D) {
            if (sel == 0) {
                if (t_confirm(1)) do_reboot();
            } else if (sel == 1) {
                if (t_confirm(0)) do_shutdown();
            } else {
                return 1;
            }
        }
    }
}

EFI_STATUS EFIAPI efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *st)
{
    static const EFI_GUID li_guid = EFI_LOADED_IMAGE_GUID;
    EFI_LOADED_IMAGE *li = 0;

    gST = st;
    gBS = st->BootServices;
    gImage = image;
    gBootDevice = 0;
    if (!EFI_ERROR(gBS->HandleProtocol(image, &li_guid, (void **)&li)) && li) gBootDevice = li->DeviceHandle;
    gBS->SetWatchdogTimer(0, 0, 0, 0);

    t_init();
    fs_init();

    if ((sys_ram_bytes() >> 10) < 3072) err_msg = "Cannot boot NixelOS. Error code: NOT_ENOUGH_RAM";

    if (early_poll()) terminal_run();
    for (;;) {
        if (error_screen()) terminal_run();
    }
}
