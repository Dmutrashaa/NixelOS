#!/usr/bin/env python3
import os
import re
import struct
import sys

TARGET_SIZE = 64


def fail(msg):
    sys.stderr.write("mkanim: " + msg + "\n")
    sys.exit(1)


def frame_list(folder):
    if not os.path.isdir(folder):
        fail("folder '%s' not found (unpack %s.zip here)" % (folder, folder))
    nums = []
    for name in os.listdir(folder):
        m = re.fullmatch(r"(\d+)\.bmp", name, re.IGNORECASE)
        if m:
            nums.append((int(m.group(1)), name))
    if not nums:
        fail("no N.bmp files in '%s'" % folder)
    nums.sort()
    for idx, (n, _) in enumerate(nums):
        if n != idx:
            fail("'%s': frame numbering has a gap (expected %d.bmp)" % (folder, idx))
    return [os.path.join(folder, name) for _, name in nums]


def load_bmp(path):
    with open(path, "rb") as f:
        b = f.read()
    if b[:2] != b"BM":
        fail("%s: not a BMP" % path)
    off = struct.unpack_from("<I", b, 10)[0]
    _hs, w, h, _pl, bpp, comp = struct.unpack_from("<IiiHHI", b, 14)
    if bpp != 24 or comp != 0:
        fail("%s: need 24-bit uncompressed BMP (got %d bpp, compression %d)" % (path, bpp, comp))
    bottom_up = h > 0
    h = abs(h)
    stride = (w * 3 + 3) & ~3
    if len(b) < off + stride * h:
        fail("%s: file is truncated" % path)
    rows = [b[off + y * stride: off + y * stride + w * 3] for y in range(h)]
    if bottom_up:
        rows.reverse()
    return w, h, b"".join(rows)


def downscale(data, w, h, target):
    if w % target or h % target or w // target != h // target:
        fail("cannot shrink %dx%d to %dx%d by a whole factor" % (w, h, target, target))
    f = w // target
    if f == 1:
        return data
    ow = w // f
    half = (f * f) // 2
    rows = [data[y * w * 3:(y + 1) * w * 3] for y in range(h)]
    out = bytearray()
    for y in range(0, h, f):
        block = rows[y:y + f]
        row = bytearray(ow * 3)
        for c in range(3):
            col_sums = [sum(t) for t in zip(*[r[c::3] for r in block])]
            row[c::3] = bytes((sum(col_sums[i:i + f]) + half) // (f * f)
                              for i in range(0, w, f))
        out += row
    return bytes(out)


def read_logo(inc):
    text = open(inc).read()
    w = int(re.search(r"img_width\s+equ\s+(\d+)", text).group(1))
    h = int(re.search(r"img_height\s+equ\s+(\d+)", text).group(1))
    data = bytearray()
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("db "):
            for tok in line[3:].split(","):
                tok = tok.strip()
                if tok:
                    data.append(int(tok, 16) if tok.lower().startswith("0x") else int(tok))
    if len(data) < w * h * 3:
        fail("image_data.inc is shorter than %dx%d" % (w, h))
    return w, h, bytes(data[:w * h * 3])


def main():
    if len(sys.argv) != 4:
        fail("usage: mkanim.py FRAMES_DIR BIOS_DIR UEFI_DIR")
    frames_dir, bios_dir, uefi_dir = sys.argv[1:4]
    start = frame_list(os.path.join(frames_dir, "START"))
    loop = frame_list(os.path.join(frames_dir, "INFINITE"))
    os.makedirs(uefi_dir, exist_ok=True)

    size = None
    blob = bytearray()
    for path in start + loop:
        w, h, data = load_bmp(path)
        if TARGET_SIZE:
            data = downscale(data, w, h, TARGET_SIZE)
            w = h = TARGET_SIZE
        if size is None:
            size = (w, h)
        elif size != (w, h):
            fail("%s: size differs" % path)
        blob += data

    with open(os.path.join(bios_dir, "anim.bin"), "wb") as f:
        f.write(blob)
    with open(os.path.join(bios_dir, "anim_info.inc"), "w") as inc:
        inc.write("ANIM_W            equ %d\n" % size[0])
        inc.write("ANIM_H            equ %d\n" % size[1])
        inc.write("ANIM_START_FRAMES equ %d\n" % len(start))
        inc.write("ANIM_INF_FRAMES   equ %d\n" % len(loop))
    with open(os.path.join(uefi_dir, "ANIM.NXA"), "wb") as f:
        f.write(b"NXAN" + struct.pack("<HHHH", size[0], size[1], len(start), len(loop)) + blob)

    lw, lh, ld = read_logo(os.path.join(bios_dir, "image_data.inc"))
    with open(os.path.join(uefi_dir, "LOGO.NXI"), "wb") as f:
        f.write(b"NXIM" + struct.pack("<HH", lw, lh) + ld)

    print("mkanim: %dx%d, %d start + %d loop frames, logo %dx%d" % (size[0], size[1], len(start), len(loop), lw, lh))


if __name__ == "__main__":
    main()
