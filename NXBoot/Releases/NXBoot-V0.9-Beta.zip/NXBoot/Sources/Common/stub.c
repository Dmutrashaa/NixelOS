#include "efi.h"

#ifndef NX_TARGET_PATH
#error NX_TARGET_PATH must be defined, for example u"\\NXBoot\\X86\\NXBoot.EFI"
#endif

static const EFI_GUID g_loaded_image = EFI_LOADED_IMAGE_GUID;
static const EFI_GUID g_simple_fs = EFI_SIMPLE_FS_GUID;
static const EFI_GUID g_file_info = EFI_FILE_INFO_GUID;

static void out(EFI_SYSTEM_TABLE *st, const CHAR16 *s)
{
    if (st && st->ConOut) st->ConOut->OutputString(st->ConOut, s);
}

static void wait_key(EFI_SYSTEM_TABLE *st)
{
    UINTN idx;
    EFI_INPUT_KEY key;
    if (!st->ConIn) return;
    st->BootServices->WaitForEvent(1, &st->ConIn->WaitForKey, &idx);
    st->ConIn->ReadKeyStroke(st->ConIn, &key);
}

static EFI_STATUS fail(EFI_SYSTEM_TABLE *st, const CHAR16 *msg, EFI_STATUS code)
{
    out(st, (const CHAR16 *)u"NXBoot: ");
    out(st, msg);
    out(st, (const CHAR16 *)u"\r\n\r\nPress any key...\r\n");
    wait_key(st);
    return code;
}

EFI_STATUS EFIAPI efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *st)
{
    EFI_BOOT_SERVICES *bs = st->BootServices;
    EFI_LOADED_IMAGE *self = 0;
    EFI_LOADED_IMAGE *child_info = 0;
    EFI_SIMPLE_FS *fs = 0;
    EFI_FILE *root = 0;
    EFI_FILE *file = 0;
    EFI_HANDLE child = 0;
    uint8_t info_buf[512];
    EFI_FILE_INFO *info = (EFI_FILE_INFO *)info_buf;
    UINTN info_size = sizeof(info_buf);
    UINTN size;
    UINTN exit_size = 0;
    void *buf = 0;
    EFI_STATUS s;

    s = bs->HandleProtocol(image, &g_loaded_image, (void **)&self);
    if (EFI_ERROR(s)) return fail(st, (const CHAR16 *)u"cannot read the loaded image information.", s);

    s = bs->HandleProtocol(self->DeviceHandle, &g_simple_fs, (void **)&fs);
    if (EFI_ERROR(s)) return fail(st, (const CHAR16 *)u"boot volume is not readable.", s);

    s = fs->OpenVolume(fs, &root);
    if (EFI_ERROR(s)) return fail(st, (const CHAR16 *)u"cannot open the boot volume.", s);

    s = root->Open(root, &file, (const CHAR16 *)NX_TARGET_PATH, EFI_FILE_MODE_READ, 0);
    if (EFI_ERROR(s)) {
        root->Close(root);
        return fail(st, (const CHAR16 *)u"NXBoot.EFI was not found in the NXBoot folder.", s);
    }

    s = file->GetInfo(file, &g_file_info, &info_size, info);
    if (EFI_ERROR(s) || info->FileSize == 0) {
        file->Close(file);
        root->Close(root);
        return fail(st, (const CHAR16 *)u"NXBoot.EFI is empty or unreadable.", EFI_LOAD_ERROR);
    }
    size = (UINTN)info->FileSize;

    s = bs->AllocatePool(EfiLoaderData, size, &buf);
    if (EFI_ERROR(s)) {
        file->Close(file);
        root->Close(root);
        return fail(st, (const CHAR16 *)u"not enough memory.", s);
    }

    s = file->Read(file, &size, buf);
    file->Close(file);
    root->Close(root);
    if (EFI_ERROR(s)) {
        bs->FreePool(buf);
        return fail(st, (const CHAR16 *)u"cannot read NXBoot.EFI.", s);
    }

    s = bs->LoadImage(0, image, self->FilePath, buf, size, &child);
    bs->FreePool(buf);
    if (EFI_ERROR(s)) return fail(st, (const CHAR16 *)u"NXBoot.EFI is not a valid UEFI image for this CPU.", s);

    s = bs->HandleProtocol(child, &g_loaded_image, (void **)&child_info);
    if (!EFI_ERROR(s) && child_info) child_info->DeviceHandle = self->DeviceHandle;

    s = bs->StartImage(child, &exit_size, 0);
    bs->UnloadImage(child);
    return s;
}
