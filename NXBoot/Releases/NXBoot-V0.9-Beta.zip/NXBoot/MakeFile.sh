#!/bin/bash
# NXBoot standalone build: makes the disk image (.img) from this folder only.
# Needs nothing outside Boot/NXBoot (no NixelBootManager).
# Output: NXBoot.img (override with NIXEL_IMG), files for the data partition: NIXEL_FILES.
set -e
cd "$(dirname "$(readlink -f "$0")")"
ROOT="$PWD"

NX=.
SRCDIR=$NX/Sources
BIOS=$SRCDIR/X86/BIOS
UEFI_X86=$SRCDIR/X86/UEFI
UEFI_ARM=$SRCDIR/ARM
COMMON=$SRCDIR/Common
DEC=$SRCDIR/Decoders
BUILD="$ROOT/build"

trap 'rm -rf "$BUILD"' EXIT

SRC="${NIXEL_FILES:-/mnt/storage/NixelOS}"
OUT="${NIXEL_IMG:-NXBoot.img}"
MIN_MB=34

need() {
    command -v "$1" >/dev/null 2>&1 || { echo "Missing tool: $1. Install it: pkg install $2"; exit 1; }
}

need nasm nasm
need python3 python
need mkfs.fat dosfstools
need mcopy mtools
need mmd mtools

LOW_SECTORS=$(awk '$1=="LOW_SECTORS" {print $3}' $BIOS/boot2.asm)
HIGH_BASE=$(awk '$1=="HIGH_BASE" {print $3}' $BIOS/boot2.asm)
PART_LBA=$(awk '$1=="FAT32_LBA" {print $3}' $BIOS/boot2.asm)
CHUNK_SECTORS=$(awk '$1=="CHUNK_SECTORS" {print $3}' $BIOS/boot1.asm)

rm -rf "$BUILD"
mkdir -p "$BUILD/UEFI"

python3 $COMMON/mkanim.py $NX/ANIM $BIOS "$BUILD/UEFI"

(cd $BIOS && nasm -f bin view.asm -o "$BUILD/view.bin") || { echo "view.asm failed to assemble"; exit 1; }

(cd $BIOS && nasm -f bin -I "$BUILD/" boot2.asm -o "$BUILD/boot2.bin") || { echo "boot2.asm failed to assemble (if it says TIMES value is negative: the code part of stage 2 no longer fits into LOW_SECTORS * 512 bytes)"; exit 1; }

SIZE=$(stat -c%s "$BUILD/boot2.bin")
STAGE2_SECTORS=$(( (SIZE + 511) / 512 ))
READ_SECTORS=$(( (STAGE2_SECTORS + CHUNK_SECTORS - 1) / CHUNK_SECTORS * CHUNK_SECTORS ))
if [ $((READ_SECTORS + 1)) -gt "$PART_LBA" ]; then
    echo "boot2.bin is too big: $SIZE bytes does not fit before the FAT32 partition (raise FAT32_LBA in boot2.asm)"
    exit 1
fi

nasm -f bin -I $BIOS/ "$ROOT/bootpc.asm" -DSTAGE2_SECTORS=$LOW_SECTORS -DLOW_SECTORS=$LOW_SECTORS -DHIGH_BASE=$HIGH_BASE -o "$BUILD/boot1.bin" || { echo "bootpc.asm failed to assemble (if it says TIMES value is negative: stage 1 no longer fits before the partition table at byte 446)"; exit 1; }

uefi_flags() {
    local arch="$1"
    local flags="--target=${arch}-unknown-windows -ffreestanding -fshort-wchar -fno-stack-protector -fno-builtin -fno-pic -mno-red-zone -O2 -Wall -I $COMMON -I $DEC"
    case "$arch" in aarch64) flags="${flags/-mno-red-zone/}";; esac
    echo "$flags"
}

dec_build() {
    local arch="$1"
    local flags f
    flags="$(uefi_flags "$arch")"
    mkdir -p "$BUILD/dec_$arch"
    for f in $DEC/*.c; do
        clang $flags -c "$f" -o "$BUILD/dec_$arch/$(basename "$f" .c).o"
    done
}

uefi_build() {
    local arch="$1" machine="$2" out="$3" entry_src="$4" stub_path="$5" use_dec="$6"
    local flags
    local objs=() f o
    flags="$(uefi_flags "$arch")"
    mkdir -p "$BUILD/obj_$out"
    if [ "$entry_src" = "stub" ]; then
        o="$BUILD/obj_$out/stub.o"
        clang $flags -DNX_TARGET_PATH="$stub_path" -c $COMMON/stub.c -o "$o"
        objs+=("$o")
    else
        for f in $entry_src/*.c; do
            o="$BUILD/obj_$out/$(basename "$f" .c).o"
            clang $flags -c "$f" -o "$o"
            objs+=("$o")
        done
    fi
    if [ "$use_dec" = "dec" ]; then
        for f in "$BUILD"/dec_$arch/*.o; do
            objs+=("$f")
        done
    fi
    lld-link /subsystem:efi_application /entry:efi_main /nodefaultlib /machine:$machine /out:"$BUILD/$out" "${objs[@]}" >/dev/null
}

HAVE_UEFI=0
HAVE_DEC=0
if command -v clang >/dev/null 2>&1 && command -v lld-link >/dev/null 2>&1; then
    dec_build x86_64
    dec_build aarch64
    HAVE_DEC=1
    uefi_build x86_64 x64 BootPC.EFI stub 'u"\\NXBoot\\X86\\NXBoot.EFI"'
    uefi_build aarch64 arm64 BootARM.EFI stub 'u"\\NXBoot\\ARM\\NXBoot.EFI"'
    uefi_build x86_64 x64 NXBoot_X86.EFI $UEFI_X86 "" dec
    uefi_build aarch64 arm64 NXBoot_ARM.EFI $UEFI_ARM ""
    cp "$BUILD/BootPC.EFI" "$BUILD/BootARM.EFI" "$ROOT/"
    HAVE_UEFI=1
else
    echo "clang or lld-link not found - building BIOS only. For UEFI install them: pkg install clang lld"
    if command -v cc >/dev/null 2>&1; then
        mkdir -p "$BUILD/dec_host"
        for f in $DEC/*.c; do
            cc -O2 -Wall -std=c11 -c "$f" -o "$BUILD/dec_host/$(basename "$f" .c).o"
        done
        HAVE_DEC=2
    else
        echo "No C compiler found - the image decoders were not built."
    fi
fi

mb_for() {
    local mb=$(( ($1 * 115 / 100 + 4 * 1048576 + 1048575) / 1048576 ))
    if [ "$mb" -lt "$MIN_MB" ]; then mb=$MIN_MB; fi
    echo "$mb"
}

BOOT_FILES=()
for K in kernel.elf kernel.bin boot.cfg; do
    if [ -f "$K" ]; then BOOT_FILES+=("$K"); fi
done

BOOT_BYTES=0
for K in "${BOOT_FILES[@]}"; do
    BOOT_BYTES=$(( BOOT_BYTES + ($(stat -c%s "$K") + 4095) / 4096 * 4096 ))
done
for K in "$BUILD/UEFI/ANIM.NXA" "$BUILD/UEFI/LOGO.NXI"; do
    BOOT_BYTES=$(( BOOT_BYTES + ($(stat -c%s "$K") + 4095) / 4096 * 4096 ))
done
if [ $HAVE_UEFI -eq 1 ]; then
    for K in BootPC.EFI BootARM.EFI NXBoot_X86.EFI NXBoot_ARM.EFI; do
        BOOT_BYTES=$(( BOOT_BYTES + ($(stat -c%s "$BUILD/$K") + 4095) / 4096 * 4096 ))
    done
    BOOT_BYTES=$(( BOOT_BYTES + 2 * (($(stat -c%s "$BUILD/BootPC.EFI") + $(stat -c%s "$BUILD/BootARM.EFI") + 8191) / 4096 * 4096) ))
fi

DATA_BYTES=0
if [ -d "$SRC" ]; then
    DATA_BYTES=$(find "$SRC" -type f -printf '%s\n' | awk '{s += int(($1 + 4095) / 4096) * 4096 + 256} END {print s + 0}')
    DIR_COUNT=$(find "$SRC" -type d | wc -l)
    DATA_BYTES=$(( DATA_BYTES + DIR_COUNT * 4096 ))
else
    echo "Folder $SRC not found - the files partition will be empty (in Termux run termux-setup-storage first)"
fi

P1_MB=$(mb_for "$BOOT_BYTES")
P2_MB=$(mb_for "$DATA_BYTES")
P1_START=$PART_LBA
P1_SECTORS=$(( P1_MB * 2048 ))
P2_START=$(( P1_START + P1_SECTORS ))
P2_SECTORS=$(( P2_MB * 2048 ))
TOTAL_SECTORS=$(( P2_START + P2_SECTORS ))

rm -f "$OUT"
cat "$BUILD/boot1.bin" "$BUILD/boot2.bin" > "$OUT"
truncate -s $(( TOTAL_SECTORS * 512 )) "$OUT"

python3 - "$OUT" $P1_START $P1_SECTORS $P2_START $P2_SECTORS <<'PY'
import struct, sys
path = sys.argv[1]
p1s, p1n, p2s, p2n = map(int, sys.argv[2:6])
def entry(flag, ptype, start, count):
    return struct.pack('<B3sB3sII', flag, b'\xfe\xff\xff', ptype, b'\xfe\xff\xff', start, count)
table = entry(0x80, 0x0C, p1s, p1n) + entry(0x00, 0x0C, p2s, p2n) + bytes(32)
with open(path, 'r+b') as f:
    f.seek(446)
    f.write(table)
PY

export MTOOLS_SKIP_CHECK=1
BOOTIMG="$OUT@@$((P1_START * 512))"
DATAIMG="$OUT@@$((P2_START * 512))"

mkfs.fat -F 32 -n NIXELBOOT --offset $P1_START "$OUT" $(( P1_SECTORS / 2 ))
mkfs.fat -F 32 -n NIXELFILES --offset $P2_START "$OUT" $(( P2_SECTORS / 2 ))

printf 'NixelOS FAT32 test\n' | mcopy -i "$BOOTIMG" - ::TEST.TXT
for K in "${BOOT_FILES[@]}"; do
    EXT="${K##*.}"
    mcopy -i "$BOOTIMG" "$K" "::${K%.*}.${EXT^^}"
done

mmd -i "$BOOTIMG" ::NXBoot
mcopy -i "$BOOTIMG" "$BUILD/UEFI/ANIM.NXA" "$BUILD/UEFI/LOGO.NXI" ::NXBoot/

if [ $HAVE_UEFI -eq 1 ]; then
    mmd -i "$BOOTIMG" ::EFI ::EFI/BOOT ::NXBoot/X86 ::NXBoot/ARM
    mcopy -i "$BOOTIMG" "$BUILD/BootPC.EFI" "$BUILD/BootARM.EFI" ::
    mcopy -i "$BOOTIMG" "$BUILD/BootPC.EFI" ::EFI/BOOT/BOOTX64.EFI
    mcopy -i "$BOOTIMG" "$BUILD/BootARM.EFI" ::EFI/BOOT/BOOTAA64.EFI
    mcopy -i "$BOOTIMG" "$BUILD/NXBoot_X86.EFI" ::NXBoot/X86/NXBoot.EFI
    mcopy -i "$BOOTIMG" "$BUILD/NXBoot_ARM.EFI" ::NXBoot/ARM/NXBoot.EFI
fi

if [ -d "$SRC" ]; then
    shopt -s dotglob nullglob
    FILES=("$SRC"/*)
    shopt -u dotglob nullglob
    if [ ${#FILES[@]} -gt 0 ]; then
        mcopy -s -m -n -i "$DATAIMG" "${FILES[@]}" ::
    fi
fi

mkdir -p "$NX/X86" "$NX/ARM"
cp "$BUILD/boot1.bin" "$BUILD/boot2.bin" "$NX/X86/"
cp "$BUILD/UEFI/ANIM.NXA" "$BUILD/UEFI/LOGO.NXI" "$NX/"
if [ $HAVE_UEFI -eq 1 ]; then
    cp "$BUILD/NXBoot_X86.EFI" "$NX/X86/NXBoot.EFI"
    cp "$BUILD/NXBoot_ARM.EFI" "$NX/ARM/NXBoot.EFI"
fi
if [ $HAVE_DEC -eq 1 ]; then
    rm -rf "$DEC/Build"
    mkdir -p "$DEC/Build/X86" "$DEC/Build/ARM"
    cp "$BUILD"/dec_x86_64/*.o "$DEC/Build/X86/"
    cp "$BUILD"/dec_aarch64/*.o "$DEC/Build/ARM/"
elif [ $HAVE_DEC -eq 2 ]; then
    rm -rf "$DEC/Build"
    mkdir -p "$DEC/Build/HOST"
    cp "$BUILD"/dec_host/*.o "$DEC/Build/HOST/"
fi

echo "Done: $OUT ($(stat -c%s "$OUT") bytes) - boot partition ${P1_MB} MiB, files partition ${P2_MB} MiB"
